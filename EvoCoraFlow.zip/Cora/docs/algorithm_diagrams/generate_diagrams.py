# -*- coding: utf-8 -*-
"""Generate editable SVG algorithm schematics for the Cora package.

The diagrams are explanatory schematics, not measured performance plots.  The
Python/matplotlib source keeps all text as editable SVG text elements.
"""
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Microsoft YaHei", "SimHei", "Arial", "DejaVu Sans"],
    "svg.fonttype": "none",
    "pdf.fonttype": 42,
    "font.size": 9,
    "axes.spines.right": False,
    "axes.spines.top": False,
})

OUT = Path(__file__).resolve().parent
NAVY = "#12304A"
BLUE = "#2B6CB0"
TEAL = "#2A9D8F"
GOLD = "#D98E04"
CORAL = "#C65D55"
INK = "#263238"
PALE = "#F5F8FB"
GRID = "#D9E2EC"


def canvas(title, width=12, height=4.8):
    fig, ax = plt.subplots(figsize=(width, height))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")
    ax.text(0.02, 0.95, title, ha="left", va="top", fontsize=15,
            fontweight="bold", color=NAVY)
    return fig, ax


def box(ax, xy, wh, text, color=BLUE, face="#F4F8FC", fontsize=9, radius=0.018):
    x, y = xy
    w, h = wh
    patch = FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.012,rounding_size={radius}",
                           linewidth=1.3, edgecolor=color, facecolor=face)
    ax.add_patch(patch)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
            color=INK, fontsize=fontsize, linespacing=1.35)
    return patch


def arrow(ax, start, end, color=NAVY, label=None, curve=0.0, lw=1.5):
    style = "Simple,tail_width=0.6,head_width=6,head_length=7"
    patch = FancyArrowPatch(start, end, arrowstyle=style, mutation_scale=1,
                            linewidth=lw, color=color,
                            connectionstyle=f"arc3,rad={curve}")
    ax.add_patch(patch)
    if label:
        mx = (start[0] + end[0]) / 2
        my = (start[1] + end[1]) / 2 + (0.035 if curve <= 0 else 0.055)
        ax.text(mx, my, label, ha="center", va="center", fontsize=8, color=color)
    return patch


def footer(ax, text):
    ax.text(0.02, 0.035, text, ha="left", va="bottom", fontsize=8, color="#607080")


def save(fig, name):
    fig.tight_layout(pad=0.6)
    fig.savefig(OUT / f"{name}.svg", bbox_inches="tight")
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight")
    fig.savefig(OUT / f"{name}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def overall():
    fig, ax = canvas("感知—稳定识别—决策—执行—调优闭环", 14, 4.7)
    labels = [
        ("感知", "YOLO 候选\n液滴 / 激光 / 障碍", BLUE),
        ("稳定识别", "HSV 聚类 + EMA\n迟滞匹配 + 离群过滤", TEAL),
        ("决策规划", "26×26 落点\nAEG-RRT 候选路径", GOLD),
        ("执行闭环", "KCF / 轨迹 PID\n约 50 Hz 阻塞检查", CORAL),
        ("调优复盘", "轨迹回放\n有界多目标增益搜索", NAVY),
    ]
    xs = [0.03, 0.22, 0.41, 0.60, 0.79]
    for x, (head, body, col) in zip(xs, labels):
        box(ax, (x, 0.36), (0.15, 0.36), f"{head}\n\n{body}", col, "#FFFFFF", 9)
    for x in xs[:-1]:
        arrow(ax, (x + 0.15, 0.54), (x + 0.185, 0.54))
    arrow(ax, (0.865, 0.36), (0.105, 0.36), color=CORAL, curve=-0.22)
    ax.text(0.49, 0.21, "新观测 / 阻塞触发重规划", ha="center", fontsize=8, color=CORAL)
    footer(ax, "输出：稳定编号、可行路径、批量队列与可追溯的控制参数；安全门在每个执行阶段独立复核")
    save(fig, "01_overall_closed_loop")


def stable_labeling():
    fig, ax = canvas("稳定编号与三层防抖", 13, 5.4)
    box(ax, (0.03, 0.60), (0.17, 0.21), "检测框\n中心 / 半径 / HSV", BLUE)
    box(ax, (0.27, 0.60), (0.18, 0.21), "第一层\n尺寸与重复框\n离群过滤", CORAL, "#FFF7F6")
    box(ax, (0.52, 0.60), (0.18, 0.21), "第二层\n预测匹配 + 迟滞门控\n全局一对一", TEAL, "#F2FBF9")
    box(ax, (0.77, 0.60), (0.18, 0.21), "第三层\nEMA 位置平滑\n短时漏检保留身份", GOLD, "#FFF9ED")
    for a, b in [((0.20, 0.705), (0.27, 0.705)), ((0.45, 0.705), (0.52, 0.705)), ((0.70, 0.705), (0.77, 0.705))]:
        arrow(ax, a, b)
    box(ax, (0.22, 0.17), (0.23, 0.20), "颜色 / 尺寸聚类\n组标签 A、B、C…", BLUE, "#F4F8FC")
    box(ax, (0.55, 0.17), (0.23, 0.20), "稳定输出\nA1、A2、B1…\n低置信预测单独标记", NAVY, "#F5F8FB")
    arrow(ax, (0.86, 0.60), (0.67, 0.37), color=GOLD, curve=0.18)
    ax.text(0.55, 0.46, "特征更新", fontsize=8, color=GOLD)
    arrow(ax, (0.33, 0.60), (0.33, 0.37), color=BLUE)
    arrow(ax, (0.45, 0.27), (0.55, 0.27), color=NAVY)
    ax.plot([0.80, 0.98, 0.98], [0.27, 0.27, 0.53], color=CORAL, linewidth=1.2)
    arrow(ax, (0.98, 0.53), (0.90, 0.59), color=CORAL)
    ax.text(0.97, 0.39, "超时\n重建", ha="right", fontsize=8, color=CORAL)
    footer(ax, "激光与未知障碍保留在控制输入中；任何一层无法确认时，执行器优先停机而不是猜测")
    save(fig, "02_stable_labeling")


def aeg_rrt():
    fig, ax = canvas("AEG-RRT 多目标避障路径", 13, 5.4)
    box(ax, (0.03, 0.67), (0.18, 0.16), "起点 / 目标\n障碍与安全半径", BLUE)
    box(ax, (0.27, 0.67), (0.18, 0.16), "Informed RRT*\n椭圆采样与 rewiring", TEAL, "#F2FBF9")
    box(ax, (0.51, 0.67), (0.18, 0.16), "精英档案\n差分式方向扰动\n多样性保留", GOLD, "#FFF9ED")
    box(ax, (0.75, 0.67), (0.20, 0.16), "折中选择\n长度 / 净空 / 平滑度\n障碍密度", CORAL, "#FFF7F6")
    for x in (0.21, 0.45, 0.69):
        arrow(ax, (x, 0.75), (x + 0.06, 0.75))
    # schematic workspace
    ax.add_patch(Rectangle((0.09, 0.16), 0.76, 0.34, facecolor=PALE, edgecolor=GRID, linewidth=1.2))
    for cx, cy, r in [(0.31, 0.30, 0.055), (0.50, 0.39, 0.065), (0.67, 0.25, 0.045)]:
        ax.add_patch(Circle((cx, cy), r, facecolor="#E8B4AF", edgecolor=CORAL, linewidth=1.0))
    ax.add_patch(Circle((0.14, 0.23), 0.018, facecolor=TEAL, edgecolor="none"))
    ax.add_patch(Circle((0.79, 0.43), 0.018, facecolor=GOLD, edgecolor="none"))
    paths = [((0.14, 0.23), (0.24, 0.19), (0.40, 0.18), (0.56, 0.21), (0.64, 0.35), (0.79, 0.43)),
             ((0.14, 0.23), (0.20, 0.44), (0.43, 0.49), (0.60, 0.49), (0.79, 0.43)),
             ((0.14, 0.23), (0.25, 0.18), (0.44, 0.17), (0.59, 0.17), (0.75, 0.20), (0.82, 0.33), (0.79, 0.43))]
    colors = [BLUE, TEAL, GOLD]
    for pts, col in zip(paths, colors):
        ax.plot([p[0] for p in pts], [p[1] for p in pts], color=col, linewidth=2.0, alpha=0.9)
    ax.text(0.13, 0.13, "起点", color=TEAL, fontsize=8)
    ax.text(0.77, 0.48, "目标", color=GOLD, fontsize=8)
    ax.text(0.38, 0.53, "示意候选路径", color=NAVY, fontsize=8)
    arrow(ax, (0.87, 0.32), (0.94, 0.32), color=NAVY, label="执行", curve=0.0)
    footer(ax, "AEG-RRT 是候选集中的多目标折中选择器；执行前还要通过独立碰撞与净空校验")
    save(fig, "03_aeg_rrt_multiobjective")


def batch_planning():
    fig, ax = canvas("双层全液滴批量规划", 13, 5.4)
    box(ax, (0.03, 0.68), (0.17, 0.16), "液滴集合\n{A1, A2, …}", BLUE)
    box(ax, (0.27, 0.68), (0.23, 0.16), "上层：联合编码\n变长分批 + 落点序号\n顺序 / 边界 / 落点扰动", TEAL, "#F2FBF9")
    box(ax, (0.58, 0.68), (0.20, 0.16), "下层：批内规划\n近邻 + 2-opt\n26×26 安全网格解码", GOLD, "#FFF9ED")
    box(ax, (0.85, 0.68), (0.12, 0.16), "完整计划", CORAL, "#FFF7F6", 8)
    arrow(ax, (0.20, 0.76), (0.27, 0.76)); arrow(ax, (0.50, 0.76), (0.58, 0.76)); arrow(ax, (0.78, 0.76), (0.85, 0.76))
    box(ax, (0.15, 0.26), (0.22, 0.19), "批次 1\nA2 → A4 → A1", BLUE, "#F4F8FC")
    box(ax, (0.40, 0.26), (0.22, 0.19), "批次 2\nA3 → A5", TEAL, "#F2FBF9")
    box(ax, (0.65, 0.26), (0.22, 0.19), "目标函数\n距离 + 批次数 + 净空惩罚", NAVY, "#F5F8FB", 8)
    arrow(ax, (0.34, 0.355), (0.40, 0.355)); arrow(ax, (0.62, 0.355), (0.65, 0.355))
    arrow(ax, (0.70, 0.68), (0.55, 0.45), color=GOLD, curve=0.15)
    ax.text(0.40, 0.56, "候选评估", fontsize=8, color=GOLD)
    arrow(ax, (0.76, 0.45), (0.93, 0.68), color=CORAL, label="可执行", curve=0.16)
    arrow(ax, (0.15, 0.26), (0.06, 0.16), color=CORAL, label="失败则整批停止", curve=-0.2)
    footer(ax, "计划提交前必须覆盖全部液滴、批次非空、落点互斥且净空可行；不返回部分计划")
    save(fig, "04_dual_layer_batch_planning")


def pid_replay():
    fig, ax = canvas("RGR-PID：回放引导重生优化器", 14, 6.3)
    top = [(0.03, "轨迹回放\n误差 e / 控制 u / dt"),
           (0.28, "辨识简化响应\n估计运动增益与采样间隔"),
           (0.53, "有界种群初始化\nx = (Kp, Ki, Kd)"),
           (0.78, "回放多目标评价\n误差 / 能量 / 抖动 / 超调")]
    for x, label in top:
        box(ax, (x, 0.70), (0.19, 0.14), label, BLUE, fontsize=9)
    for x in (0.22, 0.47, 0.72):
        arrow(ax, (x, 0.77), (x + 0.06, 0.77))
    box(ax, (0.03, 0.35), (0.23, 0.18), "局部播种 + 高斯扰动\nx′ = clip(x + U[−1,1] r Δ)\n改善时扩半径，否则收缩", TEAL, "#F2FBF9")
    box(ax, (0.37, 0.35), (0.24, 0.18), "精英方向 + 竞争替换\n非支配档案保留多目标解\n边界裁剪后重新回放", GOLD, "#FFF9ED")
    box(ax, (0.72, 0.35), (0.25, 0.18), "贪心保留 + 停滞重生\n连续 3 代无改善：随机新种子\n父代与子代合并选优", CORAL, "#FFF7F6")
    ax.plot([0.875, 0.875, 0.145], [0.69, 0.60, 0.60], color=NAVY, linewidth=1.2)
    arrow(ax, (0.145, 0.60), (0.145, 0.54))
    arrow(ax, (0.26, 0.44), (0.37, 0.44))
    arrow(ax, (0.61, 0.44), (0.72, 0.44))
    box(ax, (0.34, 0.11), (0.33, 0.11), "终止 → scope=rrt 参数文件\n显式加载 / 有限性校验 / 现场验证", NAVY, "#F5F8FB")
    arrow(ax, (0.84, 0.34), (0.68, 0.17), color=CORAL)
    ax.plot([0.98, 0.995, 0.995, 0.875], [0.44, 0.44, 0.88, 0.88], color=TEAL, linewidth=1.2)
    arrow(ax, (0.875, 0.88), (0.875, 0.85), color=TEAL)
    ax.text(0.72, 0.89, "未达迭代上限", fontsize=8, color=TEAL)
    footer(ax, "回放模型是离线近似；图示描述算法结构，不表示实机调参收益已经得到验证")
    save(fig, "05_replay_guided_pid")


def elite_operator():
    fig, ax = canvas("AEG-RRT：精英方向与可行档案更新", 14, 6.3)
    box(ax, (0.03, 0.70), (0.22, 0.14), "多种子 Informed RRT*\n候选路径与安全捷径处理", BLUE)
    box(ax, (0.38, 0.70), (0.23, 0.14), "非支配精英与父路径\n按弧长重采样为 7 个点", TEAL, "#F2FBF9")
    box(ax, (0.74, 0.70), (0.23, 0.14), "内部点差分扰动\nq′ = q_base + F (q_a − q_b)\nF ∈ [0.25, 0.75]", GOLD, "#FFF9ED", fontsize=9)
    arrow(ax, (0.25, 0.77), (0.38, 0.77))
    arrow(ax, (0.61, 0.77), (0.74, 0.77))
    box(ax, (0.74, 0.36), (0.23, 0.16), "可行性门\n固定起终点 / 边界裁剪\n逐线段碰撞检查", CORAL, "#FFF7F6")
    box(ax, (0.38, 0.36), (0.23, 0.16), "签名去重与档案更新\nf = (长度, −净空, 转角, 密度)\n非支配筛选", TEAL, "#F2FBF9", fontsize=9)
    box(ax, (0.03, 0.36), (0.22, 0.16), "归一化折中选择\n独立路线复核后提交执行\n失败则等待重规划", NAVY, "#F5F8FB")
    arrow(ax, (0.855, 0.69), (0.855, 0.53))
    arrow(ax, (0.73, 0.44), (0.62, 0.44))
    arrow(ax, (0.37, 0.44), (0.26, 0.44))
    ax.plot([0.495, 0.495, 0.67, 0.67, 0.495],
            [0.35, 0.19, 0.19, 0.91, 0.91], color=TEAL, linewidth=1.2)
    arrow(ax, (0.495, 0.91), (0.495, 0.85), color=TEAL)
    ax.text(0.53, 0.13, "档案继续参与下一轮变异；现场变化触发重新生成候选", ha="center", fontsize=8, color=TEAL)
    footer(ax, "保留多目标折中与可行性，不把有限候选搜索解释为全局最优证明")
    save(fig, "06_aeg_rrt_elite_operator")


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    overall()
    stable_labeling()
    aeg_rrt()
    batch_planning()
    pid_replay()
    elite_operator()
    print(f"generated SVG diagrams in {OUT}")
