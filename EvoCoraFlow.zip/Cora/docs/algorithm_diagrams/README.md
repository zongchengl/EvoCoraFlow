# 算法图

图形由 Python / matplotlib 绘制，源文件为 `generate_diagrams.py`。所有图都是算法结构示意，路径形状为示意几何，不是实验统计结果。未使用论文截图或外部机构标识。

| 文件前缀 | 内容 |
| --- | --- |
| 01_overall_closed_loop | 感知、稳定识别、决策、执行、调优总链路 |
| 02_stable_labeling | 三层防抖与稳定编号 |
| 03_aeg_rrt_multiobjective | 多目标路径候选与避障示意 |
| 04_dual_layer_batch_planning | 分批与落点联合搜索、批内规划 |
| 05_replay_guided_pid | RGR-PID 的播种、评价、精英与重生 |
| 06_aeg_rrt_elite_operator | AEG-RRT 差分方向与安全档案更新 |

每幅图提供 SVG、PDF、300 dpi PNG。SVG 保留可编辑文字；PDF 使用嵌入式 TrueType 字体。原始尺寸为 12–14 英寸宽的讲解图，缩排到论文单栏前需重新检查字号；未针对某个期刊指定尺寸。

```text
python -m pip install matplotlib
python generate_diagrams.py
```

重新绘图时建议使用中文字体。缺少当前字体时会按脚本中的备选字体回退，需检查字符是否完整。

交付图完成逐图目视检查，6 幅 PDF 的文字下限检查全部通过（最小 8 pt），碰撞审查全部为 0 失败、0 警告。对应 `*.collision.json` 保存检查结果。`*.alignment.json` 记录单坐标系结构图，不涉及可比数据面板的对齐要求。源文件检查为 0 失败；PNG 分辨率、未提供 TIFF 和未限定期刊栏宽属于已记录的交付格式选择。
