# -*- coding: utf-8 -*-
"""实拍曝光/增益扫查：每个档位跑一次 YOLO，输出检出数和标注图。

用来回答「相机能出图但 Cora 检不出液滴」到底卡在哪：
  · 画面过曝/过暗 -> 换曝光档
  · 各档都检不出 -> 视场没对准液滴，或需要重新标定模型
"""
import os
import sys
import time

import cv2
from image_io import read_image, write_image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import droplet_core as core  # noqa: E402

EXPOSURES = [1500, 3000, 5000, 8000, 12000, 20000]
GAINS = [0.0]
CONF = 0.25


def draw(img, res, names):
    out = img.copy()
    colors = {0: (60, 200, 60), 1: (60, 60, 235), 2: (235, 180, 60)}
    for b in res.boxes:
        cls = int(b.cls[0])
        x1, y1, x2, y2 = [int(v) for v in b.xyxy[0].tolist()]
        c = colors.get(cls, (200, 200, 200))
        cv2.rectangle(out, (x1, y1), (x2, y2), c, 3)
        cv2.putText(out, f"{names[cls]} {float(b.conf[0]):.2f}",
                    (x1, max(24, y1 - 10)), cv2.FONT_HERSHEY_SIMPLEX,
                    1.4, c, 3)
    return out


def main():
    from ultralytics import YOLO

    model = YOLO(os.path.join(HERE, "weights", "best.pt"))
    names = model.names
    print(f"模型类别：{names}")

    cam = core.HikCamera()
    print(f"相机已打开：{cam.access_mode}")

    # 先跑一次热身，避免首帧耗时被算进去
    import numpy as np
    model.predict(np.zeros((640, 640, 3), dtype=np.uint8), imgsz=1280,
                  device="cpu", verbose=False)

    summary = []
    try:
        for gain in GAINS:
            for expo in EXPOSURES:
                cam.cam.MV_CC_SetEnumValue("ExposureAuto", 0)
                cam.cam.MV_CC_SetFloatValue("ExposureTime", float(expo))
                cam.cam.MV_CC_SetEnumValue("GainAuto", 0)
                cam.cam.MV_CC_SetFloatValue("Gain", float(gain))
                time.sleep(0.35)
                for _ in range(3):
                    cam.get_frame(timeout=2000)
                fr = cam.get_frame(timeout=3000)
                if fr is None:
                    print(f"expo {expo:>6}  gain {gain}  取帧失败")
                    continue

                gray = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
                over = (gray > 250).mean() * 100
                t0 = time.time()
                res = model.predict(fr, imgsz=1280, conf=CONF,
                                    device="cpu", verbose=False)[0]
                dt = time.time() - t0

                counts = {}
                for b in res.boxes:
                    nm = names[int(b.cls[0])]
                    counts[nm] = counts.get(nm, 0) + 1

                line = (f"expo {expo:>6}us  gain {gain:<4}  亮度 {gray.mean():6.1f}  "
                        f"过曝 {over:5.1f}%  推理 {dt:5.2f}s  "
                        f"检出 {len(res.boxes):>3}  {counts if counts else ''}")
                print(line)
                summary.append((expo, gain, gray.mean(), len(res.boxes), counts))

                ann = draw(fr, res, names)
                h, w = ann.shape[:2]
                ann = cv2.resize(ann, (w // 4, h // 4), interpolation=cv2.INTER_AREA)
                cv2.putText(ann, f"expo {expo} gain {gain} hits {len(res.boxes)}",
                            (14, 38), cv2.FONT_HERSHEY_SIMPLEX, 1.1, (0, 0, 255), 3)
                write_image(os.path.join(HERE, f"_sweep_{expo}_{int(gain)}.png"), ann)
    finally:
        cam.close()

    print("\n========== 汇总（按检出数排序）==========")
    for expo, gain, mean, n, counts in sorted(summary, key=lambda r: -r[3]):
        print(f"  检出 {n:>3} 个 | expo {expo:>6}us gain {gain} | 亮度 {mean:6.1f} | {counts}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
