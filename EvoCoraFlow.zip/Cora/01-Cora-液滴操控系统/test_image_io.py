"""Unicode paths must work for portable image/debug entry points."""
from pathlib import Path
import tempfile
import unittest

import numpy as np
from image_io import read_image, write_image


class ImagePathTests(unittest.TestCase):
    def test_unicode_directory_and_filename_roundtrip_losslessly(self):
        with tempfile.TemporaryDirectory() as folder:
            parent = Path(folder) / "中文图片"
            parent.mkdir()
            path = parent / "液滴样例.png"
            pixels = np.arange(18 * 24 * 3, dtype=np.uint8).reshape(18, 24, 3)
            self.assertTrue(write_image(path, pixels))
            np.testing.assert_array_equal(read_image(path), pixels)

    def test_missing_image_returns_none_and_failed_write_raises(self):
        with tempfile.TemporaryDirectory() as folder:
            missing = Path(folder) / "不存在" / "样例.png"
            self.assertIsNone(read_image(missing))
            with self.assertRaises(OSError):
                write_image(missing, np.zeros((3, 3, 3), dtype=np.uint8))


if __name__ == "__main__":
    unittest.main()
