import argparse
import ctypes
import json
import os
import sys
from ctypes import *
import math
import random
import statistics
import threading
import time

try:
    import serial
except ImportError:  # 没装 pyserial 时仍可做纯视觉/离线调试
    serial = None
from dataclasses import dataclass

import cv2
import numpy as np
try:
    from multiobjective_planner import generate_candidate_paths
except ImportError:  # standalone legacy imports retain their original planner
    generate_candidate_paths = None
try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None


def get_screen_size(default=(1280, 720)):
    try:
        user32 = ctypes.windll.user32
        return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
    except Exception:
        return default


def resize_to_fit(image, max_width, max_height, margin=0.92):
    if image is None:
        return image

    height, width = image.shape[:2]
    limit_w = max(1, int(max_width * margin))
    limit_h = max(1, int(max_height * margin))
    scale = min(limit_w / width, limit_h / height, 1.0)

    if scale >= 1.0:
        return image

    new_width = max(1, int(width * scale))
    new_height = max(1, int(height * scale))
    return cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)


def _find_mvs_root():
    """自动定位相机 SDK 安装目录。"""
    # ``os.environ.get`` returns ``None`` when the optional override is not
    # configured.  Keep only real path strings so offline imports never fail
    # before the application has a chance to select demo mode.
    candidates = []
    configured_root = os.environ.get("MVS_ROOT")
    if configured_root:
        candidates.append(configured_root)
    for program_root in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
        if program_root:
            candidates.append(os.path.join(program_root, "MVS"))
    for cand in candidates:
        probe = os.path.join(cand, "Development", "Samples", "Python", "MvImport")
        if os.path.isdir(probe):
            return cand
    # 都没找到也返回一个，让后面的导入错误信息指向具体路径，方便排查
    return next((path for path in candidates if path), "")


MVS_ROOT = _find_mvs_root()
MV_IMPORT = MVS_ROOT + r"\Development\Samples\Python\MvImport"

for p in [
    MVS_ROOT + r"\Development\Libraries\win64",
    MVS_ROOT + r"\Development\Bin\win64",
    r"C:\Program Files (x86)\Common Files\MVS\Runtime\Win64_x64",
]:
    if os.path.exists(p):
        os.add_dll_directory(p)

# MVS 自带的 Python 样例用的是「把 MvImport 目录本身加进 path，
# 然后 from MvCameraControl_class import *」（见 Samples/Python/GrabImage）。
# 原来的写法是当包导入（from MvImport.xxx），只有在父目录恰好在 path 上时才成立，
# 在干净环境里必然 ModuleNotFoundError。两种路径都放进去，两种写法都试。
sys.path.append(MV_IMPORT)
sys.path.append(os.path.dirname(MV_IMPORT))

MvCamera = None
try:
    from MvImport.MvCameraControl_class import *
except ImportError:
    try:
        from MvCameraControl_class import *
    except ImportError:
        # 离线调参、路径代价计算不需要相机 SDK；
        # 真正要开相机时会抛出明确的运行时错误。
        pass


def check(ret, msg):
    if ret != 0:
        raise RuntimeError(f"{msg} failed, ret=0x{ret:x}")


def ip_to_str(ip):
    return ".".join(str((ip >> s) & 0xFF) for s in (24, 16, 8, 0))


class HikCamera:
    def __init__(
        self,
        index=0,
        width=2024,
        height=2036,
        offset_x=0,
        offset_y=0,
        exposure_time=15000.0,
        gain=10.0,
        frame_rate=30.0,
    ):
        if MvCamera is None:
            raise RuntimeError(
                "相机 SDK 未找到；请安装相机驱动后再使用真实设备模式，"
                "或改用演示/图片调试模式"
            )
        self.cam = MvCamera()
        self._dst_buf = None
        self._dst_size = 0

        device_list = MV_CC_DEVICE_INFO_LIST()
        ret = MvCamera.MV_CC_EnumDevices(MV_GIGE_DEVICE | MV_USB_DEVICE, device_list)
        check(ret, "Enum devices")

        if device_list.nDeviceNum == 0:
            raise RuntimeError("No Hikrobot camera found")

        print("Camera count:", device_list.nDeviceNum)

        for i in range(device_list.nDeviceNum):
            info = cast(device_list.pDeviceInfo[i], POINTER(MV_CC_DEVICE_INFO)).contents
            if info.nTLayerType == MV_GIGE_DEVICE:
                g = info.SpecialInfo.stGigEInfo
                model = "".join(chr(c) for c in g.chModelName if c != 0)
                print(i, model, ip_to_str(g.nCurrentIp))

        device_info = cast(device_list.pDeviceInfo[index], POINTER(MV_CC_DEVICE_INFO)).contents

        ret = self.cam.MV_CC_CreateHandle(device_info)
        check(ret, "Create handle")

        # 海康 GigE 相机同一时刻只能被一个程序占用。
        # 最容易踩的坑：MVS 客户端还开着，独占打开被拒（0x80000203 无访问权限）。
        # 依次降级尝试：独占 → 独占(可抢占) → 控制(共享) → 监视(只读)，
        # 全失败时给一句能直接照做的提示，而不是甩一个十六进制错误码。
        self.access_mode = None
        open_error = None
        modes = [
            (globals().get("MV_ACCESS_Exclusive", 1), "独占"),
            (globals().get("MV_ACCESS_ExclusiveWithSwitch", 2), "独占(可抢占)"),
            (globals().get("MV_ACCESS_Control", 3), "控制(共享)"),
            (globals().get("MV_ACCESS_Monitor", 7), "监视(只读)"),
        ]
        for mode, mode_cn in modes:
            ret = self.cam.MV_CC_OpenDevice(mode, 0)
            if ret == 0:
                self.access_mode = mode_cn
                print(f"Open device: OK（访问模式：{mode_cn}）")
                break
            open_error = ret
            print(f"Open device 失败（{mode_cn}）：0x{ret:x}")
        else:
            hint = ""
            if open_error == 0x80000203:      # MV_E_ACCESS_DENIED
                hint = ("\n  相机被别的程序占用了。最常见的原因是海康 MVS 客户端还开着 ——\n"
                        "  把 MVS.exe 关掉，再重新启动 Cora 就能用。")
            elif open_error == 0x80000204:    # MV_E_BUSY
                hint = "\n  设备忙或网络断开，检查网线、网卡是否在同一网段。"
            raise RuntimeError(f"打开相机失败，ret=0x{open_error:x}{hint}")

        if device_info.nTLayerType == MV_GIGE_DEVICE:
            packet_size = self.cam.MV_CC_GetOptimalPacketSize()
            if packet_size > 0:
                ret = self.cam.MV_CC_SetIntValue("GevSCPSPacketSize", packet_size)
                print("Set packet size:", hex(ret), packet_size)

        self._set_camera_params(width, height, offset_x, offset_y, exposure_time, gain, frame_rate)

        ret = self.cam.MV_CC_SetImageNodeNum(3)
        print("Set image node num:", hex(ret))

        ret = self.cam.MV_CC_SetGrabStrategy(MV_GrabStrategy_LatestImagesOnly)
        print("Set grab strategy:", hex(ret))

        ret = self.cam.MV_CC_StartGrabbing()
        check(ret, "Start grabbing")

    def _int_range(self, node):
        """读节点的 (min, max, inc)。读不到就返回 (None, None, 1)。"""
        try:
            st = MVCC_INTVALUE_EX()
            if self.cam.MV_CC_GetIntValueEx(node, st) != 0:
                return None, None, 1
            inc = int(getattr(st, "nInc", 0) or 1)
            return int(st.nMin), int(st.nMax), max(1, inc)
        except Exception:
            return None, None, 1

    def _set_camera_params(self, width, height, offset_x, offset_y, exposure_time, gain, frame_rate):
        ret = self.cam.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)
        print("Trigger off:", hex(ret))

        # ROI 必须先归零再设尺寸：否则新尺寸可能超出剩余画幅而设置失败。
        self.cam.MV_CC_SetIntValue("OffsetX", 0)
        self.cam.MV_CC_SetIntValue("OffsetY", 0)

        # Width/Height/Offset 都要按增量对齐（多数海康机型是 8 的倍数），
        # 给的数不是倍数时相机直接拒绝，而且只返回一个错误码，很难查。
        # 这里先对齐再夹取到合法范围，再把实际生效的值打印出来。
        def fit(value, lo, hi, inc, fallback):
            if lo is None:
                return int(value) if value else fallback
            v = int(value) if value else fallback
            v = max(lo, min(hi, v))
            return lo + int((v - lo) // inc) * inc

        # ★ 顺序很关键：先把 Width/Height 定下来，再去读 Offset 的允许范围。
        # Offset 的上限是「传感器尺寸 − Width」，Width 还没设成目标值时读到的
        # 上限偏小时会错误裁剪偏移量，因此需按当前尺寸重新读取约束。
        w_min, w_max, w_inc = self._int_range("Width")
        h_min, h_max, h_inc = self._int_range("Height")
        width = fit(width, w_min, w_max, w_inc, 2024)
        height = fit(height, h_min, h_max, h_inc, 2036)

        ret = self.cam.MV_CC_SetIntValue("Width", width)
        print("Set Width:", hex(ret), width)

        ret = self.cam.MV_CC_SetIntValue("Height", height)
        print("Set Height:", hex(ret), height)

        # 尺寸已生效，现在读到的 Offset 范围才是对的
        ox_min, ox_max, ox_inc = self._int_range("OffsetX")
        oy_min, oy_max, oy_inc = self._int_range("OffsetY")
        offset_x = fit(offset_x, ox_min, ox_max, ox_inc, 0)
        offset_y = fit(offset_y, oy_min, oy_max, oy_inc, 0)

        ret = self.cam.MV_CC_SetIntValue("OffsetX", offset_x)
        print("Set OffsetX:", hex(ret), offset_x)

        ret = self.cam.MV_CC_SetIntValue("OffsetY", offset_y)
        print("Set OffsetY:", hex(ret), offset_y)

        # 回读一次，确认 ROI 真的生效了（不是"设了但被忽略"）。
        # 必须从相机读实际值，不能拿本地变量冒充。
        def _read_int(node, default):
            try:
                st = MVCC_INTVALUE_EX()
                if self.cam.MV_CC_GetIntValueEx(node, st) == 0:
                    return int(st.nCurValue)
            except Exception:
                pass
            return default

        got_w = _read_int("Width", width)
        got_h = _read_int("Height", height)
        got_ox = _read_int("OffsetX", offset_x)
        got_oy = _read_int("OffsetY", offset_y)
        print(f"ROI 实际生效：{got_w} x {got_h} @ ({got_ox}, {got_oy})")
        if (got_ox, got_oy) != (offset_x, offset_y):
            print(f"注意：要求的偏移 ({offset_x}, {offset_y}) 被相机调成了 "
                  f"({got_ox}, {got_oy})")

        ret = self.cam.MV_CC_SetBoolValue("AcquisitionFrameRateEnable", True)
        print("FrameRateEnable:", hex(ret))

        ret = self.cam.MV_CC_SetFloatValue("AcquisitionFrameRate", float(frame_rate))
        print("Set FrameRate:", hex(ret), frame_rate)

        ret = self.cam.MV_CC_SetEnumValueByString("ExposureAuto", "Off")
        print("ExposureAuto Off:", hex(ret))

        ret = self.cam.MV_CC_SetFloatValue("ExposureTime", float(exposure_time))
        print("Set ExposureTime:", hex(ret), exposure_time)

        ret = self.cam.MV_CC_SetEnumValueByString("GainAuto", "Off")
        print("GainAuto Off:", hex(ret))

        ret = self.cam.MV_CC_SetFloatValue("Gain", float(gain))
        print("Set Gain:", hex(ret), gain)

    def get_frame(self, timeout=1000):
        frame_out = MV_FRAME_OUT()
        memset(byref(frame_out), 0, sizeof(frame_out))

        ret = self.cam.MV_CC_GetImageBuffer(frame_out, timeout)
        check(ret, "Get image")

        try:
            width = frame_out.stFrameInfo.nWidth
            height = frame_out.stFrameInfo.nHeight
            dst_size = width * height * 3

            if self._dst_buf is None or self._dst_size != dst_size:
                self._dst_size = dst_size
                self._dst_buf = (c_ubyte * dst_size)()

            convert_param = MV_CC_PIXEL_CONVERT_PARAM()
            memset(byref(convert_param), 0, sizeof(convert_param))

            convert_param.nWidth = width
            convert_param.nHeight = height
            convert_param.pSrcData = cast(frame_out.pBufAddr, POINTER(c_ubyte))
            convert_param.nSrcDataLen = frame_out.stFrameInfo.nFrameLen
            convert_param.enSrcPixelType = frame_out.stFrameInfo.enPixelType
            convert_param.enDstPixelType = PixelType_Gvsp_BGR8_Packed
            convert_param.pDstBuffer = self._dst_buf
            convert_param.nDstBufferSize = dst_size

            ret = self.cam.MV_CC_ConvertPixelType(convert_param)
            check(ret, "Convert pixel")

            img = np.ctypeslib.as_array(self._dst_buf, shape=(dst_size,))
            return img.reshape((height, width, 3)).copy()

        finally:
            self.cam.MV_CC_FreeImageBuffer(frame_out)

    def close(self):
        self.cam.MV_CC_StopGrabbing()
        self.cam.MV_CC_CloseDevice()
        self.cam.MV_CC_DestroyHandle()


class ThreadedHikCamera:
    def __init__(self, *args, **kwargs):
        self.camera = HikCamera(*args, **kwargs)
        self._lock = threading.Lock()
        self._frame_ready = threading.Event()
        self._stop_event = threading.Event()
        self._latest_frame = None
        self._latest_seq = 0
        self._latest_error = None
        self._closed = False
        self._thread = threading.Thread(target=self._reader, daemon=True)
        self._thread.start()

    def _reader(self):
        try:
            while not self._stop_event.is_set():
                frame = self.camera.get_frame()
                with self._lock:
                    self._latest_frame = frame
                    self._latest_seq += 1
                    self._latest_error = None
                    self._frame_ready.set()
        except Exception as exc:
            with self._lock:
                self._latest_error = exc
                self._frame_ready.set()

    def get_frame(self, timeout=1.0):
        if self._latest_frame is None:
            if not self._frame_ready.wait(timeout):
                raise TimeoutError("No frame received from threaded camera")

        with self._lock:
            if self._latest_error is not None:
                raise self._latest_error
            if self._latest_frame is None:
                raise TimeoutError("No frame available from threaded camera")
            return self._latest_frame

    def get_frame_with_seq(self, timeout=1.0):
        if self._latest_frame is None:
            if not self._frame_ready.wait(timeout):
                raise TimeoutError("No frame received from threaded camera")

        with self._lock:
            if self._latest_error is not None:
                raise self._latest_error
            if self._latest_frame is None:
                raise TimeoutError("No frame available from threaded camera")
            return self._latest_seq, self._latest_frame

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._stop_event.set()
        try:
            self.camera.close()
        finally:
            if self._thread.is_alive():
                self._thread.join(timeout=1.0)


def box_center(box):
    x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
    return (x1 + x2) / 2, (y1 + y2) / 2


def collect_detections(result):
    detections = []
    if result.boxes is None:
        return detections

    for box in result.boxes:
        cls_id = int(box.cls[0])
        name = result.names[cls_id]
        conf = float(box.conf[0])
        cx, cy = box_center(box)
        x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
        detections.append({
            "name": name,
            "conf": conf,
            "center": (cx, cy),
            "xyxy": (x1, y1, x2, y2),
        })
    return detections


def best_detection(detections, name):
    candidates = [d for d in detections if d["name"] == name]
    if not candidates:
        return None
    return max(candidates, key=lambda d: d["conf"])


def resolve_serial_port(preferred=None):
    """挑出步进电机的串口。

    同一设备插入不同 USB 口时，系统分配的端口号可能变化，因此不写死。
    优先认 CH340/CH341（Y42XYZ 常见转串口芯片），认不出来就用第一个。
    """
    if preferred:
        return preferred
    try:
        import serial.tools.list_ports as list_ports
    except Exception:
        return None
    ports = list(list_ports.comports())
    if not ports:
        return None
    for p in ports:
        hwid = (p.hwid or "").upper()
        desc = (p.description or "").upper()
        if "1A86" in hwid or "CH340" in desc or "CH341" in desc:
            return p.device
    return ports[0].device


class Y42XYZ:
    def __init__(
        self,
        port=None,
        baudrate=115200,
        x_addr=1,
        y_addr=2,
        z_addr=3,
        verbose=True,
        command_delay=0.08,
        motion_readback=True,
    ):
        if serial is None:
            raise RuntimeError(
                "未安装 pyserial，无法驱动步进电机。请执行: pip install pyserial")
        if not port:
            port = resolve_serial_port()
        if not port:
            raise RuntimeError("没有找到可用串口，请通过 --port 显式指定电机端口")
        self.ser = serial.Serial(port, baudrate, timeout=0.3)
        time.sleep(0.5)

        self.addr = {
            "x": x_addr,
            "y": y_addr,
            "z": z_addr,
        }
        self.verbose = verbose
        self.command_delay = command_delay
        self.motion_readback = motion_readback

    def _show(self, data):
        return " ".join(f"{b:02X}" for b in data)

    def _u16(self, value):
        value = int(value)
        return [(value >> 8) & 0xFF, value & 0xFF]

    def _send(self, data, n=64, delay=0.08, read_reply=True):
        data = bytes(data)
        self.ser.reset_input_buffer()
        self.ser.write(data)
        if delay > 0:
            time.sleep(delay)

        if read_reply and n > 0:
            reply = self.ser.read(n)
        else:
            reply = b""

        if self.verbose:
            print("TX:", self._show(data), "RX:", self._show(reply))

        return reply

    def check(self):
        for axis in ["x", "y", "z"]:
            addr = self.addr[axis]
            print("check", axis)
            self._send([addr, 0x1F, 0x6B])

    def enable_motor(self, axis, on=True):
        addr = self.addr[axis]
        return self._send([
            addr, 0xF3, 0xAB,
            0x01 if on else 0x00,
            0x00,
            0x6B,
        ])

    def enable(self):
        for axis in ["x", "y", "z"]:
            self.enable_motor(axis, True)

    def disable(self):
        for axis in ["x", "y", "z"]:
            self.enable_motor(axis, False)

    def clear_axis_protect(self, axis):
        addr = self.addr[axis]
        return self._send([addr, 0x0E, 0x52, 0x6B])

    def clear_protect(self):
        for axis in ["x", "y", "z"]:
            self.clear_axis_protect(axis)

    def speed(self, axis, rpm, accel=10):
        addr = self.addr[axis]
        direction = 0x00 if rpm >= 0 else 0x01
        speed_bytes = self._u16(abs(rpm))
        accel = max(0, min(255, int(accel)))

        return self._send([
            addr,
            0xF6,
            direction,
            *speed_bytes,
            accel,
            0x00,
            0x6B,
        ], delay=self.command_delay, read_reply=self.motion_readback)

    def stop_axis(self, axis):
        addr = self.addr[axis]
        return self._send(
            [addr, 0xFE, 0x98, 0x00, 0x6B],
            delay=self.command_delay,
            read_reply=self.motion_readback,
        )

    def stop(self):
        for axis in ["x", "y", "z"]:
            self.stop_axis(axis)

    def move(self, x=0, y=0, z=0, accel=10):
        self.speed("x", x, accel)
        self.speed("y", y, accel)
        self.speed("z", z, accel)

    def move_xy(self, x=20, y=20, accel=10):
        self.speed("x", x, accel)
        self.speed("y", y, accel)
        self.stop_axis("z")

    def run_xy(self, x=20, y=20, seconds=2, accel=10):
        try:
            self.clear_protect()
            self.enable()
            self.move_xy(x, y, accel)
            time.sleep(seconds)
        finally:
            self.stop()

    def circle_xy(self, speed=15, seconds=5, steps=120, clockwise=True, accel=10):
        self.clear_protect()
        self.enable()
        self.stop_axis("z")

        dt = seconds / steps
        direction = -1 if clockwise else 1

        try:
            for i in range(steps + 1):
                theta = direction * 2 * math.pi * i / steps
                vx = int(-speed * math.sin(theta))
                vy = int(speed * math.cos(theta))

                self.speed("x", vx, accel)
                self.speed("y", vy, accel)
                self.stop_axis("z")
                time.sleep(dt)
        finally:
            self.stop()
            print("stopped")

    def close(self):
        try:
            self.stop()
        finally:
            self.ser.close()


DEFAULT_K = 0.018
DEFAULT_KI = 0
DEFAULT_KD = 0.000006
DEFAULT_I_LIMIT = 1500.0
DEFAULT_MAX_SPEED = 16
DEFAULT_MIN_SPEED = 4
DEFAULT_DEADBAND = 12


DRAW_K = 0.04
DRAW_KI = 0
DRAW_KD = 0.002
DRAW_I_LIMIT = 1500.0
DRAW_MAX_SPEED = 22
DRAW_MIN_SPEED = 4
DRAW_DEADBAND = 10
DEFAULT_POSITION_ALPHA = 0.35
DEFAULT_ASSOCIATION_RADIUS = 140.0
DEFAULT_LOST_FRAMES = 500
DEFAULT_MAX_CLICK_DIST = 140.0
DEFAULT_COMMAND_INTERVAL = 0.04
DEFAULT_MOTOR_COMMAND_DELAY = 0.02
DEFAULT_MAX_DETECTION_AGE = 0.80

SOURCE_CLOSE_DIST = 150.0
TARGET_ARRIVE_DIST = 5.0
RESET_ARRIVE_DIST = 40.0

MULTI_K = 0.015
MULTI_KI = 0
MULTI_KD = 0.002
MULTI_I_LIMIT = 1500.0
MULTI_MAX_SPEED = 16
MULTI_MIN_SPEED = 4
MULTI_DEADBAND = 10


MULTI_ARRIVE_DIST = 90.0


RRT_K = 0.045
RRT_KI = 0


RRT_KD = 0.0008
RRT_I_LIMIT = 1500.0

RRT_MAX_SPEED = 34
RRT_MIN_SPEED = 5

RRT_DEADBAND = 12
RRT_SOURCE_CLOSE_DIST = 110.0
RRT_TARGET_ARRIVE_DIST = 40.0
RRT_PATH_LOOKAHEAD_DIST = 80
RRT_PATH_PROJECTION_BACKTRACK = 4
RRT_DESIRED_ALPHA = 0.55
RRT_SPEED_ALPHA = 0.35
RRT_SPEED_MAX_DELTA = 9
RRT_DERIVATIVE_LIMIT = 3500.0
RRT_BRAKE_TIME = 0.0
RRT_DIRECT_CONFIRM_FRAMES = 5

RRT_ALLOW_TARGET_DIRECT = False

RRT_ALLOW_SOURCE_DIRECT = False


POINT_LINE_LOOKAHEAD = 80.0
POINT_CROSS_TRACK_GAIN = 1.20
POINT_CROSS_TRACK_LIMIT = 90.0
POINT_LINE_ARRIVE_DIST = 40.0

LASER_MIN_CONF = 0.15

MODE_POINT = "POINT_TARGET"
MODE_DRAW = "DRAW_LETTER"
MODE_MULTI = "MULTI_DROPLETS"
MODE_RRT = "RRT_PLANNER"
ACTION_RESET_HOME = "RESET_HOME"

PATH_ARRIVE_DIST = 60.0
PATH_POINT_SPACING = 80.0
PATH_DRAW_MIN_STEP = 14.0
MIN_PATH_LENGTH = 30.0

DRAW_LOOKAHEAD_DIST = 200.0
DRAW_FINISH_DIST = 45.0
DRAW_PROJECTION_BACKTRACK = 4

RIGHT_PANEL_WIDTH = 250
RIGHT_PANEL_MARGIN = 16
UI_BUTTONS = {
    MODE_POINT: (16, 54, 234, 104),
    MODE_DRAW: (16, 118, 234, 168),
    MODE_MULTI: (16, 182, 234, 232),
    MODE_RRT: (16, 246, 234, 296),
    ACTION_RESET_HOME: (16, 310, 234, 360),
}

X_DIR = 1
Y_DIR = 1

STATE_WAIT_DROPLET = "WAIT_DROPLET"
STATE_WAIT_TARGET = "WAIT_TARGET"
STATE_WAIT_PATH = "WAIT_PATH"
STATE_WAIT_SEQUENCE = "WAIT_SEQUENCE"
STATE_DRAW_PATH = "DRAW_PATH"
STATE_SEEK_DROPLET = "SEEK_DROPLET"
STATE_DRAG_TO_TARGET = "DRAG_TO_TARGET"
STATE_DRAG_TO_PATH = "DRAG_TO_PATH"
STATE_DRAG_TO_SEQUENCE = "DRAG_TO_SEQUENCE"
STATE_RETURN_HOME = "RETURN_HOME"
STATE_ARRIVED = "ARRIVED"

STATE_WAIT_SELECTION = "RRT_WAIT_SELECTION"
STATE_WAIT_PLAN = "RRT_WAIT_PLAN"
STATE_SEEK_SOURCE = "RRT_SEEK_SOURCE"
STATE_BRAKE_BEFORE_TARGET = "RRT_BRAKE_BEFORE_TARGET"
STATE_MOVE_TO_TARGET = "RRT_MOVE_TO_TARGET"
STATE_PLAN_FAILED = "RRT_PLAN_FAILED"
STATE_WAIT_REPLAN = "RRT_WAIT_REPLAN"


# =============================
# Basic utilities
# =============================
def distance(a, b):
    return math.hypot(float(a[0]) - float(b[0]), float(a[1]) - float(b[1]))


def point_error(current, desired):
    return desired[0] - current[0], desired[1] - current[1]


def smooth_point(previous, current, alpha):
    if current is None:
        return previous
    if previous is None:
        return (float(current[0]), float(current[1]))
    beta = 1.0 - alpha
    return (previous[0] * alpha + float(current[0]) * beta,
            previous[1] * alpha + float(current[1]) * beta)


def update_laser_track(control_state, laser_detection, args):
    """Fuse YOLO laser detections with a short constant-velocity fallback."""
    previous = control_state.get("laser_smooth")
    if laser_detection is not None and det_center(laser_detection) is not None:
        observed = det_center(laser_detection)
        last_observed = control_state.get("laser_last_observed")
        if last_observed is not None:
            vx = clamp(observed[0] - last_observed[0], -120.0, 120.0)
            vy = clamp(observed[1] - last_observed[1], -120.0, 120.0)
            old_v = control_state.get("laser_velocity", (0.0, 0.0))
            velocity = (0.65 * old_v[0] + 0.35 * vx, 0.65 * old_v[1] + 0.35 * vy)
        else:
            velocity = (0.0, 0.0)
        control_state["laser_velocity"] = velocity
        control_state["laser_last_observed"] = observed
        control_state["laser_predict_count"] = 0
        control_state["laser_track_mode"] = "yolo"
        return smooth_point(previous, observed, args.position_alpha), True

    predict_count = int(control_state.get("laser_predict_count", 0))
    max_predict = max(0, int(getattr(args, "track_predict_frames", 8)))
    if previous is not None and predict_count < max_predict:
        vx, vy = control_state.get("laser_velocity", (0.0, 0.0))
        decay = 0.86 ** predict_count
        predicted = (previous[0] + vx * decay, previous[1] + vy * decay)
        control_state["laser_predict_count"] = predict_count + 1
        control_state["laser_track_mode"] = "prediction"
        return predicted, False

    control_state["laser_track_mode"] = "lost"
    return None, False


def clamp(value, low, high):
    return max(low, min(high, value))


def sequence_turn_cost(previous, current, following):
    """Return a normalized turning penalty for a three-point sequence."""
    if previous is None or current is None or following is None:
        return 0.0
    a = (float(previous[0]) - float(current[0]), float(previous[1]) - float(current[1]))
    b = (float(following[0]) - float(current[0]), float(following[1]) - float(current[1]))
    na = math.hypot(*a)
    nb = math.hypot(*b)
    if na <= 1e-6 or nb <= 1e-6:
        return 0.0
    cosine = clamp((a[0] * b[0] + a[1] * b[1]) / (na * nb), -1.0, 1.0)
    return 1.0 - cosine


def sequence_route_cost(points, start=None, turn_weight=0.0):
    """Estimate execution cost for a droplet visit order."""
    if not points:
        return 0.0
    total = 0.0
    previous = start
    for point in points:
        if previous is not None:
            total += distance(previous, point)
        previous = point
    if turn_weight > 0.0:
        previous = start
        for index in range(len(points) - 1):
            following = points[index + 1]
            total += float(turn_weight) * sequence_turn_cost(previous, points[index], following)
            previous = points[index]
    return total


def optimize_sequence_order(points, start=None, turn_weight=0.0, method="tsp"):
    """Build a short visit order with a bounded nearest-neighbor + 2-opt TSP pass."""
    points = [(float(p[0]), float(p[1])) for p in points if p is not None]
    if len(points) < 3 or str(method).lower() in {"click", "manual", "none"}:
        return points

    remaining = list(range(len(points)))
    if start is None:
        first_index = remaining.pop(0)
        order = [first_index]
        current = points[first_index]
    else:
        order = []
        current = start
    while remaining:
        next_index = min(remaining, key=lambda i: distance(current, points[i]))
        remaining.remove(next_index)
        order.append(next_index)
        current = points[next_index]

    def ordered_cost(candidate):
        return sequence_route_cost([points[i] for i in candidate], start=start, turn_weight=turn_weight)

    best_cost = ordered_cost(order)
    improved = True
    while improved:
        improved = False
        for i in range(0, len(order) - 2):
            for j in range(i + 2, len(order) + 1):
                candidate = order[:i] + list(reversed(order[i:j])) + order[j:]
                candidate_cost = ordered_cost(candidate)
                if candidate_cost + 1e-6 < best_cost:
                    order = candidate
                    best_cost = candidate_cost
                    improved = True
    return [points[i] for i in order]


def update_runtime_metrics(control_state, step, now=None):
    """Keep bounded online metrics for later PID/path tuning."""
    now = time.time() if now is None else float(now)
    metrics = control_state.setdefault("metrics", {
        "started_at": now,
        "samples": 0,
        "max_error": 0.0,
        "mean_error": 0.0,
        "command_distance": 0.0,
        "completed_routes": 0,
        "last_state": None,
        "trace": [],
    })
    previous_update = float(metrics.get("last_update", now))
    dt = clamp(now - previous_update, 0.005, 0.5)
    ex, ey = step.get("ex"), step.get("ey")
    error_norm = None
    if ex is not None and ey is not None:
        error_norm = math.hypot(float(ex), float(ey))
        count = int(metrics.get("samples", 0))
        metrics["mean_error"] = (metrics.get("mean_error", 0.0) * count + error_norm) / (count + 1)
        metrics["samples"] = count + 1
        metrics["max_error"] = max(float(metrics.get("max_error", 0.0)), error_norm)
        trace = metrics.setdefault("trace", [])
        previous_sample = trace[-1] if trace else {}
        laser_position = step.get("laser_draw_center")
        previous_position = previous_sample.get("laser_position")
        pair_valid = (bool(previous_sample)
                      and previous_sample.get("route_id") == step.get("route_id")
                      and previous_sample.get("mode") == step.get("mode")
                      and previous_sample.get("state") == step.get("state")
                      and 0.005 <= now - previous_update <= 0.5)
        x_speed, y_speed = float(step.get("x_speed", 0.0)), float(step.get("y_speed", 0.0))
        trace.append({
            "ex": float(ex), "ey": float(ey), "dt": dt,
            "prev_ex": float(previous_sample.get("ex", ex)),
            "prev_ey": float(previous_sample.get("ey", ey)),
            "x_speed": x_speed,
            "y_speed": y_speed,
            "prev_x_speed": float(previous_sample.get("x_speed", 0.0)),
            "prev_y_speed": float(previous_sample.get("y_speed", 0.0)),
            "state": step.get("state"),
            "mode": step.get("mode"), "route_id": step.get("route_id"),
            "laser_position": laser_position,
            "previous_laser_position": previous_position,
            "pair_valid": pair_valid,
        })
        if len(trace) > 2000:
            del trace[:-2000]
    x_speed, y_speed = step.get("x_speed", 0), step.get("y_speed", 0)
    metrics["command_distance"] += math.hypot(float(x_speed), float(y_speed))
    previous_state = metrics.get("last_state")
    current_state = step.get("state")
    if current_state == STATE_ARRIVED and previous_state != STATE_ARRIVED:
        metrics["completed_routes"] = int(metrics.get("completed_routes", 0)) + 1
    metrics["last_state"] = current_state
    metrics["last_update"] = now


def adaptive_gain_scale(error_norm, deadband, enabled=True):
    """Bounded gain scheduling used by optional automatic PID mode."""
    if not enabled or error_norm is None:
        return 1.0
    deadband = max(1.0, float(deadband))
    # Reduce gain near the destination to limit overshoot, while preserving
    # enough gain to overcome static friction outside the deadband.
    return clamp(0.72 + 0.28 * min(1.0, float(error_norm) / (8.0 * deadband)), 0.72, 1.0)


def _clamp_vector(vector, bounds):
    return [clamp(float(value), float(low), float(high)) for value, (low, high) in zip(vector, bounds)]


def pareto_dominates(left, right):
    """Minimization dominance used by the controller's elite archive."""
    return all(float(a) <= float(b) for a, b in zip(left, right)) and any(
        float(a) < float(b) for a, b in zip(left, right)
    )


def update_pareto_archive(archive, candidate, max_size=64):
    """Keep nondominated (decision, objective) pairs and preserve diversity."""
    decision, objectives = candidate
    if any(pareto_dominates(existing[1], objectives) for existing in archive):
        return archive
    archive[:] = [existing for existing in archive if not pareto_dominates(objectives, existing[1])]
    archive.append((list(decision), tuple(float(v) for v in objectives)))
    if len(archive) > max_size:
        # A simple crowding proxy: remove the most crowded decision-space item.
        archive.sort(key=lambda item: sum(float(v) for v in item[1]))
        while len(archive) > max_size:
            archive.pop(len(archive) // 2)
    return archive


def elite_direction_vector(vector, archive, bounds, alpha=6, beta=0.5, rng=None):
    """Build a bounded direction from high- and low-ranked archive members."""
    if not archive:
        return _clamp_vector(vector, bounds)
    rng = rng or random.Random()
    sample = list(archive)
    rng.shuffle(sample)
    sample = sample[:max(2, min(int(alpha), len(sample)))]
    sample.sort(key=lambda item: sum(float(v) for v in item[1]))
    z = max(1, min(len(sample) // 2, int(round(len(sample) * float(beta)))))
    top = sample[:z]
    bottom = sample[-z:]
    direction = [
        sum(item[0][d] for item in top) / len(top)
        - sum(item[0][d] for item in bottom) / len(bottom)
        for d in range(len(vector))
    ]
    return _clamp_vector([float(v) + direction[d] for d, v in enumerate(vector)], bounds)


def competition_replacement(vector, previous_vector, population, archive, bounds, rng=None):
    """Replace a stalled candidate using archive and population separation."""
    if not archive or not population or previous_vector is None:
        return _clamp_vector(vector, bounds)
    rng = rng or random.Random()
    guide = list(archive)
    if len(guide) > len(population):
        guide = rng.sample(guide, len(population))
    best = min(guide, key=lambda item: sum(float(v) for v in item[1]))[0]
    phi = rng.uniform(0.0, 1.0)
    predicted = [float(vector[d]) + phi * (float(vector[d]) - float(previous_vector[d])) for d in range(len(vector))]
    mean_pred = sum(math.dist(predicted, item[0]) for item in guide) / len(guide)
    mean_best = sum(math.dist(best, item[0]) for item in guide) / len(guide)
    if mean_pred <= mean_best:
        return _clamp_vector(predicted, bounds)
    mean_population = [sum(float(item[0][d]) for item in population) / len(population) for d in range(len(vector))]
    mean_guide = [sum(float(item[0][d]) for item in guide) / len(guide) for d in range(len(vector))]
    replacement = [float(vector[d]) + mean_guide[d] - mean_population[d] for d in range(len(vector))]
    return _clamp_vector(replacement, bounds)


class ReplayGuidedRebirthOptimizer:
    """Bounded replay-guided optimizer for offline PID/profile search.

    Multiple local seeds, greedy retention and stagnation-triggered rebirth
    are kept inside explicit parameter limits. Objective evaluation is fully
    offline and replay based.
    """
    def __init__(self, objective, bounds, population_size=16, generations=24, seed=None):
        self.objective = objective
        self.bounds = list(bounds)
        self.population_size = max(4, int(population_size))
        self.generations = max(1, int(generations))
        self.rng = random.Random(seed)

    def _random_vector(self):
        return [self.rng.uniform(low, high) for low, high in self.bounds]

    def optimize(self):
        population = [(self._random_vector(), None) for _ in range(self.population_size)]
        archive = []
        best = None
        best_score = float("inf")
        radius = 0.35
        stale = 0
        previous_population = []
        for generation in range(self.generations):
            evaluated = []
            for vector, _ in population:
                score, objectives = self.objective(vector)
                evaluated.append((vector, float(score), tuple(objectives)))
                update_pareto_archive(archive, (vector, objectives), max_size=self.population_size * 3)
            evaluated.sort(key=lambda item: item[1])
            if evaluated[0][1] + 1e-9 < best_score:
                best, best_score = evaluated[0][0][:], evaluated[0][1]
                stale = 0
                radius = min(0.8, radius * 1.08)
            else:
                stale += 1
                radius = max(0.04, radius * 0.92)

            core = evaluated[0][0]
            seeds = []
            for vector, _, _ in evaluated:
                for _ in range(2):
                    candidate = []
                    for dim, (low, high) in enumerate(self.bounds):
                        span = float(high) - float(low)
                        value = vector[dim] + self.rng.uniform(-1.0, 1.0) * radius * span
                        candidate.append(clamp(value, low, high))
                    seeds.append(candidate)
            # Gaussian multiplicative exploration around the current elite.
            mutation = [
                clamp(core[d] * (1.0 + self.rng.gauss(0.0, 0.18)), low, high)
                for d, (low, high) in enumerate(self.bounds)
            ]
            seeds.append(mutation)
            if archive:
                seeds.append(elite_direction_vector(core, archive, self.bounds, rng=self.rng))
                population_vectors = [(item[0], item[0]) for item in evaluated]
                for index, item in enumerate(evaluated[-2:]):
                    previous = previous_population[-2 + index] if len(previous_population) >= 2 else item[0]
                    seeds.append(competition_replacement(
                        item[0], previous, population_vectors, archive, self.bounds, rng=self.rng
                    ))
            if stale >= 3:
                # Rebirth replaces a poor region after stagnation.
                seeds.append(self._random_vector())
                stale = 0
            scored = []
            for candidate in seeds:
                score, objectives = self.objective(candidate)
                scored.append((candidate, float(score), tuple(objectives)))
                update_pareto_archive(archive, (candidate, objectives), max_size=self.population_size * 3)
            pool = sorted(evaluated + scored, key=lambda item: item[1])
            previous_population = [item[0][:] for item in evaluated]
            population = [(item[0], item[1]) for item in pool[:self.population_size]]
        # Include offspring evaluated in the final generation in the result.
        if pool[0][1] < best_score:
            best, best_score = pool[0][0][:], pool[0][1]
        return {"best": best, "score": best_score, "archive": archive, "generations": self.generations}


def estimate_replay_plant(trace, min_command=2.0):
    """Estimate pixels per command-unit-second from recorded closed-loop pairs."""
    gains_x, gains_y = [], []
    for sample in trace:
        if sample.get("pair_valid") is False:
            continue
        dt = clamp(float(sample.get("dt", 0.04)), 0.005, 0.5)
        prev_ex = float(sample.get("prev_ex", sample.get("ex", 0.0)))
        prev_ey = float(sample.get("prev_ey", sample.get("ey", 0.0)))
        ex = float(sample.get("ex", 0.0))
        ey = float(sample.get("ey", 0.0))
        position = sample.get("laser_position")
        previous_position = sample.get("previous_laser_position")
        dx, dy = prev_ex - ex, prev_ey - ey
        if position is not None and previous_position is not None:
            # Moving waypoints change the error origin. Physical displacement
            # remains a valid response measurement across those changes.
            dx = float(position[0]) - float(previous_position[0])
            dy = float(position[1]) - float(previous_position[1])
        # Motor Y advances image-X error; motor X advances image-Y error.
        command_y = float(sample.get("prev_y_speed", sample.get("y_speed", 0.0)))
        command_x = float(sample.get("prev_x_speed", sample.get("x_speed", 0.0)))
        if abs(command_y) >= min_command:
            estimate = abs(dx / (command_y * dt))
            if math.isfinite(estimate) and 0.02 <= estimate <= 5000.0:
                gains_x.append(estimate)
        if abs(command_x) >= min_command:
            estimate = abs(dy / (command_x * dt))
            if math.isfinite(estimate) and 0.02 <= estimate <= 5000.0:
                gains_y.append(estimate)
    if len(gains_x) < 5 or len(gains_y) < 5:
        return None
    gains_x.sort()
    gains_y.sort()
    return {
        "pixels_per_speed_second_x": statistics.median(gains_x),
        "pixels_per_speed_second_y": statistics.median(gains_y),
        "samples_x": len(gains_x),
        "samples_y": len(gains_y),
    }


def evaluate_pid_replay(gains, trace, plant, min_speed=4.0, max_speed=16.0,
                        deadband=10.0, i_limit=1500.0, max_steps=1400):
    """Replay a two-axis first-order motion model using gains inferred from logs."""
    if not trace or plant is None:
        return None
    ex = float(trace[0].get("ex", 0.0))
    ey = float(trace[0].get("ey", 0.0))
    if math.hypot(ex, ey) <= deadband:
        return {"objectives": (0.0, 0.0, 0.0, 0.0), "reached": True, "steps": 0}
    integral_x = integral_y = 0.0
    previous_ex, previous_ey = ex, ey
    previous_commands = (0.0, 0.0)
    abs_error = energy = command_delta = overshoot = 0.0
    reached = False
    dt_values = [clamp(float(s.get("dt", 0.04)), 0.005, 0.5) for s in trace[-300:]]
    dt = statistics.median(dt_values) if dt_values else 0.04
    initial_norm = max(1.0, math.hypot(ex, ey))
    for step_index in range(int(max_steps)):
        norm = math.hypot(ex, ey)
        abs_error += norm * dt
        if norm <= deadband:
            reached = True
            break
        integral_x = 0.0 if abs(ex) < deadband else clamp(integral_x + ex * dt, -i_limit, i_limit)
        integral_y = 0.0 if abs(ey) < deadband else clamp(integral_y + ey * dt, -i_limit, i_limit)
        dex = (ex - previous_ex) / dt
        dey = (ey - previous_ey) / dt
        command_x = gains[0] * ey + gains[1] * integral_y + gains[2] * dey
        command_y = gains[0] * ex + gains[1] * integral_x + gains[2] * dex
        command_x = clamp(command_x, -max_speed, max_speed)
        command_y = clamp(command_y, -max_speed, max_speed)
        if abs(ey) >= deadband and abs(command_x) < min_speed:
            command_x = math.copysign(min_speed, command_x if abs(command_x) > 1e-9 else ey)
        if abs(ex) >= deadband and abs(command_y) < min_speed:
            command_y = math.copysign(min_speed, command_y if abs(command_y) > 1e-9 else ex)
        energy += command_x * command_x + command_y * command_y
        command_delta += (command_x - previous_commands[0]) ** 2 + (command_y - previous_commands[1]) ** 2
        previous_commands = (command_x, command_y)
        previous_ex, previous_ey = ex, ey
        ex -= float(plant["pixels_per_speed_second_x"]) * command_y * dt
        ey -= float(plant["pixels_per_speed_second_y"]) * command_x * dt
        # Penalize crossing the destination as overshoot; keep a bounded
        # simulation so an unstable gain set cannot run indefinitely.
        if ex * previous_ex < 0:
            overshoot += min(abs(ex), initial_norm)
        if ey * previous_ey < 0:
            overshoot += min(abs(ey), initial_norm)
    horizon = max(dt, (step_index + 1) * dt)
    norm_steps = max(1, step_index + 1)
    iae = abs_error / (initial_norm * horizon)
    effort = energy / (2.0 * max(1.0, max_speed ** 2) * norm_steps)
    jitter = command_delta / (2.0 * max(1.0, max_speed ** 2) * norm_steps)
    overshoot_ratio = overshoot / (initial_norm * norm_steps)
    completion = min(1.0, horizon / max(dt, max_steps * dt)) if reached else 1.0
    objectives = (iae, effort, jitter + 0.8 * (not reached), overshoot_ratio + completion * 0.05)
    return {"objectives": objectives, "reached": reached, "steps": norm_steps,
            "time_seconds": horizon, "final_error": math.hypot(ex, ey)}


def tune_pid_from_metrics(metrics, base=None, bounds=None, population_size=16, generations=24,
                          seed=7, min_speed=4.0, max_speed=16.0,
                          deadband=10.0, i_limit=1500.0):
    """Tune gains by replaying recorded actuator commands in an identified model."""
    base = list(base or [0.015, 0.0, 0.002])
    bounds = list(bounds or [
        (max(0.001, base[0] * 0.35), base[0] * 2.5),
        (0.0, max(0.01, base[1] * 3.0 + 0.002)),
        (max(0.0, base[2] * 0.25), max(0.01, base[2] * 3.0)),
    ])
    trace = [sample for sample in list(metrics.get("trace", []))[-1000:]
             if sample.get("ex") is not None and sample.get("ey") is not None
             and sample.get("mode", MODE_RRT) == MODE_RRT]
    if not trace:
        return {"best": base, "score": None, "archive": [], "reason": "no control trace"}
    plant = estimate_replay_plant(trace)
    if plant is None:
        return {"best": base, "score": None, "archive": [],
                "reason": "insufficient command/error pairs for replay plant estimate"}

    def objective(vector):
        replay = evaluate_pid_replay(
            vector, trace, plant,
            min_speed=min_speed, max_speed=max_speed,
            deadband=deadband, i_limit=i_limit,
        )
        objectives = replay["objectives"]
        score = objectives[0] + 0.35 * objectives[1] + 0.45 * objectives[2] + 0.55 * objectives[3]
        return score, objectives

    result = ReplayGuidedRebirthOptimizer(
        objective, bounds, population_size=population_size, generations=generations, seed=seed
    ).optimize()
    result["replay_plant"] = plant
    result["objective_names"] = ["normalized_error_integral", "control_energy",
                                 "command_jitter_and_failure", "overshoot_and_time"]
    return result


def run_pid_tuning(args):
    """Tune the RRT trajectory PID offline and write a portable JSON profile."""
    with open(args.tune_from_metrics, "r", encoding="utf-8") as metrics_handle:
        recorded_metrics = json.load(metrics_handle)
    tuned = tune_pid_from_metrics(
        recorded_metrics,
        base=[args.rrt_k, args.rrt_ki, args.rrt_kd],
        population_size=args.tune_population,
        generations=args.tune_generations,
        seed=args.rrt_seed or 7,
        min_speed=args.rrt_min_speed,
        max_speed=args.rrt_max_speed,
        deadband=args.rrt_deadband,
        i_limit=args.rrt_i_limit,
    )
    gains = tuned.get("best", [args.rrt_k, args.rrt_ki, args.rrt_kd])
    output_params = {
        "scope": "rrt",
        "kp": float(gains[0]),
        "ki": float(gains[1]),
        "kd": float(gains[2]),
        "score": tuned.get("score"),
        "archive_size": len(tuned.get("archive", [])),
        "replay_samples": len(recorded_metrics.get("trace", [])),
        "replay_plant": tuned.get("replay_plant"),
        "objective_names": tuned.get("objective_names", []),
        "reason": tuned.get("reason"),
    }
    with open(args.tuned_params_file, "w", encoding="utf-8") as tuned_handle:
        json.dump(output_params, tuned_handle, ensure_ascii=False, indent=2)
    print(json.dumps(output_params, ensure_ascii=False, indent=2))
    print(f"调参结果已保存：{os.path.abspath(args.tuned_params_file)}")
    return output_params


def apply_tuned_pid_params(args, path):
    """Load an explicitly selected, finite and non-negative PID profile."""
    with open(path, "r", encoding="utf-8") as tuned_handle:
        tuned = json.load(tuned_handle)
    # Older saved profiles did not record a control scope and were used by the
    # MULTI controller. New replay profiles explicitly target the RRT path PID.
    scope = str(tuned.get("scope", "multi")).lower()
    if scope not in {"rrt", "multi"}:
        raise ValueError("PID 配置的控制范围无效")
    values = [float(tuned.get(key, default)) for key, default in (
        ("kp", getattr(args, f"{scope}_k")),
        ("ki", getattr(args, f"{scope}_ki")),
        ("kd", getattr(args, f"{scope}_kd")),
    )]
    if any(not math.isfinite(value) or value < 0 for value in values):
        raise ValueError("PID 参数必须是有限的非负数")
    setattr(args, f"{scope}_k", values[0])
    setattr(args, f"{scope}_ki", values[1])
    setattr(args, f"{scope}_kd", values[2])
    print(f"已加载 {scope.upper()} PID：kp={values[0]:.6g}, ki={values[1]:.6g}, kd={values[2]:.6g}")
    return scope


def error_to_speed(error, integral, derivative, direction, kp, ki, kd, deadband, min_speed, max_speed):

    if abs(error) < deadband:
        return 0

    speed = direction * (kp * error + ki * integral + kd * derivative)

    if min_speed > 0 and abs(speed) < min_speed:

        fallback_sign = direction * error
        speed = math.copysign(min_speed, speed if abs(speed) > 1e-9 else fallback_sign)

    return int(max(-max_speed, min(max_speed, speed)))


def smooth_speed_command(target_speed, last_speed, alpha, max_delta):
    target_speed = int(target_speed)
    last_speed = float(last_speed or 0.0)

    # Stop immediately when the PID says the axis is inside the deadband.
    if target_speed == 0:
        return 0

    alpha = clamp(float(alpha), 0.0, 0.95)
    blended = last_speed * alpha + float(target_speed) * (1.0 - alpha)

    max_delta = max(1.0, float(max_delta))
    delta = clamp(blended - last_speed, -max_delta, max_delta)
    return int(round(last_speed + delta))


def reset_pd_state(control_state):
    """Clear PID history to avoid speed spikes after mode/target/path changes."""
    control_state["pd_last_ex"] = None
    control_state["pd_last_ey"] = None
    control_state["pd_last_time"] = None
    control_state["pd_last_state"] = None
    control_state["pd_last_route_id"] = None
    control_state["pd_last_path_index"] = None
    control_state["pd_last_segment_key"] = None
    control_state["pd_integral_ex"] = 0.0
    control_state["pd_integral_ey"] = 0.0
    control_state["rrt_desired_smooth"] = None
    control_state["rrt_last_x_speed"] = 0
    control_state["rrt_last_y_speed"] = 0


def stop_xy(stage):
    if stage is not None:
        stage.stop_axis("x")
        stage.stop_axis("y")


def point_to_segment_distance(p, a, b):
    px, py = p
    ax, ay = a
    bx, by = b
    vx = bx - ax
    vy = by - ay
    wx = px - ax
    wy = py - ay
    length2 = vx * vx + vy * vy
    if length2 <= 1e-9:
        return distance(p, a)
    t = (wx * vx + wy * vy) / length2
    t = max(0.0, min(1.0, t))
    proj = (ax + t * vx, ay + t * vy)
    return distance(p, proj)


def segment_intersects_circle(a, b, center, radius):
    return point_to_segment_distance(center, a, b) <= radius


def point_in_rect(point, rect):
    x, y = point
    x1, y1, x2, y2 = rect
    return x1 <= x <= x2 and y1 <= y <= y2


def hit_ui_button(point):
    for mode, rect in UI_BUTTONS.items():
        if point_in_rect(point, rect):
            return mode
    return None


def compact_path(points, min_dist=1.0):
    cleaned = []
    for point in points:
        if point is None:
            continue
        current = (float(point[0]), float(point[1]))
        if not cleaned or distance(cleaned[-1], current) >= min_dist:
            cleaned.append(current)
    return cleaned


def path_total_length(points):
    points = compact_path(points, 1.0)
    if len(points) < 2:
        return 0.0
    return sum(distance(points[i - 1], points[i]) for i in range(1, len(points)))


def resample_path(points, spacing):
    """Convert a freehand mouse path into evenly spaced waypoints."""
    points = compact_path(points, 1.0)
    if len(points) <= 2:
        return points

    spacing = max(1.0, float(spacing))
    samples = [points[0]]
    next_sample_dist = spacing
    walked = 0.0

    for i in range(1, len(points)):
        start = points[i - 1]
        end = points[i]
        seg_len = distance(start, end)
        if seg_len <= 1e-6:
            continue

        while walked + seg_len >= next_sample_dist:
            ratio = (next_sample_dist - walked) / seg_len
            x = start[0] + (end[0] - start[0]) * ratio
            y = start[1] + (end[1] - start[1]) * ratio
            samples.append((x, y))
            next_sample_dist += spacing

        walked += seg_len

    if distance(samples[-1], points[-1]) > 1.0:
        samples.append(points[-1])
    return samples


def vector_norm(vec):
    return math.hypot(float(vec[0]), float(vec[1]))


def limit_vector(vec, max_norm):
    """Limit a 2D vector length while keeping its direction."""
    length = vector_norm(vec)
    if length <= 1e-9 or length <= max_norm:
        return vec
    scale = float(max_norm) / length
    return (vec[0] * scale, vec[1] * scale)


def compute_line_tracking_target(position, line_start, line_end, lookahead, cross_gain, cross_limit):
    """Return a desired point that forces POINT mode to stay on a straight line.

    A = line_start, B = line_end, P = current laser position.
    H is P projected onto segment AB.
    The forward term moves from H toward B.
    The cross-track term pulls P back toward H, so the controller does not merely
    chase the final target and cut across the line.
    """
    if position is None or line_start is None or line_end is None:
        return line_end, 0.0, 0.0

    ax, ay = float(line_start[0]), float(line_start[1])
    bx, by = float(line_end[0]), float(line_end[1])
    px, py = float(position[0]), float(position[1])

    vx, vy = bx - ax, by - ay
    line_len = math.hypot(vx, vy)
    if line_len <= 1e-6:
        return (bx, by), 1.0, distance(position, line_end)

    ux, uy = vx / line_len, vy / line_len
    progress = ((px - ax) * ux + (py - ay) * uy)
    progress_clamped = clamp(progress, 0.0, line_len)

    hx = ax + ux * progress_clamped
    hy = ay + uy * progress_clamped

    lookahead = max(0.0, float(lookahead))
    forward_progress = clamp(progress_clamped + lookahead, 0.0, line_len)
    fx = ax + ux * forward_progress
    fy = ay + uy * forward_progress

    # Cross-track correction: vector from current position back to the line.
    cx = (hx - px) * float(cross_gain)
    cy = (hy - py) * float(cross_gain)
    cx, cy = limit_vector((cx, cy), max(0.0, float(cross_limit)))

    desired = (fx + cx, fy + cy)
    cross_track_error = math.hypot(hx - px, hy - py)
    progress_ratio = progress_clamped / line_len
    return desired, progress_ratio, cross_track_error


def path_cumulative_lengths(points):
    """Return cumulative arc length for a polyline."""
    points = compact_path(points, 1.0)
    if not points:
        return []
    lengths = [0.0]
    total = 0.0
    for i in range(1, len(points)):
        total += distance(points[i - 1], points[i])
        lengths.append(total)
    return lengths


def interpolate_path_at_s(points, cumulative, s):
    """Interpolate a point on a polyline by arc length."""
    if not points:
        return None
    if len(points) == 1 or not cumulative:
        return points[0]

    s = clamp(float(s), 0.0, cumulative[-1])
    if s <= 0.0:
        return points[0]
    if s >= cumulative[-1]:
        return points[-1]

    for i in range(1, len(points)):
        if cumulative[i] >= s:
            seg_start = cumulative[i - 1]
            seg_len = max(1e-6, cumulative[i] - seg_start)
            ratio = (s - seg_start) / seg_len
            a = points[i - 1]
            b = points[i]
            return (a[0] + (b[0] - a[0]) * ratio,
                    a[1] + (b[1] - a[1]) * ratio)

    return points[-1]


def project_point_to_segment(point, a, b):
    """Project point P onto segment AB."""
    px, py = float(point[0]), float(point[1])
    ax, ay = float(a[0]), float(a[1])
    bx, by = float(b[0]), float(b[1])
    vx, vy = bx - ax, by - ay
    seg_len2 = vx * vx + vy * vy
    if seg_len2 <= 1e-9:
        return a, 0.0, distance(point, a)
    t = ((px - ax) * vx + (py - ay) * vy) / seg_len2
    t = clamp(t, 0.0, 1.0)
    proj = (ax + vx * t, ay + vy * t)
    return proj, t, distance(point, proj)


def compute_continuous_path_target(points, position, start_index, lookahead, backtrack=4, finish_dist=None):

    points = compact_path(points, 1.0)
    if position is None or len(points) < 2:
        return None, 0, 0.0, 0.0, True

    cumulative = path_cumulative_lengths(points)
    total_len = cumulative[-1] if cumulative else 0.0
    if total_len <= 1e-6:
        return points[-1], len(points) - 1, 1.0, 0.0, True

    start_i = max(0, min(int(start_index), len(points) - 2) - int(backtrack))
    best = None
    for i in range(start_i, len(points) - 1):
        proj, t, dist_to_seg = project_point_to_segment(position, points[i], points[i + 1])
        s = cumulative[i] + distance(points[i], proj)
        # Lightly prefer forward progress to avoid jumping backward on self-crossing paths.
        if best is None or dist_to_seg < best[0]:
            best = (dist_to_seg, i, t, proj, s)

    if best is None:
        return points[-1], len(points) - 1, 1.0, distance(position, points[-1]), True

    _, seg_index, _, _, current_s = best
    target_s = min(total_len, current_s + max(0.0, float(lookahead)))
    desired = interpolate_path_at_s(points, cumulative, target_s)

    # Progress index is for UI/status only. Do not use it as a stop waypoint.
    progress_index = seg_index
    while progress_index < len(cumulative) - 1 and cumulative[progress_index + 1] <= current_s:
        progress_index += 1

    progress_ratio = current_s / total_len
    dist_to_end = distance(position, points[-1])
    if finish_dist is None:
        finish_dist = DRAW_FINISH_DIST
    finished = progress_ratio >= 0.995 and dist_to_end <= 1.5 * max(1.0, float(finish_dist))
    return desired, progress_index, progress_ratio, dist_to_end, finished


# =============================
# Detection helpers
# =============================
def is_droplet(det):
    return det.get("name") != "laser"


def det_center(det):
    center = det.get("center")
    if center is None:
        return None
    return (float(center[0]), float(center[1]))


def det_bbox(det):
    for key in ("xyxy", "bbox", "box"):
        value = det.get(key)
        if value is None:
            continue
        if isinstance(value, dict):
            keys = {str(k).lower(): v for k, v in value.items()}
            if all(k in keys for k in ("x1", "y1", "x2", "y2")):
                return (float(keys["x1"]), float(keys["y1"]), float(keys["x2"]), float(keys["y2"]))
        if isinstance(value, (list, tuple)) and len(value) >= 4:
            x1, y1, x2, y2 = value[:4]
            return (float(x1), float(y1), float(x2), float(y2))
    if all(k in det for k in ("x1", "y1", "x2", "y2")):
        return (float(det["x1"]), float(det["y1"]), float(det["x2"]), float(det["y2"]))
    return None


def det_radius(det, default_radius=35.0):
    box = det_bbox(det)
    if box is None:
        return float(default_radius)
    x1, y1, x2, y2 = box
    w = abs(x2 - x1)
    h = abs(y2 - y1)
    return max(5.0, 0.5 * max(w, h))


def draw_detection(view, det, color, label=None):
    center = det_center(det)
    box = det_bbox(det)
    if label is None:
        label = det.get("name", "")

    if box is not None:
        x1, y1, x2, y2 = [int(v) for v in box]
        cv2.rectangle(view, (x1, y1), (x2, y2), color, 2)
        if label:
            cv2.putText(view, label, (x1, max(20, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
    elif center is not None:
        x, y = int(center[0]), int(center[1])
        cv2.circle(view, (x, y), 12, color, 2)
        if label:
            cv2.putText(view, label, (x + 14, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)


def nearest_droplet_detection(detections, click_point, max_click_dist):
    candidates = [d for d in detections if is_droplet(d) and det_center(d) is not None]
    if not candidates:
        return None, None
    nearest = min(candidates, key=lambda d: distance(det_center(d), click_point))
    nearest_dist = distance(det_center(nearest), click_point)
    if nearest_dist > max_click_dist:
        return None, nearest_dist
    return nearest, nearest_dist


def select_laser_detection(detections):
    laser = best_detection(detections, "laser")
    if laser is None:
        return None, None
    if float(laser.get("conf", 0.0)) < LASER_MIN_CONF:
        return None, laser
    return laser, laser


def select_locked_droplet(detections, selected_name, locked_center, missing_count, args):
    if selected_name is None or locked_center is None:
        return None, locked_center, missing_count

    candidates = [d for d in detections if d.get("name") == selected_name and det_center(d) is not None]
    if not candidates:
        missing_count += 1
        if missing_count >= args.lost_frames:
            return None, None, 0
        return None, locked_center, missing_count

    nearest = min(candidates, key=lambda d: distance(det_center(d), locked_center))
    if distance(det_center(nearest), locked_center) <= args.association_radius:
        new_center = smooth_point(locked_center, det_center(nearest), args.position_alpha)
        return nearest, new_center, 0

    missing_count += 1
    if missing_count >= args.lost_frames:
        return None, None, 0
    return None, locked_center, missing_count


def select_locked_detection(detections, name, locked_center, missing_count, association_radius, lost_frames, position_alpha):
    if name is None or locked_center is None:
        return None, locked_center, missing_count

    candidates = [d for d in detections if d.get("name") == name and det_center(d) is not None]
    if not candidates:
        missing_count += 1
        if missing_count >= lost_frames:
            return None, None, 0
        return None, locked_center, missing_count

    nearest = min(candidates, key=lambda d: distance(det_center(d), locked_center))
    if distance(det_center(nearest), locked_center) <= association_radius:
        return nearest, smooth_point(locked_center, det_center(nearest), position_alpha), 0

    missing_count += 1
    if missing_count >= lost_frames:
        return None, None, 0
    return None, locked_center, missing_count


def is_same_selected_detection(det, selected_name, selected_center, association_radius):
    if selected_name is None or selected_center is None:
        return False
    c = det_center(det)
    return det.get("name") == selected_name and c is not None and distance(c, selected_center) <= association_radius


# =============================
# Informed RRT* planner
# =============================
@dataclass
class Obstacle:
    center: tuple
    radius: float
    name: str = "obstacle"
    target_near: bool = False

@dataclass
class Node:
    point: tuple
    parent: int
    cost: float


class InformedRRTStarPlanner:
    def __init__(self, bounds, obstacles, step_size, goal_sample_rate, max_iter, search_radius, rng_seed=None):
        self.bounds = bounds  # (xmin, ymin, xmax, ymax)
        self.obstacles = obstacles
        self.step_size = float(step_size)
        self.goal_sample_rate = float(goal_sample_rate)
        self.max_iter = int(max_iter)
        self.search_radius = float(search_radius)
        self.rng = random.Random(rng_seed)

    def in_bounds(self, p):
        xmin, ymin, xmax, ymax = self.bounds
        return xmin <= p[0] <= xmax and ymin <= p[1] <= ymax

    def collision_free_point(self, p):
        if not self.in_bounds(p):
            return False
        for obs in self.obstacles:
            if distance(p, obs.center) <= obs.radius:
                return False
        return True

    def collision_free_segment(self, a, b):
        if not self.in_bounds(a) or not self.in_bounds(b):
            return False
        for obs in self.obstacles:
            if segment_intersects_circle(a, b, obs.center, obs.radius):
                return False
        return True

    def sample_uniform(self, goal):
        if self.rng.random() < self.goal_sample_rate:
            return goal
        xmin, ymin, xmax, ymax = self.bounds
        return (self.rng.uniform(xmin, xmax), self.rng.uniform(ymin, ymax))

    def sample_informed(self, start, goal, c_best):
        c_min = distance(start, goal)
        if not math.isfinite(c_best) or c_best <= c_min + 1e-9:
            return self.sample_uniform(goal)

        center = ((start[0] + goal[0]) * 0.5, (start[1] + goal[1]) * 0.5)
        theta = math.atan2(goal[1] - start[1], goal[0] - start[0])
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        a = c_best * 0.5
        b_sq = max(c_best * c_best - c_min * c_min, 0.0)
        b = math.sqrt(b_sq) * 0.5

        for _ in range(100):
            # Uniform sample inside unit disk.
            r = math.sqrt(self.rng.random())
            ang = self.rng.uniform(0.0, 2.0 * math.pi)
            lx = a * r * math.cos(ang)
            ly = b * r * math.sin(ang)
            x = center[0] + cos_t * lx - sin_t * ly
            y = center[1] + sin_t * lx + cos_t * ly
            p = (x, y)
            if self.in_bounds(p):
                return p
        return self.sample_uniform(goal)

    def steer(self, from_point, to_point):
        d = distance(from_point, to_point)
        if d <= self.step_size:
            return to_point
        ratio = self.step_size / max(d, 1e-9)
        return (from_point[0] + (to_point[0] - from_point[0]) * ratio,
                from_point[1] + (to_point[1] - from_point[1]) * ratio)

    def nearest_index(self, nodes, point):
        return min(range(len(nodes)), key=lambda i: distance(nodes[i].point, point))

    def near_indices(self, nodes, point):
        n = max(len(nodes), 2)
        radius = self.search_radius * math.sqrt(math.log(n) / n)
        radius = max(radius, self.step_size * 2.0)
        return [i for i, node in enumerate(nodes) if distance(node.point, point) <= radius]

    def reconstruct_path(self, nodes, goal_index):
        path = []
        idx = goal_index
        while idx >= 0:
            path.append(nodes[idx].point)
            idx = nodes[idx].parent
        path.reverse()
        return path

    def plan(self, start, goal):
        start = (float(start[0]), float(start[1]))
        goal = (float(goal[0]), float(goal[1]))

        if not self.collision_free_point(start):
            return None
        if not self.collision_free_point(goal):
            return None

        # If straight line is already safe, keep it. This is useful in sparse scenes.
        if self.collision_free_segment(start, goal):
            return [start, goal]

        nodes = [Node(start, -1, 0.0)]
        best_goal_index = None
        c_best = float("inf")

        for _ in range(self.max_iter):
            sample = self.sample_informed(start, goal, c_best)
            nearest_idx = self.nearest_index(nodes, sample)
            new_point = self.steer(nodes[nearest_idx].point, sample)
            if not self.collision_free_point(new_point):
                continue
            if not self.collision_free_segment(nodes[nearest_idx].point, new_point):
                continue

            near = self.near_indices(nodes, new_point)
            best_parent = nearest_idx
            best_cost = nodes[nearest_idx].cost + distance(nodes[nearest_idx].point, new_point)

            for idx in near:
                candidate_cost = nodes[idx].cost + distance(nodes[idx].point, new_point)
                if candidate_cost < best_cost and self.collision_free_segment(nodes[idx].point, new_point):
                    best_parent = idx
                    best_cost = candidate_cost

            new_index = len(nodes)
            nodes.append(Node(new_point, best_parent, best_cost))

            # Rewire nearby nodes through the new node when it is cheaper.
            for idx in near:
                if idx == best_parent:
                    continue
                rewired_cost = best_cost + distance(new_point, nodes[idx].point)
                if rewired_cost < nodes[idx].cost and self.collision_free_segment(new_point, nodes[idx].point):
                    nodes[idx].parent = new_index
                    nodes[idx].cost = rewired_cost

            # Try connecting to the goal.
            if distance(new_point, goal) <= self.step_size * 1.5 and self.collision_free_segment(new_point, goal):
                goal_cost = best_cost + distance(new_point, goal)
                if goal_cost < c_best:
                    best_goal_index = len(nodes)
                    nodes.append(Node(goal, new_index, goal_cost))
                    c_best = goal_cost

        if best_goal_index is None:
            return None
        return self.reconstruct_path(nodes, best_goal_index)


def path_length(path):
    if not path or len(path) < 2:
        return 0.0
    return sum(distance(path[i], path[i + 1]) for i in range(len(path) - 1))


def shortcut_smooth_path(path, obstacles, bounds, attempts=80, rng_seed=None):
    if path is None or len(path) <= 2:
        return path
    rng = random.Random(rng_seed)

    def free(a, b):
        xmin, ymin, xmax, ymax = bounds
        if not (xmin <= a[0] <= xmax and ymin <= a[1] <= ymax and xmin <= b[0] <= xmax and ymin <= b[1] <= ymax):
            return False
        return not any(segment_intersects_circle(a, b, obs.center, obs.radius) for obs in obstacles)

    new_path = list(path)
    for _ in range(attempts):
        if len(new_path) <= 2:
            break
        i = rng.randint(0, len(new_path) - 3)
        j = rng.randint(i + 2, len(new_path) - 1)
        if free(new_path[i], new_path[j]):
            new_path = new_path[: i + 1] + new_path[j:]
    return new_path


def make_obstacles(detections, selected_source_name, source_center, selected_target_name, target_center,
                   association_radius, moving_radius, safety_margin, default_radius, exclude_source, exclude_target,
                   target_near_center=None, target_near_radius=0.0, target_near_safety_margin=None,
                   target_near_max_radius=None):

    selected_exclude_radius = min(float(association_radius), 55.0)

    droplets = []
    for det in detections:
        if not is_droplet(det):
            continue
        center = det_center(det)
        if center is None:
            continue
        base_radius = det_radius(det, default_radius)
        droplets.append((det, center, base_radius))

    excluded_indices = set()

    def exclude_nearest_selected(selected_name, selected_center):
        if selected_name is None or selected_center is None:
            return None

        candidates = []
        for idx, (det, center, _) in enumerate(droplets):
            if idx in excluded_indices:
                continue
            if det.get("name") != selected_name:
                continue
            d = distance(center, selected_center)
            if d <= selected_exclude_radius:
                candidates.append((d, idx))

        if not candidates:
            return None

        _, best_idx = min(candidates, key=lambda item: item[0])
        excluded_indices.add(best_idx)
        return best_idx

    if exclude_source:
        exclude_nearest_selected(selected_source_name, source_center)
    if exclude_target:
        exclude_nearest_selected(selected_target_name, target_center)

    obstacles = []
    for idx, (det, center, base_radius) in enumerate(droplets):
        if idx in excluded_indices:
            continue
        local_safety_margin = float(safety_margin)
        local_max_radius = None
        if (
            target_near_center is not None
            and target_near_safety_margin is not None
            and float(target_near_radius or 0.0) > 0.0
            and distance(center, target_near_center) <= float(target_near_radius)
        ):
            local_safety_margin = float(target_near_safety_margin)
            if target_near_max_radius is not None:
                local_max_radius = max(1.0, float(target_near_max_radius))

        is_target_near = local_max_radius is not None  # 只有 target-near 分支才会设 local_max_radius
        expanded_radius = base_radius + moving_radius + local_safety_margin
        if local_max_radius is not None:
            expanded_radius = min(float(expanded_radius), local_max_radius)
        obstacles.append(Obstacle(center=center, radius=expanded_radius, name=det.get("name", "droplet"),
                                  target_near=is_target_near))

    return obstacles


def soften_endpoint_blockers(obstacles, start, goal, args, start_soft_radius=None, goal_soft_radius=None):

    default_soft_radius = max(10.0, float(getattr(args, "rrt_endpoint_soft_radius", 120.0)))
    start_soft_radius = default_soft_radius if start_soft_radius is None else max(1.0, float(start_soft_radius))
    goal_soft_radius = default_soft_radius if goal_soft_radius is None else max(1.0, float(goal_soft_radius))
    relaxed = []
    start_relaxed = 0
    goal_relaxed = 0

    for obs in obstacles:
        contains_start = start is not None and distance(start, obs.center) <= obs.radius
        contains_goal = goal is not None and distance(goal, obs.center) <= obs.radius
        if contains_start or contains_goal:

            candidate_radius = float(obs.radius)
            if contains_start:
                candidate_radius = min(candidate_radius, start_soft_radius)
            if contains_goal:
                candidate_radius = min(candidate_radius, goal_soft_radius)
            new_radius = min(float(obs.radius), candidate_radius)
            if new_radius < float(obs.radius):
                if contains_start:
                    start_relaxed += 1
                if contains_goal:
                    goal_relaxed += 1
                relaxed.append(Obstacle(center=obs.center, radius=new_radius, name=obs.name))
                continue
        relaxed.append(obs)

    return relaxed, start_relaxed, goal_relaxed


def plan_with_informed_rrtstar(start, goal, obstacles, frame_shape, args, seed_offset=0, start_soft_radius=None, goal_soft_radius=None):
    h, w = frame_shape[:2]
    bounds = (0.0, 0.0, float(w - 1), float(h - 1))


    final_obstacles, start_relaxed, goal_relaxed = soften_endpoint_blockers(
        obstacles,
        start,
        goal,
        args,
        start_soft_radius=start_soft_radius,
        goal_soft_radius=goal_soft_radius,
    )

    start_blockers = [obs for obs in final_obstacles if distance(start, obs.center) <= obs.radius]
    goal_blockers = [obs for obs in final_obstacles if distance(goal, obs.center) <= obs.radius]


    plan_extra = max(0.0, float(getattr(args, "rrt_plan_extra_clearance", 0.0)))
    planner_obstacles = []
    endpoint_extra_skipped = 0
    for obs in final_obstacles:
        contains_start = distance(start, obs.center) <= obs.radius
        contains_goal = distance(goal, obs.center) <= obs.radius
        if contains_start or contains_goal:
            endpoint_extra_skipped += 1
            planner_obstacles.append(obs)
        elif plan_extra > 0.0 and not obs.target_near:
            planner_obstacles.append(
                Obstacle(center=obs.center, radius=obs.radius + plan_extra, name=obs.name, target_near=False))
        elif plan_extra > 0.0 and obs.target_near:
            planner_obstacles.append(obs)  # target-near 已经用小 margin，不再叠加 extra

    if start_relaxed or goal_relaxed or start_blockers or goal_blockers or plan_extra > 0.0:
        print(
            f"[RRT plan] endpoint softening start_relaxed={start_relaxed}, goal_relaxed={goal_relaxed}, "
            f"remaining_start_blockers={len(start_blockers)}, remaining_goal_blockers={len(goal_blockers)}, "
            f"plan_extra_clearance={plan_extra:.1f}, endpoint_extra_skipped={endpoint_extra_skipped}"
        )

    planner_kwargs = {
        "step_size": args.rrt_step,
        "goal_sample_rate": args.rrt_goal_sample_rate,
        "max_iter": args.rrt_max_iter,
        "search_radius": args.rrt_search_radius,
        "smooth_attempts": args.smooth_attempts,
    }
    base_seed = args.rrt_seed + seed_offset if args.rrt_seed is not None else random.randrange(1, 2**31 - 1)
    if generate_candidate_paths is not None:
        path, _summary = generate_candidate_paths(
            start=start,
            goal=goal,
            obstacles=planner_obstacles,
            bounds=bounds,
            planner_class=InformedRRTStarPlanner,
            planner_kwargs=planner_kwargs,
            shortcut_fn=shortcut_smooth_path,
            candidate_count=getattr(args, "route_candidates", 5),
            seed=base_seed,
            mutation_generations=getattr(args, "path_refine_generations", 2),
            mutation_population=getattr(args, "path_refine_population", 6),
        )
    else:
        planner = InformedRRTStarPlanner(
            bounds=bounds,
            obstacles=planner_obstacles,
            rng_seed=base_seed,
            **{k: v for k, v in planner_kwargs.items() if k != "smooth_attempts"},
        )
        path = planner.plan(start, goal)
    if path is None:
        return None
    return path


# =============================
# Inference worker
# =============================
class LatestDetectionWorker:
    def __init__(self, camera, model, imgsz, conf, device, frame_timeout=0.25, retain_frame=False):
        self.camera = camera
        self.model = model
        self.imgsz = imgsz
        self.conf = conf
        self.device = device

        self.frame_timeout = frame_timeout
        self.retain_frame = bool(retain_frame)
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._latest_packet = None
        self._latest_error = None
        self._closed = False
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        seq = 0
        last_frame_seq = -1
        try:
            while not self._stop_event.is_set():
                try:
                    frame_seq, frame = self.camera.get_frame_with_seq(timeout=self.frame_timeout)
                except TimeoutError:
                    continue

                if frame_seq == last_frame_seq:
                    time.sleep(0.003)
                    continue
                last_frame_seq = frame_seq

                # Diagnostics must use the exact unannotated inference input,
                # not a newer camera frame paired with older boxes.  A live
                # camera is allowed to recycle its capture buffer, so retain
                # an owned copy when the caller requested diagnostics.  The
                # normal control path keeps the packet light and does not
                # copy a full-resolution frame on every inference.
                start = time.perf_counter()
                result = self.model.predict(
                    frame,
                    imgsz=self.imgsz,
                    conf=self.conf,
                    device=self.device,
                    verbose=False,
                )[0]
                packet = {
                    "seq": seq,
                    "timestamp": time.time(),
                    "infer_ms": (time.perf_counter() - start) * 1000.0,
                    "detections": collect_detections(result),
                    "frame_seq": frame_seq,
                    "frame": frame.copy() if self.retain_frame else None,
                }
                seq += 1

                with self._lock:
                    self._latest_packet = packet
                    self._latest_error = None
        except Exception as exc:
            with self._lock:
                self._latest_error = exc

    def get_latest(self):
        with self._lock:
            if self._latest_error is not None:
                raise self._latest_error
            return self._latest_packet

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._stop_event.set()
        if self._thread.is_alive():
            self._thread.join(timeout=2.0)


# =============================
# Minimal state machine
# =============================
def make_control_state(mode=MODE_POINT):
    initial_state = STATE_WAIT_SELECTION if mode == MODE_RRT else STATE_WAIT_DROPLET
    return {
        "route_id": 0,
        "mode": mode,
        "state": initial_state,
        "selected_source_name": None,
        "selected_target_name": None,
        "source_lock_center": None,
        "target_lock_center": None,
        "source_smooth": None,
        "target_smooth": None,
        "target_is_virtual": False,
        "source_radius": 35.0,
        "target_radius": 35.0,
        "source_miss_count": 0,
        "target_miss_count": 0,
        "laser_smooth": None,
        "target_point": None,
        "point_line_start": None,
        "target_line_start": None,
        "home_point": None,
        "route_to_source": [],
        "route_to_target": [],
        "target_route_start_mode": "source",
        "target_route_goal": None,
        "source_wp_index": 1,
        "target_wp_index": 1,
        "route_valid": False,
        "plan_failed": False,
        "last_plan_message": "",
        "obstacles_to_source": [],
        "obstacles_to_target": [],
        "last_replan_time": time.time(),
        "last_replan_success_time": time.time(),
        "replan_block_count": 0,
        "replan_count": 0,
        "direct_clear_count_source": 0,
        "direct_clear_count_target": 0,
        "resume_state": STATE_SEEK_SOURCE,
        "last_replan_retry_time": 0.0,
        "brake_until": 0.0,
        "brake_started": False,
        "selection_ready": False,
        "sequence_points": [],
        "sequence_index": 0,
        "sequence_order_mode": "tsp",
        "sequence_order_cost": 0.0,
        "sequence_points": [],
        "sequence_index": 0,
        "path_points": [],
        "path_index": 0,
        "path_draft": [],
        "drawing_path": False,
        "pd_last_ex": None,
        "pd_last_ey": None,
        "pd_last_time": None,
        "pd_last_state": None,
        "pd_last_route_id": None,
        "pd_last_path_index": None,
        "pd_integral_ex": 0.0,
        "pd_integral_ey": 0.0,
        "rrt_desired_smooth": None,
        "rrt_last_x_speed": 0,
        "rrt_last_y_speed": 0,
        "metrics": {
            "started_at": time.time(),
            "samples": 0,
            "max_error": 0.0,
            "mean_error": 0.0,
            "command_distance": 0.0,
            "completed_routes": 0,
            "last_state": None,
            "trace": [],
        },
        "laser_track_mode": "none",
        "laser_velocity": (0.0, 0.0),
        "laser_predict_count": 0,
        "laser_last_observed": None,
    }


def reset_task(control_state, mode=None):
    old_laser = control_state.get("laser_smooth")
    old_id = control_state.get("route_id", 0)
    old_mode = control_state.get("mode", MODE_POINT)
    old_planner = control_state.get("rrt_planner")
    old_metrics = control_state.get("metrics")
    old_sequence_order_mode = control_state.get("sequence_order_mode", "tsp")
    old_sequence_turn_weight = control_state.get("sequence_turn_weight", 0.0)
    new_mode = mode if mode is not None else old_mode

    control_state.clear()
    control_state.update(make_control_state(new_mode))
    control_state["laser_smooth"] = old_laser
    control_state["route_id"] = old_id + 1

    if old_planner is not None:
        control_state["rrt_planner"] = old_planner
    control_state["rrt_planning_active"] = False
    control_state["rrt_planning_job_id"] = None
    control_state["rrt_planning_kind"] = None
    control_state["rrt_planning_key"] = None
    control_state["sequence_order_mode"] = old_sequence_order_mode
    control_state["sequence_turn_weight"] = old_sequence_turn_weight
    if old_metrics is not None:
        control_state["metrics"] = old_metrics
    reset_pd_state(control_state)


def switch_mode(control_state, mode):
    reset_task(control_state, mode=mode)


def source_is_selected(control_state):
    return control_state.get("selected_source_name") is not None and control_state.get("source_lock_center") is not None


def target_is_selected(control_state):
    return control_state.get("selected_target_name") is not None and control_state.get("target_lock_center") is not None


def rrt_reset_route(control_state):
    reset_task(control_state, mode=MODE_RRT)


def rrt_select_source_from_click(control_state, det, args):
    reset_task(control_state, mode=MODE_RRT)
    center = det_center(det)
    control_state["selected_source_name"] = det.get("name")
    control_state["source_lock_center"] = center
    control_state["source_radius"] = det_radius(det, args.default_droplet_radius)
    control_state["source_smooth"] = smooth_point(None, center, args.position_alpha)
    control_state["source_miss_count"] = 0
    control_state["state"] = STATE_WAIT_SELECTION
    control_state["selection_ready"] = False
    reset_pd_state(control_state)


def rrt_select_target_from_click(control_state, det, args):
    control_state["route_id"] += 1
    control_state["state"] = STATE_WAIT_PLAN
    control_state["selection_ready"] = True
    control_state["selected_target_name"] = det.get("name")
    control_state["target_is_virtual"] = False
    control_state["target_lock_center"] = det_center(det)
    control_state["target_radius"] = det_radius(det, args.default_droplet_radius)
    control_state["target_miss_count"] = 0
    control_state["target_smooth"] = smooth_point(None, det_center(det), args.position_alpha)
    control_state["target_line_start"] = control_state.get("source_smooth") or control_state.get("source_lock_center")
    control_state["route_to_source"] = []
    control_state["route_to_target"] = []
    control_state["target_route_start_mode"] = "source"
    control_state["target_route_goal"] = None
    control_state["source_wp_index"] = 1
    control_state["target_wp_index"] = 1
    control_state["route_valid"] = False
    control_state["plan_failed"] = False
    control_state["last_plan_message"] = ""
    reset_pd_state(control_state)


def rrt_select_fixed_target(control_state, point, source_det, args):
    """Prepare RRT* control for a planner-chosen fixed landing coordinate."""
    x, y = float(point[0]), float(point[1])
    control_state["route_id"] += 1
    control_state["mode"] = MODE_RRT
    control_state["state"] = STATE_WAIT_PLAN
    control_state["selection_ready"] = True
    control_state["selected_target_name"] = "__fixed_goal__"
    control_state["target_is_virtual"] = True
    control_state["target_lock_center"] = (x, y)
    control_state["target_smooth"] = (x, y)
    control_state["target_radius"] = max(2.0, float(control_state.get("source_radius", args.default_droplet_radius)))
    control_state["target_miss_count"] = 0
    control_state["target_line_start"] = control_state.get("source_smooth") or control_state.get("source_lock_center")
    control_state["route_to_source"] = []
    control_state["route_to_target"] = []
    control_state["target_route_start_mode"] = "source"
    control_state["target_route_goal"] = None
    control_state["source_wp_index"] = 1
    control_state["target_wp_index"] = 1
    control_state["route_valid"] = False
    control_state["plan_failed"] = False
    control_state["last_plan_message"] = ""
    control_state["replan_count"] = 0
    control_state["replan_block_count"] = 0
    control_state["rrt_planning_active"] = False
    control_state["rrt_planning_job_id"] = None
    control_state["rrt_planning_kind"] = None
    control_state["rrt_planning_key"] = None
    reset_pd_state(control_state)


def select_source_from_click(control_state, det, args):
    mode = control_state.get("mode", MODE_POINT)
    reset_task(control_state, mode=mode)
    center = det_center(det)
    control_state["selected_source_name"] = det.get("name")
    control_state["source_lock_center"] = center
    control_state["source_smooth"] = smooth_point(None, center, args.position_alpha)
    control_state["source_miss_count"] = 0
    # Remember the first selected droplet position. RESET uses this fixed point.
    control_state["home_point"] = center
    control_state["state"] = STATE_WAIT_TARGET if mode == MODE_POINT else STATE_WAIT_PATH


def return_laser_to_home(control_state):
    """Command the laser to return to the initially selected droplet position."""
    home = control_state.get("home_point")
    if home is None:
        return False
    control_state["target_point"] = None
    control_state["drawing_path"] = False
    control_state["state"] = STATE_RETURN_HOME
    control_state["route_id"] += 1
    reset_pd_state(control_state)
    return True


def append_sequence_droplet(control_state, det):
    """Add one clicked droplet center to the MULTI queue."""
    center = det_center(det)
    if center is None:
        return False, 0

    sequence = control_state.setdefault("sequence_points", [])
    was_idle = len(sequence) == 0 or control_state.get("state") not in {STATE_DRAG_TO_SEQUENCE}
    sequence.append((float(center[0]), float(center[1])))

    # Keep the currently approached point stable, then optimize only the
    # unvisited suffix. This allows clicks to be added while the machine is
    # moving without abruptly changing its active target.
    if control_state.get("sequence_order_mode", "tsp") != "click":
        current_index = int(control_state.get("sequence_index", 0))
        prefix_len = 0 if was_idle else min(current_index + 1, len(sequence))
        prefix = sequence[:prefix_len]
        pending = sequence[prefix_len:]
        start = prefix[-1] if prefix else control_state.get("laser_smooth")
        sequence[:] = prefix + optimize_sequence_order(
            pending,
            start=start,
            turn_weight=float(control_state.get("sequence_turn_weight", 0.0)),
            method=control_state.get("sequence_order_mode", "tsp"),
        )
        control_state["sequence_order_cost"] = sequence_route_cost(
            sequence[prefix_len:], start=start,
            turn_weight=float(control_state.get("sequence_turn_weight", 0.0)),
        )

    if was_idle:
        control_state["sequence_index"] = 0
        control_state["state"] = STATE_DRAG_TO_SEQUENCE
        control_state["route_id"] += 1
        reset_pd_state(control_state)

    return True, len(sequence)


def reorder_pending_sequence(control_state, start_point=None):
    """Recompute the remaining MULTI route after a target is reached."""
    sequence = control_state.get("sequence_points", [])
    index = int(control_state.get("sequence_index", 0))
    if len(sequence) - index <= 1 or control_state.get("sequence_order_mode", "tsp") == "click":
        return
    prefix = sequence[:index + 1]
    pending = sequence[index + 1:]
    start = start_point or prefix[-1]
    optimized = optimize_sequence_order(
        pending,
        start=start,
        turn_weight=float(control_state.get("sequence_turn_weight", 0.0)),
        method=control_state.get("sequence_order_mode", "tsp"),
    )
    control_state["sequence_points"] = prefix + optimized
    control_state["sequence_order_cost"] = sequence_route_cost(
        optimized, start=start,
        turn_weight=float(control_state.get("sequence_turn_weight", 0.0)),
    )


def select_target_from_click(control_state, point):
    control_state["target_point"] = (float(point[0]), float(point[1]))
    # The final line start is refreshed when the laser actually reaches the
    # droplet. This fallback still gives a valid line immediately after clicking.
    control_state["point_line_start"] = control_state.get("source_smooth") or control_state.get("source_lock_center")
    control_state["state"] = STATE_SEEK_DROPLET
    control_state["route_id"] += 1
    reset_pd_state(control_state)


def start_path_drawing(control_state, point):
    control_state["target_point"] = None
    control_state["path_points"] = []
    control_state["path_index"] = 0
    control_state["path_draft"] = [(float(point[0]), float(point[1]))]
    control_state["drawing_path"] = True
    control_state["state"] = STATE_DRAW_PATH
    control_state["route_id"] += 1


def append_path_drawing(control_state, point, min_step):
    if not control_state.get("drawing_path"):
        return False
    draft = control_state.setdefault("path_draft", [])
    current = (float(point[0]), float(point[1]))
    if not draft or distance(draft[-1], current) >= min_step:
        draft.append(current)
        return True
    return False


def finish_path_drawing(control_state, args):
    if not control_state.get("drawing_path"):
        return False

    draft = compact_path(control_state.get("path_draft", []), args.path_draw_min_step)
    control_state["drawing_path"] = False

    if len(draft) < 2 or path_total_length(draft) < args.min_path_length:
        control_state["path_points"] = []
        control_state["path_index"] = 0
        control_state["path_draft"] = draft
        control_state["state"] = STATE_WAIT_PATH
        return False

    path_points = resample_path(draft, args.path_point_spacing)
    control_state["path_points"] = path_points
    control_state["path_index"] = 0
    control_state["path_draft"] = draft
    control_state["state"] = STATE_SEEK_DROPLET
    control_state["route_id"] += 1
    return True


def enter_wait_replan(control_state, resume_state, message, now=None):

    control_state["route_valid"] = False
    control_state["plan_failed"] = False
    control_state["state"] = STATE_WAIT_REPLAN
    control_state["resume_state"] = resume_state
    control_state["replan_block_count"] = 0
    control_state["last_plan_message"] = message
    control_state["route_id"] += 1
    if now is None:
        now = time.time()
    control_state["last_replan_retry_time"] = now
    # Reset this every time we enter WAIT_REPLAN.  Otherwise an old wait window
    # can make a later second-droplet replan time out immediately.
    control_state["first_replan_entry_time"] = now
    reset_pd_state(control_state)
    print(message)


def attempt_wait_replan(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth, now):
    stuck_timeout = getattr(args, "replan_stuck_timeout", 2.5)
    first_replan_time = control_state.get("first_replan_entry_time", now)
    control_state.setdefault("first_replan_entry_time", now)
    if now - first_replan_time > stuck_timeout:
        control_state["state"] = STATE_PLAN_FAILED
        control_state["plan_failed"] = True
        control_state["last_plan_message"] = "replan timed out — please reselect"
        return False
    if control_state.get("state") != STATE_WAIT_REPLAN:
        return False
    if laser_smooth is None or source_smooth is None or target_smooth is None:
        return False
    if control_state.get("rrt_planning_active"):
        return False

    last_retry = control_state.get("last_replan_retry_time", 0.0)
    if now - last_retry < args.replan_retry_interval:
        return False
    control_state["last_replan_retry_time"] = now

    selected_source_name = control_state["selected_source_name"]
    selected_target_name = control_state["selected_target_name"]
    resume_state = control_state.get("resume_state", STATE_MOVE_TO_TARGET)
    replan_count = int(control_state.get("replan_count", 0))

    if resume_state == STATE_SEEK_SOURCE:
        obstacles = make_obstacles(
            detections=detections,
            selected_source_name=selected_source_name,
            source_center=source_smooth,
            selected_target_name=selected_target_name,
            target_center=target_smooth,
            association_radius=args.association_radius,
            moving_radius=args.laser_radius,
            safety_margin=args.safety_margin,
            default_radius=args.default_droplet_radius,
            exclude_source=True,
            exclude_target=False,
        )
        control_state["obstacles_to_source"] = obstacles
        submit_rrt_plan(
            control_state,
            "wait_replan_source",
            {
                "args": args,
                "frame_shape": frame_shape,
                "laser_smooth": laser_smooth,
                "source_smooth": source_smooth,
                "target_smooth": target_smooth,
                "obstacles": obstacles,
                "seed_offset": 3000 + replan_count,
                "replan_count": replan_count,
                "resume_state": STATE_SEEK_SOURCE,
            },
            "queued retry: laser->source planning in background",
        )
        return False

    source_radius = control_state.get("source_radius", args.default_droplet_radius)
    obstacles = make_obstacles(
        detections=detections,
        selected_source_name=selected_source_name,
        source_center=source_smooth,
        selected_target_name=selected_target_name,
        target_center=target_smooth,
        association_radius=args.association_radius,
        moving_radius=source_radius,
        safety_margin=args.safety_margin,
        default_radius=args.default_droplet_radius,
        exclude_source=True,
        exclude_target=True,
        **target_near_obstacle_kwargs(args, target_smooth, use_hard=False),
    )
    control_state["obstacles_to_target"] = obstacles
    submit_rrt_plan(
        control_state,
        "wait_replan_target",
        {
            "args": args,
            "frame_shape": frame_shape,
            "laser_smooth": laser_smooth,
            "source_smooth": source_smooth,
            "target_smooth": target_smooth,
            "obstacles": obstacles,
            "seed_offset": 4000 + replan_count,
            "replan_count": replan_count,
            "resume_state": STATE_MOVE_TO_TARGET,
        },
        "queued retry: laser->target planning in background",
    )
    return False

def ensure_route_planned(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth):
    if control_state.get("state") == STATE_WAIT_REPLAN:
        return
    if control_state.get("route_valid") or control_state.get("plan_failed"):
        return
    if control_state.get("rrt_planning_active"):
        control_state["state"] = STATE_WAIT_PLAN
        return
    if laser_smooth is None or source_smooth is None or target_smooth is None:
        control_state["state"] = STATE_WAIT_PLAN
        return

    selected_source_name = control_state["selected_source_name"]
    selected_target_name = control_state["selected_target_name"]
    source_radius = control_state["source_radius"]

    obstacles_to_source = make_obstacles(
        detections=detections,
        selected_source_name=selected_source_name,
        source_center=source_smooth,
        selected_target_name=selected_target_name,
        target_center=target_smooth,
        association_radius=args.association_radius,
        moving_radius=args.laser_radius,
        safety_margin=args.safety_margin,
        default_radius=args.default_droplet_radius,
        exclude_source=True,
        exclude_target=False,
    )

    obstacles_to_target = make_obstacles(
        detections=detections,
        selected_source_name=selected_source_name,
        source_center=source_smooth,
        selected_target_name=selected_target_name,
        target_center=target_smooth,
        association_radius=args.association_radius,
        moving_radius=source_radius,
        safety_margin=args.safety_margin,
        default_radius=args.default_droplet_radius,
        exclude_source=True,
        exclude_target=True,
        **target_near_obstacle_kwargs(args, target_smooth, use_hard=False),
    )

    control_state["state"] = STATE_WAIT_PLAN
    control_state["obstacles_to_source"] = obstacles_to_source
    control_state["obstacles_to_target"] = obstacles_to_target
    submit_rrt_plan(
        control_state,
        "initial",
        {
            "args": args,
            "frame_shape": frame_shape,
            "laser_smooth": laser_smooth,
            "source_smooth": source_smooth,
            "target_smooth": target_smooth,
            "obstacles_to_source": obstacles_to_source,
            "obstacles_to_target": obstacles_to_target,
            "resume_state": STATE_SEEK_SOURCE,
        },
        "queued initial RRT planning in background",
    )

def plan_target_route_from_laser(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth, seed_offset=20):

    if laser_smooth is None or source_smooth is None or target_smooth is None:
        return False
    if control_state.get("rrt_planning_active"):
        return False

    selected_source_name = control_state["selected_source_name"]
    selected_target_name = control_state["selected_target_name"]
    source_radius = control_state.get("source_radius", args.default_droplet_radius)

    obstacles_to_target = make_obstacles(
        detections=detections,
        selected_source_name=selected_source_name,
        source_center=source_smooth,
        selected_target_name=selected_target_name,
        target_center=target_smooth,
        association_radius=args.association_radius,
        moving_radius=source_radius,
        safety_margin=args.safety_margin,
        default_radius=args.default_droplet_radius,
        exclude_source=True,
        exclude_target=True,
        **target_near_obstacle_kwargs(args, target_smooth, use_hard=False),
    )

    control_state["obstacles_to_target"] = obstacles_to_target
    control_state["route_valid"] = False
    control_state["state"] = STATE_WAIT_PLAN
    control_state["resume_state"] = STATE_MOVE_TO_TARGET
    control_state["target_route_start_mode"] = "planning_laser"
    submit_rrt_plan(
        control_state,
        "target_from_laser",
        {
            "args": args,
            "frame_shape": frame_shape,
            "laser_smooth": laser_smooth,
            "source_smooth": source_smooth,
            "target_smooth": target_smooth,
            "obstacles": obstacles_to_target,
            "seed_offset": seed_offset,
            "replan_count": int(control_state.get("replan_count", 0)),
            "resume_state": STATE_MOVE_TO_TARGET,
        },
        "queued second-stage laser->target planning in background",
    )
    return False

def inflate_obstacles(obstacles, extra_radius):
    if extra_radius <= 0:
        return list(obstacles)
    return [Obstacle(center=obs.center, radius=obs.radius + extra_radius, name=obs.name) for obs in obstacles]


def target_endpoint_soft_radius(args):

    return max(1.0, float(getattr(args, "rrt_target_endpoint_soft_radius", 38.0)))


def target_near_obstacle_kwargs(args, target_smooth, use_hard=False):

    if target_smooth is None:
        return {}
    zone_radius = max(0.0, float(getattr(args, "rrt_target_near_zone_radius", 0.0)))
    if zone_radius <= 0.0:
        return {}
    if use_hard:
        margin = max(0.0, float(getattr(args, "rrt_target_near_hard_safety_margin", getattr(args, "hard_safety_margin", 40.0))))
        max_radius = getattr(args, "rrt_target_near_hard_max_radius", None)
    else:
        margin = max(0.0, float(getattr(args, "rrt_target_near_safety_margin", getattr(args, "safety_margin", 300.0))))
        max_radius = getattr(args, "rrt_target_near_max_radius", None)
    return {
        "target_near_center": target_smooth,
        "target_near_radius": zone_radius,
        "target_near_safety_margin": margin,
        "target_near_max_radius": max_radius,
    }


def target_approach_radius(args):

    arrive = max(5.0, float(getattr(args, "rrt_target_arrive_dist", RRT_TARGET_ARRIVE_DIST)))
    ratio = clamp(float(getattr(args, "rrt_target_approach_ratio", 0.85)), 0.25, 0.98)
    return max(5.0, arrive * ratio)


def generate_target_approach_goals(start, target, obstacles, frame_shape, args):

    if start is None or target is None:
        return []

    h, w = frame_shape[:2]
    xmin, ymin, xmax, ymax = 0.0, 0.0, float(w - 1), float(h - 1)
    tx, ty = float(target[0]), float(target[1])
    radius = target_approach_radius(args)

    # Prefer the side opposite the nearest obstacle that threatens the target.
    base_angles = []
    target_blockers = []
    for obs in obstacles or []:
        d = distance(target, obs.center)
        if d <= float(obs.radius) + radius + 20.0:
            target_blockers.append((d, obs))
    if target_blockers:
        _, nearest = min(target_blockers, key=lambda item: item[0])
        # Direction from blocker to target, i.e. away from the blocker.
        base_angles.append(math.atan2(ty - nearest.center[1], tx - nearest.center[0]))

    # Also try the side facing the current laser, then a full ring.
    base_angles.append(math.atan2(float(start[1]) - ty, float(start[0]) - tx))
    samples = int(max(8, getattr(args, "rrt_target_approach_samples", 16)))
    for i in range(samples):
        base_angles.append(2.0 * math.pi * i / samples)

    candidates = []
    seen = set()
    # Try a few radii inside the arrival circle.
    for r in [radius, radius * 0.75, radius * 0.50]:
        for ang in base_angles:
            x = tx + r * math.cos(ang)
            y = ty + r * math.sin(ang)
            if not (xmin <= x <= xmax and ymin <= y <= ymax):
                continue
            key = (round(x, 1), round(y, 1))
            if key in seen:
                continue
            seen.add(key)
            point = (x, y)
            inside = False
            near_zone = max(0.0, float(getattr(args, "rrt_target_near_zone_radius", 0.0)))
            approach_clearance = max(5.0, float(getattr(args, "rrt_target_approach_clearance", 65.0)))
            for obs in obstacles or []:
                obs_dist_to_target = distance(obs.center, target)
                check_radius = float(obs.radius)
                if near_zone > 0.0 and obs_dist_to_target <= near_zone:
                    check_radius = min(check_radius, approach_clearance)
                if distance(point, obs.center) <= check_radius:
                    inside = True
                    break
            if inside:
                continue
            candidates.append(point)

    # Sort by how easy they should be to reach from the current laser.
    candidates.sort(key=lambda p: distance(start, p))
    return candidates


def plan_target_route_with_approach_fallback(start, target, obstacles, frame_shape, args, seed_offset=0):
    route = plan_with_informed_rrtstar(
        start=start,
        goal=target,
        obstacles=obstacles,
        frame_shape=frame_shape,
        args=args,
        seed_offset=seed_offset,
        goal_soft_radius=target_endpoint_soft_radius(args),
    )
    if route is not None:
        return route, target, False

    for idx, goal in enumerate(generate_target_approach_goals(start, target, obstacles, frame_shape, args)):
        route = plan_with_informed_rrtstar(
            start=start,
            goal=goal,
            obstacles=obstacles,
            frame_shape=frame_shape,
            args=args,
            seed_offset=seed_offset + 101 + idx,
            goal_soft_radius=max(1.0, target_endpoint_soft_radius(args)),
        )
        if route is not None:
            print(
                f"[RRT target fallback] center blocked, using approach goal "
                f"dist_to_target={distance(goal, target):.1f}px"
            )
            return route, goal, True

    return None, target, False



# =============================
# Asynchronous RRT planning
# =============================
class RRTPlanningWorker:

    def __init__(self):
        self._lock = threading.Lock()
        self._has_job = threading.Event()
        self._stop_event = threading.Event()
        self._pending_job = None
        self._running_key = None
        self._running_job_id = None
        self._latest_result = None
        self._next_job_id = 1
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def submit(self, kind, route_id, payload, key=None):
        if key is None:
            key = (kind, route_id)
        with self._lock:
            if self._running_key == key:
                return self._running_job_id, False
            if self._pending_job is not None and self._pending_job.get("key") == key:
                return self._pending_job.get("job_id"), False

            job_id = self._next_job_id
            self._next_job_id += 1
            self._pending_job = {
                "job_id": job_id,
                "kind": kind,
                "route_id": route_id,
                "payload": payload,
                "key": key,
                "submitted_at": time.time(),
            }
            self._has_job.set()
            return job_id, True

    def poll(self):
        with self._lock:
            result = self._latest_result
            self._latest_result = None
            return result

    def close(self):
        self._stop_event.set()
        self._has_job.set()
        if self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _run(self):
        while not self._stop_event.is_set():
            self._has_job.wait(timeout=0.1)
            if self._stop_event.is_set():
                break

            with self._lock:
                job = self._pending_job
                self._pending_job = None
                if self._pending_job is None:
                    self._has_job.clear()
                if job is None:
                    continue
                self._running_key = job.get("key")
                self._running_job_id = job.get("job_id")

            try:
                result = self._execute(job)
            except Exception as exc:
                result = {
                    "job_id": job.get("job_id"),
                    "kind": job.get("kind"),
                    "route_id": job.get("route_id"),
                    "ok": False,
                    "error": repr(exc),
                }

            result["job_id"] = job.get("job_id")
            result["kind"] = job.get("kind")
            result["route_id"] = job.get("route_id")
            result["finished_at"] = time.time()

            with self._lock:
                self._latest_result = result
                self._running_key = None
                self._running_job_id = None
                if self._pending_job is not None:
                    self._has_job.set()

    def _execute(self, job):
        kind = job["kind"]
        p = job["payload"]
        args = p["args"]
        frame_shape = p["frame_shape"]

        if kind == "initial":
            route_to_source = plan_with_informed_rrtstar(
                start=p["laser_smooth"],
                goal=p["source_smooth"],
                obstacles=p["obstacles_to_source"],
                frame_shape=frame_shape,
                args=args,
                seed_offset=1,
            )
            route_to_target = None
            if route_to_source is not None:
                route_to_target = plan_with_informed_rrtstar(
                    start=p["source_smooth"],
                    goal=p["target_smooth"],
                    obstacles=p["obstacles_to_target"],
                    frame_shape=frame_shape,
                    args=args,
                    seed_offset=2,
                    goal_soft_radius=target_endpoint_soft_radius(args),
                )
            return {
                "ok": True,
                "route_to_source": route_to_source,
                "route_to_target": route_to_target,
                "obstacles_to_source": p["obstacles_to_source"],
                "obstacles_to_target": p["obstacles_to_target"],
            }

        if kind in {"target_from_laser", "wait_replan_target", "dynamic_target"}:
            route, target_route_goal, used_target_fallback = plan_target_route_with_approach_fallback(
                start=p["laser_smooth"],
                target=p["target_smooth"],
                obstacles=p["obstacles"],
                frame_shape=frame_shape,
                args=args,
                seed_offset=p.get("seed_offset", 20),
            )
            return {
                "ok": True,
                "route": route,
                "target_route_goal": target_route_goal,
                "used_target_fallback": used_target_fallback,
                "obstacles": p["obstacles"],
                "blocked_by": p.get("blocked_by"),
                "replan_count": p.get("replan_count", 0),
            }

        if kind in {"wait_replan_source", "dynamic_source"}:
            route = plan_with_informed_rrtstar(
                start=p["laser_smooth"],
                goal=p["source_smooth"],
                obstacles=p["obstacles"],
                frame_shape=frame_shape,
                args=args,
                seed_offset=p.get("seed_offset", 1000),
            )
            return {
                "ok": True,
                "route": route,
                "obstacles": p["obstacles"],
                "blocked_by": p.get("blocked_by"),
                "replan_count": p.get("replan_count", 0),
            }

        return {"ok": False, "error": f"unknown RRT planning job kind: {kind}"}


def get_rrt_planner(control_state):
    planner = control_state.get("rrt_planner")
    if planner is None:
        planner = RRTPlanningWorker()
        control_state["rrt_planner"] = planner
    return planner


def submit_rrt_plan(control_state, kind, payload, message=None):
    planner = get_rrt_planner(control_state)
    route_id = control_state.get("route_id", 0)
    key = (kind, route_id, payload.get("resume_state"), payload.get("seed_offset"))
    job_id, submitted = planner.submit(kind, route_id, payload, key=key)
    if submitted:
        control_state["rrt_planning_active"] = True
        control_state["rrt_planning_job_id"] = job_id
        control_state["rrt_planning_kind"] = kind
        control_state["rrt_planning_key"] = key
        control_state["rrt_planning_start_time"] = time.time()
        if message:
            control_state["last_plan_message"] = message
            print(message)
    return submitted


def consume_rrt_planning_result(detections, frame_shape, args, control_state,
                                laser_smooth, source_smooth, target_smooth, now):
    planner = control_state.get("rrt_planner")
    if planner is None:
        return False

    result = planner.poll()
    if result is None:
        return False

    active_job_id = control_state.get("rrt_planning_job_id")
    if result.get("job_id") != active_job_id or result.get("route_id") != control_state.get("route_id"):

        return False

    control_state["rrt_planning_active"] = False
    control_state["rrt_planning_job_id"] = None
    control_state["rrt_planning_kind"] = None
    control_state["rrt_planning_key"] = None

    kind = result.get("kind")
    if not result.get("ok", False):
        control_state["last_plan_message"] = f"background RRT planning error: {result.get('error')}"
        print(control_state["last_plan_message"])
        if control_state.get("state") not in {STATE_WAIT_REPLAN, STATE_WAIT_PLAN}:
            control_state["plan_failed"] = True
            control_state["route_valid"] = False
            control_state["state"] = STATE_PLAN_FAILED
        return True

    if kind == "initial":
        route_to_source = result.get("route_to_source")
        route_to_target = result.get("route_to_target") or []
        obstacles_to_source = result.get("obstacles_to_source", [])
        obstacles_to_target = result.get("obstacles_to_target", [])

        if route_to_source is None:
            control_state["plan_failed"] = True
            control_state["state"] = STATE_PLAN_FAILED
            control_state["last_plan_message"] = "laser->source planning failed"
            print(control_state["last_plan_message"])
            return True

        if not accept_rrt_route_or_wait(
            route_to_source,
            detections,
            frame_shape,
            args,
            control_state,
            laser_smooth,
            source_smooth,
            target_smooth,
            STATE_SEEK_SOURCE,
            "initial laser->source",
            now,
        ):
            return True

        if route_to_target:
            preview_hard_obstacles = make_hard_obstacles_for_phase(
                detections=detections,
                args=args,
                control_state=control_state,
                source_smooth=source_smooth,
                target_smooth=target_smooth,
                phase=STATE_MOVE_TO_TARGET,
            )
            preview_goal_ignore, preview_goal_ignore_radius = phase_goal_ignore_center_and_radius(
                args,
                STATE_MOVE_TO_TARGET,
                source_smooth,
                target_smooth,
            )
            preview_ok, preview_bad_obs = validate_route_against_obstacles(
                route_to_target,
                preview_hard_obstacles,
                args,
                label="initial source->target preview",
                ignore_goal=preview_goal_ignore,
                ignore_goal_radius=preview_goal_ignore_radius,
            )
            if not preview_ok:
                route_to_target = []
                print(
                    "initial source->target preview rejected "
                    f"({preview_bad_obs.name if preview_bad_obs else 'obstacle'}); "
                    "will replan laser->target at second stage"
                )
        else:
            print("initial source->target preview planning failed; will plan laser->target at second stage")

        control_state["route_to_source"] = route_to_source
        control_state["route_to_target"] = route_to_target
        control_state["source_wp_index"] = 1 if len(route_to_source) > 1 else 0
        control_state["target_wp_index"] = 1 if len(route_to_target) > 1 else 0
        control_state["route_valid"] = True
        control_state["plan_failed"] = False
        control_state["state"] = STATE_SEEK_SOURCE
        control_state["obstacles_to_source"] = obstacles_to_source
        control_state["obstacles_to_target"] = obstacles_to_target
        control_state["last_plan_message"] = (
            f"planned async: laser->source {len(route_to_source)} pts, "
            f"initial source->target preview {len(route_to_target)} pts, "
            f"length={path_length(route_to_source)+path_length(route_to_target):.1f}px"
        )
        reset_pd_state(control_state)
        print(control_state["last_plan_message"])
        return True

    if kind in {"target_from_laser", "wait_replan_target", "dynamic_target"}:
        route = result.get("route")
        target_route_goal = result.get("target_route_goal") or target_smooth
        used_target_fallback = bool(result.get("used_target_fallback", False))
        obstacles = result.get("obstacles", [])
        replan_count = int(result.get("replan_count", control_state.get("replan_count", 0)))
        blocked_by = result.get("blocked_by") or "obstacle"
        control_state["obstacles_to_target"] = obstacles

        if route is None:
            if kind == "target_from_laser":
                if getattr(args, "enable_replan", False):
                    enter_wait_replan(control_state, STATE_MOVE_TO_TARGET, "laser->target planning failed; waiting and retrying", now)
                else:
                    control_state["plan_failed"] = True
                    control_state["route_valid"] = False
                    control_state["state"] = STATE_PLAN_FAILED
                    control_state["last_plan_message"] = "laser->target planning failed"
                    print(control_state["last_plan_message"])
            else:
                control_state["last_plan_message"] = "waiting: retry laser->target planning"
                print(control_state["last_plan_message"])
            return True

        label = (
            "second-stage laser->target" if kind == "target_from_laser"
            else "dynamic laser->target" if kind == "dynamic_target"
            else "retry laser->target"
        )
        if not accept_rrt_route_or_wait(
            route,
            detections,
            frame_shape,
            args,
            control_state,
            laser_smooth,
            source_smooth,
            target_smooth,
            STATE_MOVE_TO_TARGET,
            label,
            now,
        ):
            return True

        control_state["route_to_target"] = route
        control_state["target_route_goal"] = target_route_goal
        control_state["target_wp_index"] = nearest_route_index(route, laser_smooth, min_index=1) if len(route) > 1 else 0
        control_state["target_route_start_mode"] = "laser"
        control_state["route_valid"] = True
        control_state["plan_failed"] = False
        control_state["state"] = STATE_MOVE_TO_TARGET
        control_state["route_id"] += 1
        control_state["replan_count"] = replan_count + (1 if kind != "target_from_laser" else 0)
        control_state["replan_block_count"] = 0
        control_state["last_replan_success_time"] = now
        control_state.pop("first_replan_entry_time", None)
        reset_pd_state(control_state)
        if kind == "target_from_laser":
            control_state["last_plan_message"] = (
                f"planned second stage async: laser->target {len(route)} pts"
                + (f", fallback_goal_dist={distance(target_route_goal, target_smooth):.1f}px" if used_target_fallback else "")
            )
        elif kind == "dynamic_target":
            control_state["last_plan_message"] = (
                f"dynamic replan laser->target: {len(route)} pts, blocked_by={blocked_by}"
                + (f", fallback_goal_dist={distance(target_route_goal, target_smooth):.1f}px" if used_target_fallback else "")
            )
        else:
            control_state["last_plan_message"] = (
                f"retry success laser->target: {len(route)} pts"
                + (f", fallback_goal_dist={distance(target_route_goal, target_smooth):.1f}px" if used_target_fallback else "")
            )
        print(control_state["last_plan_message"])
        return True

    if kind in {"wait_replan_source", "dynamic_source"}:
        route = result.get("route")
        obstacles = result.get("obstacles", [])
        replan_count = int(result.get("replan_count", control_state.get("replan_count", 0)))
        blocked_by = result.get("blocked_by") or "obstacle"
        control_state["obstacles_to_source"] = obstacles

        if route is None:
            control_state["last_plan_message"] = "waiting: retry laser->source planning"
            print(control_state["last_plan_message"])
            return True

        label = "dynamic laser->source" if kind == "dynamic_source" else "retry laser->source"
        if not accept_rrt_route_or_wait(
            route,
            detections,
            frame_shape,
            args,
            control_state,
            laser_smooth,
            source_smooth,
            target_smooth,
            STATE_SEEK_SOURCE,
            label,
            now,
        ):
            return True

        control_state["route_to_source"] = route
        control_state["source_wp_index"] = nearest_route_index(route, laser_smooth, min_index=1) if len(route) > 1 else 0
        control_state["route_valid"] = True
        control_state["plan_failed"] = False
        control_state["state"] = STATE_SEEK_SOURCE
        control_state["route_id"] += 1
        control_state["replan_count"] = replan_count + 1
        control_state["replan_block_count"] = 0
        control_state["last_replan_success_time"] = now
        control_state.pop("first_replan_entry_time", None)
        reset_pd_state(control_state)
        if kind == "dynamic_source":
            control_state["last_plan_message"] = f"dynamic replan laser->source: {len(route)} pts, blocked_by={blocked_by}"
        else:
            control_state["last_plan_message"] = f"retry success laser->source: {len(route)} pts"
        print(control_state["last_plan_message"])
        return True

    return False

def phase_goal_ignore_center_and_radius(args, phase, source_smooth, target_smooth):

    if phase == STATE_MOVE_TO_TARGET:
        return target_smooth, max(0.0, float(getattr(args, "rrt_target_goal_soft_radius", 120.0)))
    if phase == STATE_SEEK_SOURCE:
        return source_smooth, max(0.0, float(getattr(args, "rrt_source_goal_soft_radius", 0.0)))
    return None, 0.0


def segment_circle_hit_point(a, b, center, radius):
    """Return (blocked, closest_point_on_segment) for segment-circle contact."""
    closest, _, closest_dist = project_point_to_segment(center, a, b)
    if closest_dist <= radius:
        return True, closest
    return False, closest


def path_blocked_by_obstacles(path, obstacles, ignore_start=None, ignore_start_radius=0.0,
                              ignore_goal=None, ignore_goal_radius=0.0):
    if path is None or len(path) < 2:
        return False, None

    ignore_start_radius = max(0.0, float(ignore_start_radius or 0.0))
    ignore_goal_radius = max(0.0, float(ignore_goal_radius or 0.0))

    for i in range(len(path) - 1):
        a = path[i]
        b = path[i + 1]
        if distance(a, b) <= 1e-6:
            continue
        for obs in obstacles:
            blocked, hit_point = segment_circle_hit_point(a, b, obs.center, obs.radius)
            if not blocked:
                continue

            if ignore_start is not None and ignore_start_radius > 0.0:
                if distance(hit_point, ignore_start) <= ignore_start_radius:
                    continue
            if ignore_goal is not None and ignore_goal_radius > 0.0:
                if distance(hit_point, ignore_goal) <= ignore_goal_radius:
                    continue

            return True, obs
    return False, None


def validate_route_against_obstacles(route, obstacles, args, label="route",
                                     ignore_start=None, ignore_start_radius=0.0,
                                     ignore_goal=None, ignore_goal_radius=0.0):
    if route is None or len(route) < 2:
        print(f"[RRT reject] {label}: empty route")
        return False, None

    extra = max(0.0, float(getattr(args, "route_validation_margin", 0.0)))
    check_obstacles = inflate_obstacles(obstacles, extra)
    blocked, obs = path_blocked_by_obstacles(
        route,
        check_obstacles,
        ignore_start=ignore_start,
        ignore_start_radius=ignore_start_radius,
        ignore_goal=ignore_goal,
        ignore_goal_radius=ignore_goal_radius,
    )
    if blocked:
        print(
            f"[RRT reject] {label}: route crosses "
            f"{obs.name if obs else 'obstacle'} with validation_margin={extra:.1f}"
        )
        return False, obs

    return True, None


def make_hard_obstacles_for_phase(detections, args, control_state, source_smooth, target_smooth, phase):
    selected_source_name = control_state.get("selected_source_name")
    selected_target_name = control_state.get("selected_target_name")
    hard_margin = max(0.0, float(getattr(args, "hard_safety_margin", 40.0)))

    if phase == STATE_SEEK_SOURCE:
        moving_radius = args.laser_radius
        exclude_target = False
    else:
        moving_radius = control_state.get("source_radius", args.default_droplet_radius)
        exclude_target = True

    return make_obstacles(
        detections=detections,
        selected_source_name=selected_source_name,
        source_center=source_smooth,
        selected_target_name=selected_target_name,
        target_center=target_smooth,
        association_radius=args.association_radius,
        moving_radius=moving_radius,
        safety_margin=hard_margin,
        default_radius=args.default_droplet_radius,
        exclude_source=True,
        exclude_target=exclude_target,
        **target_near_obstacle_kwargs(args, target_smooth, use_hard=(phase == STATE_MOVE_TO_TARGET)),
    )


def accept_rrt_route_or_wait(route, detections, frame_shape, args, control_state,
                             laser_smooth, source_smooth, target_smooth,
                             phase, label, now=None):

    hard_obstacles = make_hard_obstacles_for_phase(
        detections=detections,
        args=args,
        control_state=control_state,
        source_smooth=source_smooth,
        target_smooth=target_smooth,
        phase=phase,
    )
    goal_ignore, goal_ignore_radius = phase_goal_ignore_center_and_radius(
        args,
        phase,
        source_smooth,
        target_smooth,
    )
    ok, bad_obs = validate_route_against_obstacles(
        route,
        hard_obstacles,
        args,
        label=label,
        ignore_goal=goal_ignore,
        ignore_goal_radius=goal_ignore_radius,
    )
    if ok:
        return True

    resume_state = STATE_SEEK_SOURCE if phase == STATE_SEEK_SOURCE else STATE_MOVE_TO_TARGET
    enter_wait_replan(
        control_state,
        resume_state,
        f"unsafe {label} rejected: crosses {bad_obs.name if bad_obs else 'obstacle'}; waiting and retrying",
        now,
    )
    return False


def remaining_path_from_current(current_point, route, route_index, live_goal):
    if current_point is None or live_goal is None:
        return []
    if not route:
        return [current_point, live_goal]
    idx = max(1, min(int(route_index), len(route) - 1))
    tail = list(route[idx:])
    if not tail:
        tail = [live_goal]
    else:
        tail[-1] = live_goal
    return [current_point] + tail


def nearest_route_index(route, point, min_index=1):

    if not route:
        return 0
    if point is None:
        return min(max(min_index, 0), len(route) - 1)
    lo = min(max(int(min_index), 0), len(route) - 1)
    return min(range(lo, len(route)), key=lambda i: distance(route[i], point))


def maybe_dynamic_replan(detections, frame_shape, args, control_state, state, laser_smooth, source_smooth, target_smooth, now):

    if not getattr(args, "enable_replan", False):
        return False
    if not control_state.get("route_valid"):
        return False
    if control_state.get("rrt_planning_active"):
        return False
    if state not in {STATE_SEEK_SOURCE, STATE_MOVE_TO_TARGET}:
        return False
    if laser_smooth is None or source_smooth is None or target_smooth is None:
        return False

    last_time = control_state.get("last_replan_time", 0.0)
    if now - last_time < args.replan_interval:
        return False
    control_state["last_replan_time"] = now

    if now - control_state.get("last_replan_success_time", -1.0e9) < args.replan_cooldown:
        return False

    selected_source_name = control_state["selected_source_name"]
    selected_target_name = control_state["selected_target_name"]
    replan_count = int(control_state.get("replan_count", 0))

    if state == STATE_SEEK_SOURCE:
        obstacles = make_obstacles(
            detections=detections,
            selected_source_name=selected_source_name,
            source_center=source_smooth,
            selected_target_name=selected_target_name,
            target_center=target_smooth,
            association_radius=args.association_radius,
            moving_radius=args.laser_radius,
            safety_margin=args.safety_margin,
            default_radius=args.default_droplet_radius,
            exclude_source=True,
            exclude_target=False,
        )
        control_state["obstacles_to_source"] = obstacles

        idx = control_state.get("source_wp_index", 1)
        remaining = remaining_path_from_current(
            laser_smooth,
            control_state.get("route_to_source", []),
            idx,
            source_smooth,
        )
        check_obstacles = inflate_obstacles(obstacles, args.replan_check_margin)
        check_obstacles, _, _ = soften_endpoint_blockers(check_obstacles, laser_smooth, source_smooth, args)
        blocked, obs = path_blocked_by_obstacles(remaining, check_obstacles)

        if not blocked:
            desired_check, _, _, _, _ = compute_continuous_path_target(
                control_state.get("route_to_source", []) or [laser_smooth, source_smooth],
                laser_smooth,
                control_state.get("source_wp_index", 0),
                args.rrt_path_lookahead_dist,
                args.rrt_path_projection_backtrack,
            )
            if desired_check is not None:
                blocked, obs = path_blocked_by_obstacles([laser_smooth, desired_check], check_obstacles)

        if not blocked:
            control_state["replan_block_count"] = 0
            return False

        control_state["replan_block_count"] = int(control_state.get("replan_block_count", 0)) + 1
        if control_state["replan_block_count"] < args.replan_block_confirm_frames:
            return False

        enter_wait_replan(
            control_state,
            STATE_SEEK_SOURCE,
            f"dynamic replan queued: laser->source blocked by {obs.name if obs else 'obstacle'}; planning in background",
            now,
        )
        submit_rrt_plan(
            control_state,
            "dynamic_source",
            {
                "args": args,
                "frame_shape": frame_shape,
                "laser_smooth": laser_smooth,
                "source_smooth": source_smooth,
                "target_smooth": target_smooth,
                "obstacles": obstacles,
                "seed_offset": 1000 + replan_count,
                "replan_count": replan_count,
                "blocked_by": obs.name if obs else "obstacle",
                "resume_state": STATE_SEEK_SOURCE,
            },
        )
        return True

    # STATE_MOVE_TO_TARGET
    source_radius = control_state.get("source_radius", args.default_droplet_radius)
    obstacles = make_obstacles(
        detections=detections,
        selected_source_name=selected_source_name,
        source_center=source_smooth,
        selected_target_name=selected_target_name,
        target_center=target_smooth,
        association_radius=args.association_radius,
        moving_radius=source_radius,
        safety_margin=args.safety_margin,
        default_radius=args.default_droplet_radius,
        exclude_source=True,
        exclude_target=True,
        **target_near_obstacle_kwargs(args, target_smooth, use_hard=False),
    )
    control_state["obstacles_to_target"] = obstacles

    idx = control_state.get("target_wp_index", 1)
    remaining = remaining_path_from_current(
        laser_smooth,
        control_state.get("route_to_target", []),
        idx,
        control_state.get("target_route_goal") or target_smooth,
    )
    check_obstacles = inflate_obstacles(obstacles, args.replan_check_margin)
    check_obstacles, _, _ = soften_endpoint_blockers(
        check_obstacles,
        laser_smooth,
        target_smooth,
        args,
        goal_soft_radius=target_endpoint_soft_radius(args),
    )
    target_goal_ignore, target_goal_ignore_radius = phase_goal_ignore_center_and_radius(
        args,
        STATE_MOVE_TO_TARGET,
        source_smooth,
        target_smooth,
    )
    blocked, obs = path_blocked_by_obstacles(
        remaining,
        check_obstacles,
        ignore_goal=target_goal_ignore,
        ignore_goal_radius=target_goal_ignore_radius,
    )

    if not blocked:
        desired_check, _, _, _, _ = compute_continuous_path_target(
            control_state.get("route_to_target", []) or [laser_smooth, target_smooth],
            laser_smooth,
            control_state.get("target_wp_index", 0),
            args.rrt_path_lookahead_dist,
            args.rrt_path_projection_backtrack,
        )
        if desired_check is not None:
            blocked, obs = path_blocked_by_obstacles(
                [laser_smooth, desired_check],
                check_obstacles,
                ignore_goal=target_goal_ignore,
                ignore_goal_radius=target_goal_ignore_radius,
            )

    if not blocked:
        control_state["replan_block_count"] = 0
        return False

    control_state["replan_block_count"] = int(control_state.get("replan_block_count", 0)) + 1
    if control_state["replan_block_count"] < args.replan_block_confirm_frames:
        return False

    enter_wait_replan(
        control_state,
        STATE_MOVE_TO_TARGET,
        f"dynamic replan queued: laser->target blocked by {obs.name if obs else 'obstacle'}; planning in background",
        now,
    )
    submit_rrt_plan(
        control_state,
        "dynamic_target",
        {
            "args": args,
            "frame_shape": frame_shape,
            "laser_smooth": laser_smooth,
            "source_smooth": source_smooth,
            "target_smooth": target_smooth,
            "obstacles": obstacles,
            "seed_offset": 2000 + replan_count,
            "replan_count": replan_count,
            "blocked_by": obs.name if obs else "obstacle",
            "resume_state": STATE_MOVE_TO_TARGET,
        },
    )
    return True

def build_rrt_control_step(detections, frame_shape, args, control_state):
    state = control_state["state"]
    brake_until = control_state["brake_until"]
    brake_started = control_state["brake_started"]
    selection_ready = bool(control_state["selection_ready"])

    laser, raw_laser = select_laser_detection(detections)
    laser_conf = raw_laser["conf"] if raw_laser is not None else None

    selected_source_name = control_state["selected_source_name"]
    selected_target_name = control_state["selected_target_name"]
    source_lock_center = control_state["source_lock_center"]
    target_lock_center = control_state["target_lock_center"]
    source_miss_count = control_state["source_miss_count"]
    target_miss_count = control_state["target_miss_count"]
    laser_smooth = control_state["laser_smooth"]
    source_smooth = control_state["source_smooth"]
    target_smooth = control_state["target_smooth"]

    source = None
    target = None

    if source_is_selected(control_state):
        source, source_lock_center, source_miss_count = select_locked_detection(
            detections,
            selected_source_name,
            source_lock_center,
            source_miss_count,
            args.association_radius,
            args.lost_frames,
            args.position_alpha,
        )
    if target_is_selected(control_state) and not control_state.get("target_is_virtual", False):
        target, target_lock_center, target_miss_count = select_locked_detection(
            detections,
            selected_target_name,
            target_lock_center,
            target_miss_count,
            args.association_radius,
            args.lost_frames,
            args.position_alpha,
        )
    elif control_state.get("target_is_virtual", False):
        target = None
        target_lock_center = control_state.get("target_lock_center")
        target_miss_count = 0
        target_smooth = target_lock_center

    if source is not None:
        source_smooth = smooth_point(source_smooth, det_center(source), args.position_alpha)
        source_lock_center = source_smooth
        control_state["source_radius"] = det_radius(source, args.default_droplet_radius)
    elif source_lock_center is None:
        source_smooth = None

    if target is not None:
        target_smooth = smooth_point(target_smooth, det_center(target), args.position_alpha)
        target_lock_center = target_smooth
        control_state["target_radius"] = det_radius(target, args.default_droplet_radius)
    elif target_lock_center is None:
        target_smooth = None

    laser_smooth, laser_observed = update_laser_track(
        control_state, laser if laser is not None else (raw_laser if control_state.get("laser_smooth") is None else None), args
    )
    control_state["laser_miss_count"] = 0 if laser_observed else control_state.get("laser_miss_count", 0) + 1
    x_speed = 0
    y_speed = 0
    ex = None
    ey = None
    desired_point = None
    desired_color = (0, 0, 0)
    control_mode = None
    laser_source_dist = None
    laser_target_dist = None
    waypoint_dist = None
    state_changed = False
    safety_paused = False

    source_ready = source_smooth is not None
    target_ready = target_smooth is not None
    laser_ready = laser_smooth is not None

    now = time.time()

    if selection_ready:
        if consume_rrt_planning_result(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth, now):
            state_changed = True
            state = control_state["state"]

    route_was_valid = bool(control_state.get("route_valid"))
    if not selection_ready:
        state = STATE_WAIT_SELECTION
    else:
        ensure_route_planned(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth)
        state = control_state["state"]
        if (not route_was_valid) and control_state.get("route_valid"):
            state_changed = True

    if (
        state == STATE_WAIT_REPLAN
        and laser_ready
        and source_ready
        and target_ready
    ):
        if attempt_wait_replan(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth, now):
            state_changed = True
        state = control_state["state"]

    if (
        state == STATE_MOVE_TO_TARGET
        and laser_ready
        and source_ready
        and target_ready
        and control_state["route_valid"]
        and control_state.get("target_route_start_mode") != "laser"
    ):

        if plan_target_route_from_laser(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth):
            state_changed = True
        state = control_state["state"]

    if (
        state in {STATE_SEEK_SOURCE, STATE_MOVE_TO_TARGET}
        and laser_ready
        and source_ready
        and target_ready
        and control_state["route_valid"]
    ):
        if maybe_dynamic_replan(detections, frame_shape, args, control_state, state, laser_smooth, source_smooth, target_smooth, now):
            state_changed = True
            state = control_state["state"]

    if state == STATE_SEEK_SOURCE and laser_ready and source_ready and control_state["route_valid"]:
        laser_source_dist = distance(laser_smooth, source_smooth)
        if laser_source_dist <= args.rrt_source_close_dist:
            control_state["target_line_start"] = source_smooth
            state_changed = True
            if args.rrt_brake_time > 0:
                state = STATE_BRAKE_BEFORE_TARGET
                brake_until = now + args.rrt_brake_time
                brake_started = False
            else:
                state = STATE_MOVE_TO_TARGET
                brake_until = now
                brake_started = True
                control_state["state"] = STATE_MOVE_TO_TARGET
                plan_target_route_from_laser(detections, frame_shape, args, control_state, laser_smooth, source_smooth, target_smooth)
                state = control_state["state"]
            print(f"state -> {state}, laser_source_dist={laser_source_dist:.1f}")
        else:
            obstacles = make_obstacles(
                detections=detections,
                selected_source_name=control_state["selected_source_name"],
                source_center=source_smooth,
                selected_target_name=control_state["selected_target_name"],
                target_center=target_smooth,
                association_radius=args.association_radius,
                moving_radius=args.laser_radius,
                safety_margin=args.safety_margin,
                default_radius=args.default_droplet_radius,
                exclude_source=True,
                exclude_target=False,
            )
            control_state["obstacles_to_source"] = obstacles
            direct_check_obstacles = inflate_obstacles(obstacles, args.replan_check_margin)
            direct_check_obstacles, _, _ = soften_endpoint_blockers(direct_check_obstacles, laser_smooth, source_smooth, args)
            direct_blocked, _ = path_blocked_by_obstacles(
                [laser_smooth, source_smooth],
                direct_check_obstacles,
            )
            if not direct_blocked:
                control_state["direct_clear_count_source"] = control_state.get("direct_clear_count_source", 0) + 1
            else:
                control_state["direct_clear_count_source"] = 0
            use_direct_source = (
                getattr(args, "rrt_allow_source_direct", False)
                and (not direct_blocked)
                and control_state["direct_clear_count_source"] >= args.rrt_direct_confirm_frames
            )
            if use_direct_source:
                route = control_state["route_to_source"]
                line_start = route[0] if route else laser_smooth
                desired_point, progress_index, _, dist_to_end, _ = compute_continuous_path_target(
                    [line_start, source_smooth],
                    laser_smooth,
                    0,
                    args.rrt_path_lookahead_dist,
                    args.rrt_path_projection_backtrack,
                )
                control_state["source_wp_index"] = progress_index
                desired_color = (255, 255, 0)
                control_mode = "source_direct"
                waypoint_dist = dist_to_end
            else:
                route = control_state["route_to_source"] or [laser_smooth, source_smooth]
                desired_point, progress_index, _, dist_to_end, _ = compute_continuous_path_target(
                    route,
                    laser_smooth,
                    control_state.get("source_wp_index", 0),
                    args.rrt_path_lookahead_dist,
                    args.rrt_path_projection_backtrack,
                )
                control_state["source_wp_index"] = progress_index
                if desired_point is None:
                    desired_point = source_smooth
                desired_color = (255, 255, 0)
                control_mode = "source_path"
                waypoint_dist = dist_to_end

    if state == STATE_BRAKE_BEFORE_TARGET:
        desired_point = laser_smooth
        desired_color = (0, 165, 255)
        x_speed = 0
        y_speed = 0
        reset_pd_state(control_state)

    if state == STATE_MOVE_TO_TARGET and laser_ready and target_ready and control_state["route_valid"]:
        laser_target_dist = distance(laser_smooth, target_smooth)
        if laser_target_dist <= args.rrt_target_arrive_dist:
            state = STATE_ARRIVED
            desired_point = None
            x_speed = 0
            y_speed = 0
            state_changed = True
            reset_pd_state(control_state)
            print(f"state -> {state}, laser_target_dist={laser_target_dist:.1f}")
        else:
            obstacles = make_obstacles(
                detections=detections,
                selected_source_name=control_state["selected_source_name"],
                source_center=source_smooth,
                selected_target_name=control_state["selected_target_name"],
                target_center=target_smooth,
                association_radius=args.association_radius,
                moving_radius=control_state.get("source_radius", args.default_droplet_radius),
                safety_margin=args.safety_margin,
                default_radius=args.default_droplet_radius,
                exclude_source=True,
                exclude_target=True,
                **target_near_obstacle_kwargs(args, target_smooth, use_hard=False),
            )
            control_state["obstacles_to_target"] = obstacles
            direct_check_obstacles = inflate_obstacles(obstacles, args.replan_check_margin)
            direct_check_obstacles, _, _ = soften_endpoint_blockers(
                direct_check_obstacles,
                laser_smooth,
                target_smooth,
                args,
                goal_soft_radius=target_endpoint_soft_radius(args),
            )
            target_goal_ignore, target_goal_ignore_radius = phase_goal_ignore_center_and_radius(
                args,
                STATE_MOVE_TO_TARGET,
                source_smooth,
                target_smooth,
            )
            direct_blocked, _ = path_blocked_by_obstacles(
                [laser_smooth, target_smooth],
                direct_check_obstacles,
                ignore_goal=target_goal_ignore,
                ignore_goal_radius=target_goal_ignore_radius,
            )
            if not direct_blocked:
                control_state["direct_clear_count_target"] = control_state.get("direct_clear_count_target", 0) + 1
            else:
                control_state["direct_clear_count_target"] = 0
            use_direct_target = (
                getattr(args, "rrt_allow_target_direct", False)
                and (not direct_blocked)
                and control_state["direct_clear_count_target"] >= args.rrt_direct_confirm_frames
            )
            if use_direct_target:
                desired_point, progress_index, _, dist_to_end, _ = compute_continuous_path_target(
                    [control_state.get("target_line_start") or source_smooth, target_smooth],
                    laser_smooth,
                    0,
                    args.rrt_path_lookahead_dist,
                    args.rrt_path_projection_backtrack,
                )
                control_state["target_wp_index"] = progress_index
                desired_color = (0, 255, 0)
                control_mode = "target_direct"
                waypoint_dist = dist_to_end
            else:
                route_goal = control_state.get("target_route_goal") or target_smooth
                route = control_state["route_to_target"] or [laser_smooth, route_goal]
                desired_point, progress_index, _, dist_to_end, _ = compute_continuous_path_target(
                    route,
                    laser_smooth,
                    control_state.get("target_wp_index", 0),
                    args.rrt_path_lookahead_dist,
                    args.rrt_path_projection_backtrack,
                )
                control_state["target_wp_index"] = progress_index
                if desired_point is None:
                    desired_point = control_state.get("target_route_goal") or target_smooth
                desired_color = (0, 255, 255)
                control_mode = "target_path"
                waypoint_dist = dist_to_end

    control_ready = bool(
        selection_ready
        and control_state["route_valid"]
        and laser_ready
        and desired_point is not None
        and state in {STATE_SEEK_SOURCE, STATE_BRAKE_BEFORE_TARGET, STATE_MOVE_TO_TARGET}
    )

    if control_ready and state != STATE_BRAKE_BEFORE_TARGET:

        desired_point = smooth_point(
            control_state.get("rrt_desired_smooth"),
            desired_point,
            args.rrt_desired_alpha,
        )
        control_state["rrt_desired_smooth"] = desired_point


        phase = STATE_SEEK_SOURCE if state == STATE_SEEK_SOURCE else STATE_MOVE_TO_TARGET
        hard_obstacles = make_hard_obstacles_for_phase(
            detections=detections,
            args=args,
            control_state=control_state,
            source_smooth=source_smooth,
            target_smooth=target_smooth,
            phase=phase,
        )
        goal_ignore, goal_ignore_radius = phase_goal_ignore_center_and_radius(
            args,
            phase,
            source_smooth,
            target_smooth,
        )
        chord_ok, bad_obs = validate_route_against_obstacles(
            [laser_smooth, desired_point],
            hard_obstacles,
            args,
            label=f"command chord {state}",
            ignore_goal=goal_ignore,
            ignore_goal_radius=goal_ignore_radius,
        )

        if not chord_ok:
            safety_paused = True
            enter_wait_replan(
                control_state,
                phase,
                f"safety gate: command chord blocked by {bad_obs.name if bad_obs else 'obstacle'}; waiting and retrying",
                now,
            )
            state = control_state["state"]
            desired_point = None
            x_speed = 0
            y_speed = 0
            control_ready = False
            reset_pd_state(control_state)
        else:
            ex, ey = point_error(laser_smooth, desired_point)
            now_control = time.time()
            segment_key = control_mode
            same_pd_segment = (
                control_state.get("pd_last_route_id") == control_state.get("route_id")
                and control_state.get("pd_last_state") == state
                and control_state.get("pd_last_segment_key") == segment_key
            )
            last_ex = control_state.get("pd_last_ex")
            last_ey = control_state.get("pd_last_ey")
            last_time = control_state.get("pd_last_time")

            if same_pd_segment and last_ex is not None and last_ey is not None and last_time is not None:
                dt = max(1e-3, now_control - last_time)
                dex = (ex - last_ex) / dt
                dey = (ey - last_ey) / dt
                integral_ex = control_state.get("pd_integral_ex", 0.0) + ex * dt
                integral_ey = control_state.get("pd_integral_ey", 0.0) + ey * dt
            else:
                dex = 0.0
                dey = 0.0
                integral_ex = 0.0
                integral_ey = 0.0

            d_limit = max(0.0, float(args.rrt_derivative_limit))
            if d_limit > 0:
                dex = clamp(dex, -d_limit, d_limit)
                dey = clamp(dey, -d_limit, d_limit)

            i_limit = max(0.0, float(args.rrt_i_limit))
            if abs(ex) < args.rrt_deadband:
                integral_ex = 0.0
            else:
                integral_ex = clamp(integral_ex, -i_limit, i_limit)

            if abs(ey) < args.rrt_deadband:
                integral_ey = 0.0
            else:
                integral_ey = clamp(integral_ey, -i_limit, i_limit)

            control_state["pd_last_ex"] = ex
            control_state["pd_last_ey"] = ey
            control_state["pd_last_time"] = now_control
            control_state["pd_last_state"] = state
            control_state["pd_last_route_id"] = control_state.get("route_id")
            control_state["pd_last_segment_key"] = segment_key
            control_state["pd_integral_ex"] = integral_ex
            control_state["pd_integral_ey"] = integral_ey

            raw_x_speed = error_to_speed(ey, integral_ey, dey, X_DIR, args.rrt_k, args.rrt_ki, args.rrt_kd, args.rrt_deadband, args.rrt_min_speed, args.rrt_max_speed)
            raw_y_speed = error_to_speed(ex, integral_ex, dex, Y_DIR, args.rrt_k, args.rrt_ki, args.rrt_kd, args.rrt_deadband, args.rrt_min_speed, args.rrt_max_speed)

            x_speed = smooth_speed_command(
                raw_x_speed,
                control_state.get("rrt_last_x_speed", 0),
                args.rrt_speed_alpha,
                args.rrt_speed_max_delta,
            )
            y_speed = smooth_speed_command(
                raw_y_speed,
                control_state.get("rrt_last_y_speed", 0),
                args.rrt_speed_alpha,
                args.rrt_speed_max_delta,
            )
            control_state["rrt_last_x_speed"] = x_speed
            control_state["rrt_last_y_speed"] = y_speed
    else:
        reset_pd_state(control_state)

    if laser is None and selection_ready and state not in {STATE_WAIT_SELECTION, STATE_WAIT_PLAN, STATE_WAIT_REPLAN, STATE_PLAN_FAILED, STATE_ARRIVED}:
        safety_paused = True

    source_visible = source is not None or source_smooth is not None
    target_visible = target is not None or target_smooth is not None
    laser_visible = laser is not None or raw_laser is not None or laser_smooth is not None

    control_state["state"] = state
    control_state["brake_until"] = brake_until
    control_state["brake_started"] = brake_started
    control_state["source_lock_center"] = source_lock_center
    control_state["target_lock_center"] = target_lock_center
    control_state["source_miss_count"] = source_miss_count
    control_state["target_miss_count"] = target_miss_count
    control_state["laser_smooth"] = laser_smooth
    control_state["source_smooth"] = source_smooth
    control_state["target_smooth"] = target_smooth

    return {
        "route_id": control_state["route_id"],
        "mode": MODE_RRT,
        "draw_obstacles": bool(getattr(args, "draw_obstacles", False)),
        "detections": detections,
        "laser": laser,
        "raw_laser": raw_laser,
        "source": source,
        "target": target,
        "source_draw_center": det_center(source) if source is not None else source_smooth,
        "target_draw_center": det_center(target) if target is not None else target_smooth,
        "laser_draw_center": det_center(laser) if laser is not None else (det_center(raw_laser) if raw_laser is not None else laser_smooth),
        "laser_conf": laser_conf,
        "x_speed": x_speed,
        "y_speed": y_speed,
        "ex": ex,
        "ey": ey,
        "laser_source_dist": laser_source_dist,
        "laser_target_dist": laser_target_dist,
        "waypoint_dist": waypoint_dist,
        "detected": control_ready,
        "selection_ready": selection_ready,
        "laser_missing": laser is None,
        "safety_paused": safety_paused,
        "source_visible": source_visible,
        "target_visible": target_visible,
        "laser_visible": laser_visible,
        "state_changed": state_changed,
        "state": state,
        "brake_until": brake_until,
        "brake_started": brake_started,
        "desired_point": desired_point,
        "desired_color": desired_color,
        "route_to_source": list(control_state["route_to_source"]),
        "route_to_target": list(control_state["route_to_target"]),
        "source_wp_index": control_state["source_wp_index"],
        "target_wp_index": control_state["target_wp_index"],
        "route_valid": control_state["route_valid"],
        "plan_failed": control_state["plan_failed"],
        "obstacles_to_source": list(control_state["obstacles_to_source"]),
        "obstacles_to_target": list(control_state["obstacles_to_target"]),
    }

def build_control_step(detections, args, control_state, frame_shape=None):
    mode = control_state.get("mode", MODE_POINT)
    if mode == MODE_RRT:
        if frame_shape is None:
            frame_shape = (int(getattr(args, "height", 3036)), int(getattr(args, "width", 3200)), 3)
        return build_rrt_control_step(detections, frame_shape, args, control_state)

    state = control_state["state"]

    laser, raw_laser = select_laser_detection(detections)
    laser_smooth = control_state.get("laser_smooth")
    laser_smooth, laser_observed = update_laser_track(
        control_state, laser if laser is not None else (raw_laser if control_state.get("laser_smooth") is None else None), args
    )
    control_state["laser_miss_count"] = 0 if laser_observed else control_state.get("laser_miss_count", 0) + 1

    source = None
    source_smooth = control_state.get("source_smooth")
    source_lock_center = control_state.get("source_lock_center")
    source_miss_count = control_state.get("source_miss_count", 0)

    if source_is_selected(control_state):
        source, source_lock_center, source_miss_count = select_locked_droplet(
            detections,
            control_state["selected_source_name"],
            source_lock_center,
            source_miss_count,
            args,
        )
        if source is not None:
            source_smooth = smooth_point(source_smooth, det_center(source), args.position_alpha)
            source_lock_center = source_smooth
        elif source_lock_center is None:
            source_smooth = None

    target_point = control_state.get("target_point")
    home_point = control_state.get("home_point")
    sequence_points = list(control_state.get("sequence_points", []))
    sequence_index = int(control_state.get("sequence_index", 0))
    path_points = list(control_state.get("path_points", []))
    path_index = int(control_state.get("path_index", 0))
    drawing_path = bool(control_state.get("drawing_path", False))

    desired_point = None
    desired_color = (255, 255, 255)
    x_speed = 0
    y_speed = 0
    ex = None
    ey = None
    laser_source_dist = None
    laser_target_dist = None
    state_changed = False

    laser_ready = laser_smooth is not None
    source_ready = source_smooth is not None
    target_ready = target_point is not None
    sequence_ready = len(sequence_points) > 0
    path_ready = len(path_points) > 0

    if state == STATE_RETURN_HOME and home_point is not None:
        pass
    elif mode == MODE_MULTI:
        if not sequence_ready:
            state = STATE_WAIT_SEQUENCE
        elif state in {STATE_WAIT_DROPLET, STATE_WAIT_TARGET, STATE_WAIT_PATH, STATE_WAIT_SEQUENCE, STATE_DRAW_PATH, STATE_SEEK_DROPLET}:
            state = STATE_DRAG_TO_SEQUENCE
    elif not source_is_selected(control_state):
        state = STATE_WAIT_DROPLET
    elif mode == MODE_POINT and not target_ready:
        state = STATE_WAIT_TARGET
    elif mode == MODE_DRAW and drawing_path:
        state = STATE_DRAW_PATH
    elif mode == MODE_DRAW and not path_ready:
        state = STATE_WAIT_PATH
    elif state in {STATE_WAIT_TARGET, STATE_WAIT_PATH, STATE_DRAW_PATH}:
        state = STATE_SEEK_DROPLET

    if state == STATE_SEEK_DROPLET:
        if laser_ready and source_ready:
            laser_source_dist = distance(laser_smooth, source_smooth)
            if laser_source_dist <= args.source_close_dist:
                state = STATE_DRAG_TO_TARGET if mode == MODE_POINT else STATE_DRAG_TO_PATH
                if mode == MODE_POINT:
                    control_state["point_line_start"] = source_smooth
                    reset_pd_state(control_state)
                state_changed = True
                print(f"state -> {state}, laser_source_dist={laser_source_dist:.1f}")
            else:
                desired_point = source_smooth
                desired_color = (255, 0, 0)

    if state == STATE_DRAG_TO_TARGET:
        if laser_ready and target_ready:
            laser_target_dist = distance(laser_smooth, target_point)
            if laser_target_dist <= args.target_arrive_dist:
                state = STATE_ARRIVED
                state_changed = True
                print(f"state -> {state}, laser_target_dist={laser_target_dist:.1f}")
            else:
                desired_point = target_point
                desired_color = (0, 255, 0)

    if state == STATE_DRAG_TO_SEQUENCE:
        if laser_ready and sequence_ready:
            sequence_index = max(0, min(sequence_index, len(sequence_points) - 1))
            current_target = sequence_points[sequence_index]
            laser_target_dist = distance(laser_smooth, current_target)

            if laser_target_dist <= args.multi_arrive_dist:
                if sequence_index < len(sequence_points) - 1:
                    if getattr(args, "multi_replan_order", True):
                        control_state["sequence_index"] = sequence_index
                        reorder_pending_sequence(control_state, start_point=current_target)
                        sequence_points = list(control_state.get("sequence_points", []))
                    sequence_index += 1
                    reset_pd_state(control_state)
                    current_target = sequence_points[sequence_index]
                    laser_target_dist = distance(laser_smooth, current_target)
                else:
                    state = STATE_ARRIVED
                    state_changed = True
                    print(f"state -> {state}, multi sequence finished, points={len(sequence_points)}")

            if state == STATE_DRAG_TO_SEQUENCE:
                desired_point = current_target
                desired_color = (0, 165, 255)

    if state == STATE_RETURN_HOME:
        if laser_ready and home_point is not None:
            laser_target_dist = distance(laser_smooth, home_point)
            if laser_target_dist <= args.reset_arrive_dist:
                state = STATE_ARRIVED
                state_changed = True
                print(f"state -> {state}, reset home reached, dist={laser_target_dist:.1f}")
            else:
                desired_point = home_point
                desired_color = (255, 0, 255)

    if state == STATE_DRAG_TO_PATH:
        if laser_ready and path_ready:
            path_index = max(0, min(path_index, len(path_points) - 1))

            desired_point, progress_index, path_progress, dist_to_end, path_finished = compute_continuous_path_target(
                path_points,
                laser_smooth,
                path_index,
                args.draw_lookahead_dist,
                args.draw_projection_backtrack,
                args.draw_finish_dist,
            )
            path_index = max(0, min(progress_index, len(path_points) - 1))
            laser_target_dist = dist_to_end

            if path_finished or dist_to_end <= args.draw_finish_dist:
                state = STATE_ARRIVED
                state_changed = True
                print(f"state -> {state}, path finished, progress={path_progress:.2f}, points={len(path_points)}")
            else:
                desired_color = (0, 255, 0)

    control_ready = bool(
        laser_ready
        and desired_point is not None
        and state in {STATE_SEEK_DROPLET, STATE_DRAG_TO_TARGET, STATE_DRAG_TO_PATH, STATE_DRAG_TO_SEQUENCE, STATE_RETURN_HOME}
    )
    if control_ready:
        ex = desired_point[0] - laser_smooth[0]
        ey = desired_point[1] - laser_smooth[1]

        # POINT mode and DRAW mode use separate PID parameters.
        # DRAW mode gets faster parameters only while following the drawn path.
        if state == STATE_DRAG_TO_PATH:
            use_kp = args.draw_k
            use_ki = args.draw_ki
            use_kd = args.draw_kd
            use_i_limit = args.draw_i_limit
            use_deadband = args.draw_deadband
            use_min_speed = args.draw_min_speed
            use_max_speed = args.draw_max_speed
        elif state == STATE_DRAG_TO_SEQUENCE:
            use_kp = args.multi_k
            use_ki = args.multi_ki
            use_kd = args.multi_kd
            use_i_limit = args.multi_i_limit
            use_deadband = args.multi_deadband
            use_min_speed = args.multi_min_speed
            use_max_speed = args.multi_max_speed
        else:
            use_kp = args.k
            use_ki = args.ki
            use_kd = args.kd
            use_i_limit = args.i_limit
            use_deadband = args.deadband
            use_min_speed = args.min_speed
            use_max_speed = args.max_speed

        if getattr(args, "adaptive_pid", True):
            gain_scale = adaptive_gain_scale(
                math.hypot(float(ex), float(ey)),
                use_deadband,
                enabled=True,
            )
            use_kp *= gain_scale
            use_kd *= (0.85 + 0.15 * gain_scale)

        now_control = time.time()
        last_ex = control_state.get("pd_last_ex")
        last_ey = control_state.get("pd_last_ey")
        last_time = control_state.get("pd_last_time")
        same_pd_segment = (
            control_state.get("pd_last_route_id") == control_state.get("route_id")
            and control_state.get("pd_last_state") == state
            and (
                state in {STATE_DRAG_TO_PATH, STATE_DRAG_TO_SEQUENCE}
                or control_state.get("pd_last_path_index") == path_index
            )
        )

        if same_pd_segment and last_ex is not None and last_ey is not None and last_time is not None:
            dt = max(1e-3, now_control - last_time)
            dex = (ex - last_ex) / dt
            dey = (ey - last_ey) / dt
            integral_ex = control_state.get("pd_integral_ex", 0.0) + ex * dt
            integral_ey = control_state.get("pd_integral_ey", 0.0) + ey * dt
        else:

            dex = 0.0
            dey = 0.0
            integral_ex = 0.0
            integral_ey = 0.0

        use_i_limit = max(0.0, float(use_i_limit))
        if abs(ex) < use_deadband:
            integral_ex = 0.0
        else:
            integral_ex = clamp(integral_ex, -use_i_limit, use_i_limit)

        if abs(ey) < use_deadband:
            integral_ey = 0.0
        else:
            integral_ey = clamp(integral_ey, -use_i_limit, use_i_limit)

        control_state["pd_last_ex"] = ex
        control_state["pd_last_ey"] = ey
        control_state["pd_last_time"] = now_control
        control_state["pd_last_state"] = state
        control_state["pd_last_route_id"] = control_state.get("route_id")
        control_state["pd_last_path_index"] = path_index
        control_state["pd_integral_ex"] = integral_ex
        control_state["pd_integral_ey"] = integral_ey

        # Your motor mapping is swapped: motor x controls image y, motor y controls image x.
        x_speed = error_to_speed(ey, integral_ey, dey, X_DIR, use_kp, use_ki, use_kd, use_deadband, use_min_speed, use_max_speed)
        y_speed = error_to_speed(ex, integral_ex, dex, Y_DIR, use_kp, use_ki, use_kd, use_deadband, use_min_speed, use_max_speed)
    else:
        reset_pd_state(control_state)

    control_state["state"] = state
    control_state["laser_smooth"] = laser_smooth
    control_state["source_smooth"] = source_smooth
    control_state["source_lock_center"] = source_lock_center
    control_state["source_miss_count"] = source_miss_count
    control_state["sequence_index"] = sequence_index
    control_state["path_index"] = path_index

    return {
        "route_id": control_state["route_id"],
        "mode": mode,
        "detections": detections,
        "state": state,
        "state_changed": state_changed,
        "laser": laser,
        "raw_laser": raw_laser,
        "source": source,
        "laser_draw_center": det_center(laser) if laser is not None else (det_center(raw_laser) if raw_laser is not None else laser_smooth),
        "source_draw_center": det_center(source) if source is not None else source_smooth,
        "target_point": target_point,
        "point_line_start": control_state.get("point_line_start"),
        "home_point": home_point,
        "sequence_points": sequence_points,
        "sequence_index": sequence_index,
        "sequence_order_mode": control_state.get("sequence_order_mode", "tsp"),
        "sequence_order_cost": control_state.get("sequence_order_cost", 0.0),
        "path_points": path_points,
        "path_index": path_index,
        "path_draft": list(control_state.get("path_draft", [])),
        "drawing_path": drawing_path,
        "desired_point": desired_point,
        "desired_color": desired_color,
        "detected": control_ready,
        "laser_visible": laser is not None or raw_laser is not None or laser_smooth is not None,
        "source_visible": source is not None or source_smooth is not None,
        "x_speed": x_speed,
        "y_speed": y_speed,
        "ex": ex,
        "ey": ey,
        "laser_source_dist": laser_source_dist,
        "laser_target_dist": laser_target_dist,
        "laser_track_mode": control_state.get("laser_track_mode", "none"),
    }


def draw_marker(view, center, label, color):
    if center is None:
        return
    x, y = int(center[0]), int(center[1])
    cv2.circle(view, (x, y), 20, color, 3)
    cv2.circle(view, (x, y), 5, color, -1)
    cv2.putText(view, label, (x + 24, y - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)


def draw_polyline(view, points, color, thickness=3):
    if len(points) < 2:
        return
    int_points = [(int(p[0]), int(p[1])) for p in points]
    for i in range(1, len(int_points)):
        cv2.line(view, int_points[i - 1], int_points[i], color, thickness)


def draw_obstacles(view, obstacles, color):
    for obs in obstacles:
        cv2.circle(view, (int(obs.center[0]), int(obs.center[1])), int(obs.radius), color, 2)


def make_visual_step(step, control_state):
    """Merge slow detection step with instant UI/path edits from mouse callbacks."""
    visual = dict(step)
    visual["mode"] = control_state.get("mode", MODE_POINT)
    visual["state"] = control_state.get("state", visual.get("state"))
    visual["target_point"] = control_state.get("target_point")
    visual["point_line_start"] = control_state.get("point_line_start")
    visual["home_point"] = control_state.get("home_point")
    visual["sequence_points"] = list(control_state.get("sequence_points", []))
    visual["sequence_index"] = int(control_state.get("sequence_index", 0))
    visual["path_points"] = list(control_state.get("path_points", []))
    visual["path_index"] = int(control_state.get("path_index", 0))
    visual["path_draft"] = list(control_state.get("path_draft", []))
    visual["drawing_path"] = bool(control_state.get("drawing_path", False))
    return visual


def draw_overlay(view, step):

    mode = step.get("mode", MODE_POINT)

    for det in step.get("detections", []):
        if is_droplet(det):
            draw_detection(view, det, (160, 160, 160), det.get("name", "droplet"))

    if step.get("laser"):
        draw_detection(view, step["laser"], (0, 0, 255), "laser")
    elif step.get("raw_laser"):
        draw_detection(view, step["raw_laser"], (120, 120, 120), "laser")

    if mode == MODE_POINT:
        # Hidden: POINT target line and TARGET marker.
        pass

    elif mode == MODE_DRAW:
        # Hidden: DRAW yellow draft line, green path line, and path point marker.
        pass

    elif mode == MODE_MULTI:
        # Hidden: MULTI orange sequence line and M1/M2/M3 markers.
        pass

    elif mode == MODE_RRT:

        # draw_polyline(view, step.get("route_to_source", []), (255, 0, 255), 2)
        # draw_polyline(view, step.get("route_to_target", []), (0, 255, 255), 2)
        #
        # if step.get("source_draw_center"):
        #     draw_marker(view, step["source_draw_center"], "SRC", (255, 0, 255))
        # if step.get("target_draw_center"):
        #     draw_marker(view, step["target_draw_center"], "TGT", (0, 255, 255))
        pass
    # Hidden: desired/front lookahead point and arrow.
    # Keep these variables untouched for control logic; only do not draw them.
    desired = step.get("desired_point")
    laser = step.get("laser_draw_center")
    _ = desired, laser


def raw_points_to_preview(points, scale_x, scale_y):
    """Convert raw camera-coordinate points to current preview-window coordinates."""
    if not points:
        return []
    sx = max(float(scale_x), 1e-6)
    sy = max(float(scale_y), 1e-6)
    return [(float(p[0]) / sx, float(p[1]) / sy) for p in points]


def draw_path_on_preview(preview, control_state, scale_x, scale_y):

    if control_state.get("mode", MODE_POINT) != MODE_DRAW:
        return
    # Intentionally draw nothing for DRAW path preview.
    return


def draw_ui_buttons(panel, mode):
    labels = {
        MODE_POINT: "POINT",
        MODE_DRAW: "DRAW",
        MODE_MULTI: "MULTI",
        ACTION_RESET_HOME: "RESET",
        MODE_RRT: "RRT",
    }
    for button_mode, rect in UI_BUTTONS.items():
        x1, y1, x2, y2 = rect
        active = button_mode == mode
        fill_color = (70, 140, 70) if active else (58, 58, 58)
        if button_mode == ACTION_RESET_HOME:
            fill_color = (90, 60, 120)
        border_color = (255, 255, 255) if active else (150, 150, 150)
        cv2.rectangle(panel, (x1, y1), (x2, y2), fill_color, -1)
        cv2.rectangle(panel, (x1, y1), (x2, y2), border_color, 2)
        if button_mode == ACTION_RESET_HOME:
            text_x = x1 + 48
        elif button_mode == MODE_MULTI:
            text_x = x1 + 50
        elif button_mode == MODE_RRT:
            text_x = x1 + 72
        else:
            text_x = x1 + 58
        cv2.putText(panel, labels[button_mode], (text_x, y1 + 32), cv2.FONT_HERSHEY_SIMPLEX, 0.78, (255, 255, 255), 2)


def draw_panel_text(panel, text, origin, scale=0.62, color=(230, 230, 230), thickness=1, line_height=28):
    """Draw simple multi-line text on the right control panel."""
    x, y = origin
    for line in str(text).split("\n"):
        cv2.putText(panel, line, (x, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)
        y += line_height
    return y


def draw_right_panel(height, mode, step, stale=False, missing_laser=False, active=False):
    """Create a compact right-side UI panel with buttons and minimal status."""
    panel = np.full((height, RIGHT_PANEL_WIDTH, 3), (35, 35, 35), dtype=np.uint8)
    cv2.rectangle(panel, (0, 0), (RIGHT_PANEL_WIDTH - 1, height - 1), (85, 85, 85), 1)

    cv2.putText(panel, "MODE", (16, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.72, (255, 255, 255), 2)
    draw_ui_buttons(panel, mode)

    state_text = step.get("state", "")
    path_points = step.get("path_points", []) or []
    path_index = int(step.get("path_index", 0)) if path_points else 0

    y = 415
    cv2.line(panel, (16, y - 18), (RIGHT_PANEL_WIDTH - 16, y - 18), (85, 85, 85), 1)
    y = draw_panel_text(panel, "STATE", (16, y), 0.58, (180, 180, 180), 1, 26)
    y = draw_panel_text(panel, state_text, (16, y + 2), 0.64, (245, 245, 245), 2, 34)

    if stale:
        status_text = "STALE"
        status_color = (0, 255, 255)
    elif missing_laser:
        status_text = "LASER LOST"
        status_color = (0, 255, 255)
    elif active:
        status_text = "RUNNING"
        status_color = (0, 255, 0)
    else:
        status_text = "READY"
        status_color = (210, 210, 210)

    y = draw_panel_text(panel, "STATUS", (16, y + 14), 0.58, (180, 180, 180), 1, 26)
    y = draw_panel_text(panel, status_text, (16, y + 2), 0.68, status_color, 2, 34)

    if mode == MODE_DRAW and path_points:
        y = draw_panel_text(panel, f"PATH {path_index + 1}/{len(path_points)}", (16, y + 12), 0.58, (220, 220, 220), 1, 28)
    if mode == MODE_MULTI:
        sequence_points = step.get("sequence_points", []) or []
        sequence_index = int(step.get("sequence_index", 0)) if sequence_points else 0
        if sequence_points:
            y = draw_panel_text(panel, f"MULTI {sequence_index + 1}/{len(sequence_points)}", (16, y + 12), 0.58, (220, 220, 220), 1, 28)
        else:
            y = draw_panel_text(panel, "MULTI 0", (16, y + 12), 0.58, (220, 220, 220), 1, 28)
    if mode == MODE_RRT:
        src_route = step.get("route_to_source", []) or []
        tgt_route = step.get("route_to_target", []) or []
        y = draw_panel_text(panel, f"RRT {len(src_route)}/{len(tgt_route)}", (16, y + 12), 0.58, (220, 220, 220), 1, 28)

    cv2.line(panel, (16, y + 12), (RIGHT_PANEL_WIDTH - 16, y + 12), (85, 85, 85), 1)
    if mode == MODE_POINT:
        tip_text = "Click droplet\nClick target"
    elif mode == MODE_DRAW:
        tip_text = "Click droplet\nDraw letter"
    elif mode == MODE_MULTI:
        tip_text = "Click droplets\nQueue runs"
    elif mode == MODE_RRT:
        tip_text = "Click source\nClick target"
    else:
        tip_text = "Click button"
    draw_panel_text(panel, tip_text, (16, y + 46), 0.62, (220, 220, 220), 1, 30)
    draw_panel_text(panel, "ESC exit", (16, height - 28), 0.52, (170, 170, 170), 1, 24)
    return panel


def compose_right_panel_ui(image_preview, mode, step, stale=False, missing_laser=False, active=False):
    """Append a right-side control panel to the displayed image."""
    panel = draw_right_panel(image_preview.shape[0], mode, step, stale=stale, missing_laser=missing_laser, active=active)
    return np.hstack([image_preview, panel])


# =============================
# Main
# =============================
def build_arg_parser():
    """集中定义命令行参数，供 Cora 复用。"""
    parser = argparse.ArgumentParser(description="Minimal click-droplet-and-drag control.")
    bundled_model = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "weights", "best.pt")
    parser.add_argument("--model", default=bundled_model,
                        help="视觉模型路径；也可指定兼容的推理引擎")
    parser.add_argument("--conf", type=float, default=0.30)
    parser.add_argument("--imgsz", type=int, default=1280)
    parser.add_argument("--device", default="auto")

    parser.add_argument("--camera-index", type=int, default=0)
    parser.add_argument("--width", type=int, default=3200)
    parser.add_argument("--height", type=int, default=3036)
    parser.add_argument("--offset-x", type=int, default=0,
                        help="ROI 左上角 X 偏移。配合 --width/--height 只取一小块视场，"
                             "液滴占的像素更多、更接近训练分布，模型更容易检出")
    parser.add_argument("--offset-y", type=int, default=0,
                        help="ROI 左上角 Y 偏移")
    parser.add_argument("--exposure-time", type=float, default=50000.0)
    parser.add_argument("--gain", type=float, default=5.0)
    parser.add_argument("--frame-rate", type=float, default=10.0)

    # parser.add_argument("--enable-motor", action="store_true")
    parser.add_argument("--port", default=None,
                        help="步进电机串口；留空时自动探测")
    parser.add_argument("--motor-verbose", action="store_true")
    parser.add_argument("--motor-command-delay", type=float, default=DEFAULT_MOTOR_COMMAND_DELAY)
    parser.add_argument("--no-motor-readback", action="store_true")

    parser.add_argument("--position-alpha", type=float, default=DEFAULT_POSITION_ALPHA)
    parser.add_argument("--association-radius", type=float, default=DEFAULT_ASSOCIATION_RADIUS)
    parser.add_argument("--lost-frames", type=int, default=DEFAULT_LOST_FRAMES)
    parser.add_argument("--max-click-dist", type=float, default=DEFAULT_MAX_CLICK_DIST)
    parser.add_argument("--max-detection-age", type=float, default=DEFAULT_MAX_DETECTION_AGE)
    parser.add_argument("--track-predict-frames", type=int, default=8,
                        help="Maximum frames for short constant-velocity laser prediction when YOLO misses.")
    parser.add_argument("--metrics-file", default="cora_metrics.json",
                        help="JSON file receiving online tracking and control metrics on exit.")
    parser.add_argument("--tune-from-metrics", default=None,
                        help="根据已保存的轨迹指标离线搜索 RRT 跟踪 PID 参数，然后退出")
    parser.add_argument("--tuned-params-file", default="tuned_pid_params.json",
                        help="离线调参结果 JSON；使用 --apply-tuned-params 显式加载")
    parser.add_argument("--apply-tuned-params", default=None,
                        help="显式加载离线调参 JSON，不会自动覆盖当前 PID 参数")
    parser.add_argument("--tune-population", type=int, default=16)
    parser.add_argument("--tune-generations", type=int, default=24)

    parser.add_argument("--k", type=float, default=DEFAULT_K)
    parser.add_argument("--ki", type=float, default=DEFAULT_KI)
    parser.add_argument("--kd", type=float, default=DEFAULT_KD)
    parser.add_argument("--i-limit", type=float, default=DEFAULT_I_LIMIT)
    parser.add_argument("--max-speed", type=int, default=DEFAULT_MAX_SPEED)
    parser.add_argument("--min-speed", type=int, default=DEFAULT_MIN_SPEED)
    parser.add_argument("--deadband", type=float, default=DEFAULT_DEADBAND)
    parser.add_argument("--draw-k", type=float, default=DRAW_K)
    parser.add_argument("--draw-ki", type=float, default=DRAW_KI)
    parser.add_argument("--draw-kd", type=float, default=DRAW_KD)
    parser.add_argument("--draw-i-limit", type=float, default=DRAW_I_LIMIT)
    parser.add_argument("--draw-max-speed", type=int, default=DRAW_MAX_SPEED)
    parser.add_argument("--draw-min-speed", type=int, default=DRAW_MIN_SPEED)
    parser.add_argument("--draw-deadband", type=float, default=DRAW_DEADBAND)
    parser.add_argument("--adaptive-pid", dest="adaptive_pid", action="store_true", default=True,
                        help="Enable bounded gain scheduling near the target.")
    parser.add_argument("--no-adaptive-pid", dest="adaptive_pid", action="store_false")
    parser.add_argument("--command-interval", type=float, default=DEFAULT_COMMAND_INTERVAL)
    parser.add_argument("--source-close-dist", type=float, default=SOURCE_CLOSE_DIST)
    parser.add_argument("--target-arrive-dist", type=float, default=TARGET_ARRIVE_DIST)
    parser.add_argument("--reset-arrive-dist", type=float, default=RESET_ARRIVE_DIST)
    parser.add_argument("--multi-k", type=float, default=MULTI_K)
    parser.add_argument("--multi-ki", type=float, default=MULTI_KI)
    parser.add_argument("--multi-kd", type=float, default=MULTI_KD)
    parser.add_argument("--multi-i-limit", type=float, default=MULTI_I_LIMIT)
    parser.add_argument("--multi-max-speed", type=int, default=MULTI_MAX_SPEED)
    parser.add_argument("--multi-min-speed", type=int, default=MULTI_MIN_SPEED)
    parser.add_argument("--multi-deadband", type=float, default=MULTI_DEADBAND)
    parser.add_argument("--multi-arrive-dist", type=float, default=MULTI_ARRIVE_DIST)
    parser.add_argument("--multi-order", choices=("tsp", "click"), default="tsp",
                        help="MULTI visit order: bounded TSP optimization or original click order.")
    parser.add_argument("--multi-turn-weight", type=float, default=0.15,
                        help="Penalty for sharp turns in the MULTI route cost.")
    parser.add_argument("--multi-replan-order", action="store_true", default=True,
                        help="Reorder unvisited droplets after each arrival using the current laser position.")
    parser.add_argument("--no-multi-replan-order", dest="multi_replan_order", action="store_false")
    parser.add_argument("--point-line-lookahead", type=float, default=POINT_LINE_LOOKAHEAD)
    parser.add_argument("--point-cross-track-gain", type=float, default=POINT_CROSS_TRACK_GAIN)
    parser.add_argument("--point-cross-track-limit", type=float, default=POINT_CROSS_TRACK_LIMIT)
    parser.add_argument("--point-line-arrive-dist", type=float, default=POINT_LINE_ARRIVE_DIST)
    parser.add_argument("--path-arrive-dist", type=float, default=PATH_ARRIVE_DIST)
    parser.add_argument("--path-point-spacing", type=float, default=PATH_POINT_SPACING)
    parser.add_argument("--path-draw-min-step", type=float, default=PATH_DRAW_MIN_STEP)
    parser.add_argument("--min-path-length", type=float, default=MIN_PATH_LENGTH)
    parser.add_argument("--draw-lookahead-dist", type=float, default=DRAW_LOOKAHEAD_DIST)
    parser.add_argument("--draw-finish-dist", type=float, default=DRAW_FINISH_DIST)
    parser.add_argument("--draw-projection-backtrack", type=int, default=DRAW_PROJECTION_BACKTRACK)

    # RRT mode uses independent tracking and planning parameters.
    parser.add_argument("--rrt-k", type=float, default=RRT_K)
    parser.add_argument("--rrt-ki", type=float, default=RRT_KI)
    parser.add_argument("--rrt-kd", type=float, default=RRT_KD)
    parser.add_argument("--rrt-i-limit", type=float, default=RRT_I_LIMIT)
    parser.add_argument("--rrt-max-speed", type=int, default=RRT_MAX_SPEED)
    parser.add_argument("--rrt-min-speed", type=int, default=RRT_MIN_SPEED)
    parser.add_argument("--rrt-deadband", type=float, default=RRT_DEADBAND)
    parser.add_argument("--rrt-source-close-dist", type=float, default=RRT_SOURCE_CLOSE_DIST)
    parser.add_argument("--rrt-target-arrive-dist", type=float, default=RRT_TARGET_ARRIVE_DIST)
    parser.add_argument("--rrt-path-lookahead-dist", type=float, default=RRT_PATH_LOOKAHEAD_DIST)
    parser.add_argument("--rrt-path-projection-backtrack", type=int, default=RRT_PATH_PROJECTION_BACKTRACK)
    parser.add_argument("--rrt-desired-alpha", type=float, default=RRT_DESIRED_ALPHA,
                        help="RRT lookahead target smoothing. Higher is steadier but responds slower.")
    parser.add_argument("--rrt-speed-alpha", type=float, default=RRT_SPEED_ALPHA,
                        help="RRT motor command smoothing. Higher is steadier but accelerates slower.")
    parser.add_argument("--rrt-speed-max-delta", type=float, default=RRT_SPEED_MAX_DELTA,
                        help="Maximum RRT speed change per control update on each axis.")
    parser.add_argument("--rrt-derivative-limit", type=float, default=RRT_DERIVATIVE_LIMIT,
                        help="Clamp RRT derivative term to reduce detection-noise oscillation.")
    parser.add_argument("--rrt-brake-time", type=float, default=RRT_BRAKE_TIME)
    parser.add_argument("--rrt-direct-confirm-frames", type=int, default=RRT_DIRECT_CONFIRM_FRAMES,
                        help="Direct path must be clear this many consecutive frames before abandoning the planned route.")
    parser.add_argument("--rrt-allow-target-direct", action="store_true", default=RRT_ALLOW_TARGET_DIRECT,
                        help="Allow RRT target stage to abandon the planned route and use a straight laser->target line. Disabled by default for safer dynamic obstacle avoidance.")
    parser.add_argument("--rrt-allow-source-direct", action="store_true", default=RRT_ALLOW_SOURCE_DIRECT,
                        help="Allow RRT source stage to abandon the planned route and use a straight laser->source line. Disabled by default for safer dynamic obstacle avoidance.")

    parser.add_argument("--rrt-max-iter", type=int, default=3000)
    parser.add_argument("--route-candidates", type=int, default=5,
                        help="Multiobjective route archive size; planner keeps a small diverse Informed RRT* ensemble.")
    parser.add_argument("--path-refine-generations", type=int, default=2,
                        help="精英差分路径候选的更新轮数")
    parser.add_argument("--path-refine-population", type=int, default=6,
                        help="每轮精英差分路径候选数")
    parser.add_argument("--rrt-step", type=float, default=40.0)
    parser.add_argument("--rrt-search-radius", type=float, default=380.0)
    parser.add_argument("--rrt-goal-sample-rate", type=float, default=0.10)
    parser.add_argument("--rrt-seed", type=int, default=None)
    parser.add_argument("--smooth-attempts", type=int, default=80)
    parser.add_argument("--safety-margin", type=float, default=200.0)
    parser.add_argument("--laser-radius", type=float, default=20.0)
    parser.add_argument("--default-droplet-radius", type=float, default=35.0)
    parser.add_argument("--hard-safety-margin", type=float, default=40.0,
                        help="Non-negotiable droplet clearance used to reject unsafe RRT routes and motor command chords.")
    parser.add_argument("--rrt-target-near-zone-radius", type=float, default=10,
                        help="Only in target stage: droplets within this distance from the selected target use a separate safety margin.")
    parser.add_argument("--rrt-target-near-safety-margin", type=float, default=10,
                        help="Only in target stage: planning safety margin for obstacle droplets near the selected target.")
    parser.add_argument("--rrt-target-near-hard-safety-margin", type=float, default=4,
                        help="Only in target stage: hard validation margin for obstacle droplets near the selected target.")
    parser.add_argument("--rrt-target-near-max-radius", type=float, default=10,
                        help="Only in target stage: cap the inflated planning radius of droplets near the selected target. Prevents multiple nearby droplets from sealing the target zone.")
    parser.add_argument("--rrt-target-near-hard-max-radius", type=float, default=20,
                        help="Only in target stage: cap the hard validation radius of droplets near the selected target.")
    parser.add_argument("--route-validation-margin", type=float, default=8.0,
                        help="Extra margin used only by the final route/chord safety validator.")
    parser.add_argument("--rrt-endpoint-soft-radius", type=float, default=180.0,
                        help="Generic endpoint soft radius for escaping inflated obstacle deadlock.")
    parser.add_argument("--rrt-target-endpoint-soft-radius", type=float, default=38.0,
                        help="Planner-only soft radius for obstacles containing the final target endpoint. Smaller values prevent target-near droplets from causing WAIT_REPLAN deadlock.")
    parser.add_argument("--rrt-target-goal-soft-radius", type=float, default=180.0,
                        help="Final target neighborhood in which route/chord validators ignore endpoint-only obstacle contact.")
    parser.add_argument("--rrt-target-approach-ratio", type=float, default=0.85,
                        help="Fallback target approach goal radius as a fraction of --rrt-target-arrive-dist.")
    parser.add_argument("--rrt-target-approach-samples", type=int, default=32,
                        help="Number of circle samples used when exact target-center RRT planning is blocked.")
    parser.add_argument("--rrt-target-approach-clearance", type=float, default=65.0,
                        help="Minimum center clearance used when sampling target fallback approach goals near target-near obstacles.")
    parser.add_argument("--rrt-source-goal-soft-radius", type=float, default=0.0,
                        help="Optional source endpoint validator ignore radius. Keep 0 unless source-near droplets also cause deadlock.")
    parser.add_argument("--rrt-plan-extra-clearance", type=float, default=60.0,
                        help="Extra pixels added to RRT planning obstacles so replanned routes stay farther from droplets. Endpoint blockers are not expanded again.")
    parser.add_argument("--draw-obstacles", action="store_true")
    parser.add_argument("--enable-replan", dest="enable_replan", action="store_true", default=True)
    parser.add_argument("--disable-replan", dest="enable_replan", action="store_false")
    parser.add_argument("--replan-interval", type=float, default=0.02)
    parser.add_argument("--replan-retry-interval", type=float, default=0.2,
                        help="When replanning fails, retry planning every N seconds while motor stays stopped.")
    parser.add_argument("--replan-stuck-timeout", type=float, default=2,
                        help="Maximum seconds to remain in WAIT_REPLAN before declaring planning failed.")
    parser.add_argument("--replan-cooldown", type=float, default=0.2,
                        help="Minimum seconds after a successful replan before another replan is allowed.")
    parser.add_argument("--replan-block-confirm-frames", type=int, default=2,
                        help="Route must be blocked this many replan checks in a row before replanning.")
    parser.add_argument("--replan-check-margin", type=float, default=0,
                        help="Extra pixels added only when checking whether the current route is blocked.")
    return parser


def main():
    args = build_arg_parser().parse_args()

    if not args.tune_from_metrics and not os.path.exists(args.model):
        raise FileNotFoundError(
            f"模型文件不存在：{args.model}。请使用 --model 指定当前机器上的权重文件。"
        )

    if args.tune_from_metrics:
        run_pid_tuning(args)
        return

    if args.apply_tuned_params:
        apply_tuned_pid_params(args, args.apply_tuned_params)

    motor_on = True
    stage = None
    detector = None

    print("UI mode: use the two buttons in the right-side control panel.")
    print("RRT safety: endpoint blockers are softened, target endpoint has its own soft zone, target-near droplets can use separate safety margins, only one nearest source/target detection is excluded, and hard route/chord validation is enabled.")
    print("RRT planning: Informed RRT* runs in a background worker; the main loop only polls completed routes.")
    print("POINT TARGET: click a droplet, then click any target position.")
    print("DRAW LETTER: click a droplet, then hold the left mouse button and draw a visible letter path.")
    print("RRT: click source droplet, then click target droplet; Informed RRT* plans an obstacle-avoiding route.")
    if motor_on:
        print(f"Motor enabled on {args.port}")
    else:
        print("Motor disabled. Add --enable-motor when preview is correct.")

    if YOLO is None:
        raise RuntimeError("Ultralytics is required for camera mode; install it or use --tune-from-metrics for offline tuning.")
    model = YOLO(args.model, task="detect")
    camera = ThreadedHikCamera(
        index=args.camera_index,
        width=args.width,
        height=args.height,
        exposure_time=args.exposure_time,
        gain=args.gain,
        frame_rate=args.frame_rate,
    )

    if motor_on:
        stage = Y42XYZ(
            port=args.port,
            x_addr=1,
            y_addr=2,
            z_addr=3,
            verbose=args.motor_verbose,
            command_delay=args.motor_command_delay,
            motion_readback=not args.no_motor_readback,
        )
        stage.clear_protect()
        stage.enable()
        stage.stop_axis("z")

    detector = LatestDetectionWorker(camera=camera, model=model, imgsz=args.imgsz, conf=args.conf, device=args.device)

    screen_w, screen_h = get_screen_size()
    window_name = "Minimal Droplet Drag Control"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

    control_state = make_control_state()
    control_state["sequence_order_mode"] = args.multi_order
    control_state["sequence_turn_weight"] = args.multi_turn_weight
    rrt_planner = RRTPlanningWorker()
    control_state["rrt_planner"] = rrt_planner
    latest_step = {
        "route_id": control_state["route_id"],
        "mode": control_state["mode"],
        "detections": [],
        "state": STATE_WAIT_DROPLET,
        "detected": False,
        "x_speed": 0,
        "y_speed": 0,
        "state_changed": False,
        "laser_visible": False,
        "source_visible": False,
        "path_points": [],
        "path_index": 0,
        "path_draft": [],
        "drawing_path": False,
    }

    shared = {
        "detections": [],
        "scale_x": 1.0,
        "scale_y": 1.0,
        "image_w": 0,
        "image_h": 0,
        "request_stop": False,

        "force_control_update": False,
    }
    shared_lock = threading.Lock()

    def seed_control_laser_from_latest_step():
        if control_state.get("laser_smooth") is not None:
            return
        center = latest_step.get("laser_draw_center")
        if center is not None:
            control_state["laser_smooth"] = (float(center[0]), float(center[1]))
            control_state["laser_miss_count"] = 0

    def on_mouse(event, x, y, flags, userdata):
        with shared_lock:
            image_w = int(shared.get("image_w", 0))
            image_h = int(shared.get("image_h", 0))

            if image_w > 0 and event == cv2.EVENT_LBUTTONDOWN and x >= image_w:
                button_mode = hit_ui_button((x - image_w, y))
                if button_mode is not None:
                    if button_mode == ACTION_RESET_HOME:

                        if control_state.get("mode") == MODE_RRT:
                            reset_task(control_state, mode=MODE_RRT)
                            shared["request_stop"] = True
                            shared["force_control_update"] = True
                            print("RRT stopped/reset: click source droplet, then target droplet")
                        else:
                            ok = return_laser_to_home(control_state)
                            shared["request_stop"] = True
                            shared["force_control_update"] = True
                            if ok:
                                print(f"reset home -> laser returns to first selected droplet position {control_state.get('home_point')}")
                            else:
                                print("reset ignored: select a droplet first")
                    else:
                        switch_mode(control_state, button_mode)
                        if button_mode == MODE_RRT:
                            seed_control_laser_from_latest_step()
                        shared["request_stop"] = True
                        shared["force_control_update"] = True
                        if button_mode == MODE_POINT:
                            mode_name = "POINT TARGET"
                        elif button_mode == MODE_DRAW:
                            mode_name = "DRAW LETTER"
                        elif button_mode == MODE_MULTI:
                            mode_name = "MULTI DROPLETS"
                        elif button_mode == MODE_RRT:
                            mode_name = "RRT PLANNER"
                        else:
                            mode_name = str(button_mode)
                        print(f"mode switched -> {mode_name}")
                        if button_mode == MODE_POINT:
                            print("click a droplet, then click any target position")
                        elif button_mode == MODE_DRAW:
                            print("click a droplet, then drag mouse to draw a letter path")
                        elif button_mode == MODE_MULTI:
                            print("click droplets one by one; the laser will visit fixed droplet targets in order")
                        elif button_mode == MODE_RRT:
                            print("click source droplet, then click target droplet for RRT* obstacle avoidance")
                return

            # Ignore other mouse events in the right panel or outside the image area.
            if image_w <= 0 or image_h <= 0 or x >= image_w or y >= image_h:
                return

            raw_point = (x * shared["scale_x"], y * shared["scale_y"])
            detections = list(shared["detections"])
            mode = control_state.get("mode", MODE_POINT)

            if mode == MODE_POINT:
                if event != cv2.EVENT_LBUTTONDOWN:
                    return

                if not source_is_selected(control_state):
                    det, click_dist = nearest_droplet_detection(detections, raw_point, args.max_click_dist)
                    if det is None:
                        if click_dist is None:
                            print("click ignored: no droplet detections")
                        else:
                            print(f"click ignored: nearest droplet is {click_dist:.0f}px away")
                        return
                    select_source_from_click(control_state, det, args)
                    shared["request_stop"] = True
                    shared["force_control_update"] = True
                    print(f"selected droplet: {det.get('name')} at {det_center(det)}")
                    print("now click any target position")
                    return

                select_target_from_click(control_state, raw_point)
                shared["request_stop"] = True
                shared["force_control_update"] = True
                print(f"selected target point: ({raw_point[0]:.1f}, {raw_point[1]:.1f})")
                return

            # RRT mode: click source droplet, then target droplet.
            if mode == MODE_RRT:
                if event != cv2.EVENT_LBUTTONDOWN:
                    return
                seed_control_laser_from_latest_step()
                det, click_dist = nearest_droplet_detection(detections, raw_point, args.max_click_dist)
                if det is None:
                    if click_dist is None:
                        print("RRT click ignored: no droplet detections")
                    else:
                        print(f"RRT click ignored: nearest droplet is {click_dist:.0f}px away")
                    return

                if source_is_selected(control_state) and target_is_selected(control_state):
                    rrt_reset_route(control_state)
                    shared["request_stop"] = True
                    shared["force_control_update"] = True

                if not source_is_selected(control_state):
                    rrt_select_source_from_click(control_state, det, args)
                    shared["request_stop"] = True
                    shared["force_control_update"] = True
                    print(f"RRT selected SOURCE: {det.get('name')} at {det_center(det)}")
                    print("now click target droplet")
                    return

                rrt_select_target_from_click(control_state, det, args)
                shared["request_stop"] = True
                shared["force_control_update"] = True
                print(f"RRT selected TARGET: {det.get('name')} at {det_center(det)}")
                return

            # Multi-droplet mode: every click on a droplet appends it to the queue.
            if mode == MODE_MULTI:
                if event != cv2.EVENT_LBUTTONDOWN:
                    return
                det, click_dist = nearest_droplet_detection(detections, raw_point, args.max_click_dist)
                if det is None:
                    if click_dist is None:
                        print("multi click ignored: no droplet detections")
                    else:
                        print(f"multi click ignored: nearest droplet is {click_dist:.0f}px away")
                    return
                ok, count = append_sequence_droplet(control_state, det)
                if ok:
                    if count == 1:
                        shared["request_stop"] = True
                        shared["force_control_update"] = True
                    print(f"multi added M{count}: {det.get('name')} at {det_center(det)}")
                return

            # Draw-letter mode.
            if event == cv2.EVENT_LBUTTONDOWN:
                if not source_is_selected(control_state):
                    det, click_dist = nearest_droplet_detection(detections, raw_point, args.max_click_dist)
                    if det is None:
                        if click_dist is None:
                            print("click ignored: no droplet detections")
                        else:
                            print(f"click ignored: nearest droplet is {click_dist:.0f}px away")
                        return
                    select_source_from_click(control_state, det, args)
                    shared["request_stop"] = True
                    shared["force_control_update"] = True
                    print(f"selected droplet: {det.get('name')} at {det_center(det)}")
                    print("now hold left mouse button and draw a letter path")
                    return

                start_path_drawing(control_state, raw_point)
                shared["request_stop"] = True
                shared["force_control_update"] = True
                print(f"drawing path started at ({raw_point[0]:.1f}, {raw_point[1]:.1f})")
                return

            if event == cv2.EVENT_MOUSEMOVE:
                if control_state.get("drawing_path") and (flags & cv2.EVENT_FLAG_LBUTTON):
                    append_path_drawing(control_state, raw_point, args.path_draw_min_step)
                return

            if event == cv2.EVENT_LBUTTONUP:
                if control_state.get("drawing_path"):
                    ok = finish_path_drawing(control_state, args)
                    shared["request_stop"] = True
                    shared["force_control_update"] = True
                    if ok:
                        print(f"path finished: {len(control_state.get('path_points', []))} waypoints")
                    else:
                        print("path ignored: draw a longer path")
                return

    cv2.setMouseCallback(window_name, on_mouse)

    last_packet_seq = None
    last_packet_time = None
    last_command_time = 0.0
    last_command = (None, None)

    try:
        while True:
            frame = camera.get_frame()
            now = time.time()

            try:
                packet = detector.get_latest() if detector is not None else None
            except Exception as exc:
                print(f"inference worker failed: {exc}")
                break

            with shared_lock:
                request_stop = shared["request_stop"]
                force_control_update = shared.get("force_control_update", False)
                shared["request_stop"] = False
                shared["force_control_update"] = False

            if request_stop:
                stop_xy(stage)
                with shared_lock:
                    reset_pd_state(control_state)
                latest_step = dict(latest_step)
                latest_step["detected"] = False
                latest_step["x_speed"] = 0
                latest_step["y_speed"] = 0
                latest_step["state_changed"] = False
                latest_step["route_id"] = control_state.get("route_id")
                last_command = (0, 0)
                # Allow a newly rebuilt control step, especially first RRT start,
                # to send a speed command immediately after stopping the old task.
                last_command_time = 0.0 if force_control_update else now

            if packet is not None and (packet["seq"] != last_packet_seq or force_control_update):
                try:
                    with shared_lock:
                        shared["detections"] = packet["detections"]
                        latest_step = build_control_step(packet["detections"], args, control_state, frame.shape)
                        update_runtime_metrics(control_state, latest_step, now=now)
                    last_packet_seq = packet["seq"]
                    last_packet_time = packet["timestamp"]
                except Exception as exc:
                    import traceback
                    print(f"[ERROR] build_control_step crashed: {exc}")
                    traceback.print_exc()
                    last_packet_seq = packet["seq"]
                    last_packet_time = packet["timestamp"]

            with shared_lock:
                route_id_now = control_state["route_id"]

            packet_age = None if last_packet_time is None else now - last_packet_time
            stale = last_packet_time is None or packet_age > args.max_detection_age
            route_matches = latest_step.get("route_id") == route_id_now
            active = bool(latest_step.get("detected")) and not stale and route_matches
            arrived = latest_step.get("state") == STATE_ARRIVED and route_matches
            missing_laser = not latest_step.get("laser_visible")

            x_speed = latest_step.get("x_speed", 0) if active else 0
            y_speed = latest_step.get("y_speed", 0) if active else 0
            state_changed = latest_step.get("state_changed", False) if route_matches else False
            ex = latest_step.get("ex")
            ey = latest_step.get("ey")

            view = frame.copy()
            with shared_lock:
                step_for_draw = make_visual_step(latest_step, control_state)
            draw_overlay(view, step_for_draw)


            if motor_on and (stale or arrived or not active or missing_laser):
                if last_command != (0, 0):
                    stop_xy(stage)
                    last_command = (0, 0)
                    last_command_time = now
            elif motor_on and active:
                should_send = state_changed or now - last_command_time >= args.command_interval
                command_changed = (x_speed, y_speed) != last_command
                if should_send and (command_changed or x_speed != 0 or y_speed != 0):
                    if state_changed and latest_step.get("state") not in {STATE_DRAG_TO_TARGET, STATE_DRAG_TO_PATH, STATE_DRAG_TO_SEQUENCE, STATE_SEEK_SOURCE, STATE_MOVE_TO_TARGET} and last_command != (0, 0):
                        stop_xy(stage)
                    stage.speed("x", x_speed)
                    stage.speed("y", y_speed)
                    last_command = (x_speed, y_speed)
                    last_command_time = now
                    latest_step["state_changed"] = False
                    if ex is not None and ey is not None:
                        print(f"speed x={x_speed}, y={y_speed}, err=({ex:.0f},{ey:.0f}), state={latest_step.get('state')}")
                    else:
                        print(f"speed x={x_speed}, y={y_speed}, state={latest_step.get('state')}")

            image_max_w = max(320, screen_w - RIGHT_PANEL_WIDTH - 20)
            preview = resize_to_fit(view, image_max_w, screen_h)
            current_scale_x = frame.shape[1] / max(1, preview.shape[1])
            current_scale_y = frame.shape[0] / max(1, preview.shape[0])
            with shared_lock:
                mode_for_buttons = control_state.get("mode", MODE_POINT)
                step_for_panel = make_visual_step(latest_step, control_state)
                draw_path_on_preview(preview, control_state, current_scale_x, current_scale_y)
                shared["scale_x"] = current_scale_x
                shared["scale_y"] = current_scale_y
                shared["image_w"] = preview.shape[1]
                shared["image_h"] = preview.shape[0]

            ui_frame = compose_right_panel_ui(
                preview,
                mode_for_buttons,
                step_for_panel,
                stale=stale,
                missing_laser=missing_laser and source_is_selected(control_state),
                active=active,
            )

            cv2.resizeWindow(window_name, ui_frame.shape[1], ui_frame.shape[0])
            cv2.imshow(window_name, ui_frame)

            key = cv2.waitKey(1) & 0xFF
            if key == 27:
                break

    except Exception as exc:
        import traceback
        print(f"\n[FATAL] Main loop crashed: {exc}")
        traceback.print_exc()
        input("Press Enter to close...")
    finally:
        try:
            metrics_path = os.path.abspath(args.metrics_file)
            with open(metrics_path, "w", encoding="utf-8") as metrics_handle:
                json.dump(control_state.get("metrics", {}), metrics_handle, ensure_ascii=False, indent=2)
            print(f"metrics saved: {metrics_path}")
        except Exception as metrics_exc:
            print(f"metrics save failed: {metrics_exc}")
        stop_xy(stage)
        if detector is not None:
            detector.close()
        rrt_planner = control_state.get("rrt_planner")
        if rrt_planner is not None:
            rrt_planner.close()
        if stage is not None:
            stage.close()
        camera.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
