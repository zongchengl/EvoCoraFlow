# -*- coding: utf-8 -*-
"""Offline identity and tracking regressions; no camera or motor access."""
import unittest
from unittest.mock import Mock, patch
from tracking import SingleTargetTracker

from labeling import DropletLabeler


def det(x, y=300, radius=10):
    return {
        "name": "droplet",
        "conf": 0.9,
        "center": (float(x), float(y)),
        "xyxy": (x - radius, y - radius, x + radius, y + radius),
    }


class KCFInterfaceTests(unittest.TestCase):
    def test_xyxy_detection_roundtrips_opencv_xywh(self):
        frame = Mock(shape=(300, 400, 3))
        backend = Mock()
        backend.init.return_value = None
        backend.update.return_value = (True, (110, 85, 40, 30))
        with patch("tracking._make_kcf", return_value=backend):
            tracker = SingleTargetTracker(backend="kcf")
            initial = tracker.initialize(frame, (100, 80, 140, 110))
            backend.init.assert_called_once_with(frame, (100, 80, 40, 30))
            self.assertEqual(initial.mode, "kcf")
            result = tracker.update(frame)
        self.assertEqual(result.bbox, (110, 85, 150, 115))
        self.assertEqual(result.center, (130, 100))
        self.assertFalse(result.visible)
        self.assertEqual(result.mode, "kcf")


class StableIdentityTests(unittest.TestCase):
    def make_labeler(self, **kwargs):
        return DropletLabeler(group_mode="none", smooth_alpha=1.0,
                              min_radius_ratio=0.0, **kwargs)

    def test_progressive_crossing_keeps_identity_with_trajectory(self):
        labeler = self.make_labeler(max_missing_frames=4)
        frames = [
            [det(100, 300), det(220, 320)],
            [det(120, 300), det(200, 320)],
            [det(140, 300), det(180, 320)],
            [det(160, 300), det(160, 320)],
            [det(180, 300), det(140, 320)],
            [det(200, 300), det(120, 320)],
            [det(220, 300), det(100, 320)],
            [det(240, 300), det(80, 320)],
        ]
        first, _ = labeler.update(frames[0])
        identities = {item.label: item.identity for item in first}
        for frame in frames[1:]:
            current, _ = labeler.update(frame)
            self.assertEqual({item.label: item.identity for item in current}, identities)
        final = {item.label: item.raw_center for item in current}
        self.assertEqual(final["A1"][0], 240.0)
        self.assertEqual(final["A2"][0], 80.0)

    def test_short_missed_detection_recovers_original_label(self):
        labeler = self.make_labeler(max_missing_frames=3)
        first, _ = labeler.update([det(100), det(250)])
        expected = {item.label: item.identity for item in first}
        only_first, _ = labeler.update([det(110)])
        self.assertEqual(only_first[0].label, "A1")
        recovered, _ = labeler.update([det(120), det(240)])
        self.assertEqual({item.label: item.identity for item in recovered}, expected)

    def test_lost_identity_expires_after_configured_grace_period(self):
        labeler = self.make_labeler(max_missing_frames=1)
        first, _ = labeler.update([det(100)])
        first_identity = first[0].identity
        labeler.update([])
        labeler.update([])
        recovered, _ = labeler.update([det(105)])
        self.assertNotEqual(recovered[0].identity, first_identity)


if __name__ == "__main__":
    unittest.main(verbosity=2)
