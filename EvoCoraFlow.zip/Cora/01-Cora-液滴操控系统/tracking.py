# -*- coding: utf-8 -*-
"""视觉跟踪与 ROI/推理尺度标定。

该模块只处理单目标的短时连续跟踪，不替代检测器。检测框出现时用于校正
跟踪器，检测暂时缺失时优先使用 OpenCV KCF，随后退化到速度预测与 EMA。
这样现场缺少某个 OpenCV tracker 扩展时仍可离线运行，控制层也不会收到
未经标记的“确定检测”。
"""

from dataclasses import dataclass
import math

try:
    import cv2
except ImportError:  # pragma: no cover - 纯逻辑环境允许没有 OpenCV
    cv2 = None


def _as_bbox(bbox):
    if bbox is None or len(bbox) < 4:
        return None
    x1, y1, x2, y2 = [float(v) for v in bbox[:4]]
    if x2 < x1:
        x1, x2 = x2, x1
    if y2 < y1:
        y1, y2 = y2, y1
    if x2 - x1 < 1.0 or y2 - y1 < 1.0:
        return None
    return (x1, y1, x2, y2)


def bbox_center(bbox):
    box = _as_bbox(bbox)
    if box is None:
        return None
    return ((box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5)


def center_bbox(center, width, height):
    if center is None:
        return None
    cx, cy = float(center[0]), float(center[1])
    w = max(2.0, float(width))
    h = max(2.0, float(height))
    return (cx - w * 0.5, cy - h * 0.5, cx + w * 0.5, cy + h * 0.5)


def _clip_bbox(bbox, frame_shape):
    box = _as_bbox(bbox)
    if box is None or frame_shape is None:
        return box
    height, width = frame_shape[:2]
    x1 = max(0.0, min(float(width - 1), box[0]))
    y1 = max(0.0, min(float(height - 1), box[1]))
    x2 = max(x1 + 1.0, min(float(width), box[2]))
    y2 = max(y1 + 1.0, min(float(height), box[3]))
    return (x1, y1, x2, y2)


def _make_kcf():
    """兼容 opencv-contrib 和新版 legacy 命名空间。"""
    if cv2 is None:
        return None
    makers = [
        getattr(cv2, "TrackerKCF_create", None),
        getattr(getattr(cv2, "legacy", None), "TrackerKCF_create", None),
    ]
    for maker in makers:
        if callable(maker):
            try:
                return maker()
            except Exception:
                continue
    return None


@dataclass
class TrackResult:
    center: tuple = None
    bbox: tuple = None
    visible: bool = False
    mode: str = "lost"
    lost_frames: int = 0
    confidence: float = 0.0


class SingleTargetTracker:
    """一个目标的 KCF + 预测/EMA 适配器。

    ``update`` 的返回值明确区分 ``visible`` 和 ``mode``。预测结果只用于
    短时接续，不会伪装成高置信度检测框。
    """

    def __init__(self, backend="auto", position_alpha=0.55, max_lost=8,
                 max_jump=180.0, velocity_alpha=0.35):
        self.requested_backend = str(backend or "auto").lower()
        self.position_alpha = max(0.0, min(1.0, float(position_alpha)))
        self.max_lost = max(0, int(max_lost))
        self.max_jump = max(1.0, float(max_jump))
        self.velocity_alpha = max(0.0, min(1.0, float(velocity_alpha)))
        self.reset()

    @property
    def backend(self):
        return self._backend

    def reset(self):
        self._tracker = None
        self._bbox = None
        self._center = None
        self._velocity = (0.0, 0.0)
        self._lost = 0
        self._backend = "lost"
        self._last_frame_shape = None

    def _new_tracker(self, frame, bbox):
        self._tracker = None
        if self.requested_backend in {"ema", "predict", "prediction", "none"}:
            return
        tracker = _make_kcf()
        if tracker is None or frame is None:
            return
        try:
            x1, y1, x2, y2 = bbox
            # OpenCV trackers use xywh; project boxes use xyxy.
            xywh = (int(round(x1)), int(round(y1)),
                    max(1, int(round(x2 - x1))), max(1, int(round(y2 - y1))))
            result = tracker.init(frame, xywh)
            # OpenCV 4 returns None, older builds return bool.
            if result is False:
                return
            self._tracker = tracker
            self._backend = "kcf"
        except Exception:
            self._tracker = None

    def _fuse_observation(self, bbox, frame_shape=None, confidence=1.0):
        bbox = _clip_bbox(bbox, frame_shape)
        center = bbox_center(bbox)
        if center is None:
            return False
        if self._center is not None:
            jump = math.hypot(center[0] - self._center[0], center[1] - self._center[1])
            if jump > self.max_jump and self._lost == 0:
                return False
            vx = center[0] - self._center[0]
            vy = center[1] - self._center[1]
            a = self.velocity_alpha
            self._velocity = (
                self._velocity[0] * (1.0 - a) + vx * a,
                self._velocity[1] * (1.0 - a) + vy * a,
            )
            a = self.position_alpha
            center = (
                self._center[0] * (1.0 - a) + center[0] * a,
                self._center[1] * (1.0 - a) + center[1] * a,
            )
        self._bbox = bbox
        self._center = center
        self._lost = 0
        if self._tracker is None:
            self._backend = "ema"
        return True

    def initialize(self, frame, bbox, confidence=1.0):
        bbox = _clip_bbox(bbox, frame.shape if frame is not None else None)
        if bbox is None:
            return TrackResult()
        self.reset()
        self._last_frame_shape = frame.shape if frame is not None else None
        self._fuse_observation(bbox, self._last_frame_shape, confidence)
        self._new_tracker(frame, bbox)
        return TrackResult(self._center, self._bbox, True, self._backend, 0,
                           float(confidence))

    def update(self, frame=None, bbox=None, confidence=1.0):
        frame_shape = frame.shape if frame is not None else self._last_frame_shape
        self._last_frame_shape = frame_shape
        observed = False
        if bbox is not None:
            clipped = _clip_bbox(bbox, frame_shape)
            if clipped is not None:
                observed = self._fuse_observation(clipped, frame_shape, confidence)
                if observed:
                    # Detection is the correction source; reinitializing KCF
                    # prevents a stale template from drifting after a crossing.
                    self._new_tracker(frame, clipped)
        if observed:
            return TrackResult(self._center, self._bbox, True, self._backend, 0,
                               float(confidence))

        if self._tracker is not None and frame is not None:
            try:
                ok, box = self._tracker.update(frame)
                if ok:
                    x, y, width, height = map(float, box)
                    box = (_clip_bbox((x, y, x + width, y + height), frame_shape)
                           if width > 0 and height > 0 else None)
                    if box is not None:
                        old = self._center
                        center = bbox_center(box)
                        if old is not None:
                            vx = center[0] - old[0]
                            vy = center[1] - old[1]
                            a = self.velocity_alpha
                            self._velocity = (self._velocity[0] * (1 - a) + vx * a,
                                              self._velocity[1] * (1 - a) + vy * a)
                        self._bbox, self._center = box, center
                        self._lost = 0
                        self._backend = "kcf"
                        return TrackResult(center, box, False, "kcf", 0, 0.25)
            except Exception:
                self._tracker = None

        if self._center is not None and self._lost < self.max_lost:
            vx, vy = self._velocity
            decay = 0.86 ** self._lost
            center = (self._center[0] + vx * decay, self._center[1] + vy * decay)
            if frame_shape is not None:
                h, w = frame_shape[:2]
                center = (max(0.0, min(float(w - 1), center[0])),
                          max(0.0, min(float(h - 1), center[1])))
            self._center = center
            if self._bbox is not None:
                bw = self._bbox[2] - self._bbox[0]
                bh = self._bbox[3] - self._bbox[1]
                self._bbox = center_bbox(center, bw, bh)
            self._lost += 1
            self._backend = "prediction"
            return TrackResult(self._center, self._bbox, False, "prediction",
                               self._lost, 0.12)

        self._lost += 1
        self._backend = "lost"
        return TrackResult(None, None, False, "lost", self._lost, 0.0)

    def state(self):
        result = self.update(frame=None, bbox=None)
        return result


def recommend_detection_scale(frame_shape, droplet_diameters, base_imgsz=1280,
                              roi_shape=None, target_pixels=96,
                              min_imgsz=640, max_imgsz=1536,
                              droplet_boxes=None, roi_center=None):
    """根据目标像素直径给出 ROI 与 imgsz 建议。

    这是几何标定，不是识别率承诺。若没有可靠尺寸观测，函数返回基准
    参数并标注 ``reason=insufficient_measurement``。
    """
    h, w = int(frame_shape[0]), int(frame_shape[1])
    values = sorted(float(v) for v in (droplet_diameters or []) if float(v) > 1.0)
    if not values:
        return {
            "imgsz": int(max(min_imgsz, min(max_imgsz, base_imgsz))),
            "roi": (0, 0, w, h),
            "scale_factor": 1.0,
            "target_pixels": float(target_pixels),
            "observed_median_px": None,
            "reason": "insufficient_measurement",
        }
    median = values[len(values) // 2]
    current_w, current_h = (roi_shape[0], roi_shape[1]) if roi_shape else (w, h)
    base_imgsz = int(max(1, base_imgsz))
    current_network_px = median * base_imgsz / max(current_w, current_h)
    factor = max(0.65, min(3.0, float(target_pixels) / max(current_network_px, 1.0)))
    # 先受控增加 imgsz，再缩小软件 ROI；不自动改动相机硬件 ROI。
    imgsz_factor = min(1.35, max(0.85, math.sqrt(factor)))
    proposed = int(round(float(base_imgsz) * imgsz_factor / 32.0) * 32)
    proposed = int(max(min_imgsz, min(max_imgsz, proposed)))
    remaining_factor = factor / max(1e-6, proposed / float(base_imgsz))
    roi_w = int(max(320, min(w, round(current_w / max(1.0, remaining_factor)))))
    roi_h = int(max(320, min(h, round(current_h / max(1.0, remaining_factor)))))
    if droplet_boxes:
        boxes = [_as_bbox(box) for box in droplet_boxes]
        boxes = [box for box in boxes if box is not None]
        if boxes:
            bx1 = min(box[0] for box in boxes)
            by1 = min(box[1] for box in boxes)
            bx2 = max(box[2] for box in boxes)
            by2 = max(box[3] for box in boxes)
            required_w = max(320, int(math.ceil((bx2 - bx1) * 1.35)))
            required_h = max(320, int(math.ceil((by2 - by1) * 1.35)))
            roi_w = min(w, max(roi_w, required_w))
            roi_h = min(h, max(roi_h, required_h))
            roi_center = ((bx1 + bx2) * 0.5, (by1 + by2) * 0.5)
    cx, cy = roi_center or (w * 0.5, h * 0.5)
    ox = int(max(0, min(w - roi_w, round(float(cx) - roi_w * 0.5))))
    oy = int(max(0, min(h - roi_h, round(float(cy) - roi_h * 0.5))))
    predicted_network_px = median * proposed / max(roi_w, roi_h)
    return {
        "imgsz": proposed,
        "roi": (ox, oy, roi_w, roi_h),
        "scale_factor": round(factor, 3),
        "target_pixels": float(target_pixels),
        "observed_median_px": round(median, 2),
        "predicted_network_pixels": round(predicted_network_px, 2),
        "roi_limited_by_observed_extent": bool(droplet_boxes and max(roi_w, roi_h) > max(current_w, current_h) / max(1.0, remaining_factor) * 1.15),
        "reason": "measured",
    }

