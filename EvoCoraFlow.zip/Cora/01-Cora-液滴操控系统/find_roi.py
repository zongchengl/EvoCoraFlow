# -*- coding: utf-8 -*-
"""搜索 ROI × 推理尺寸组合，输出供现场复核的标定建议。

软件 ROI 与 imgsz 共同影响网络内目标像素直径。脚本对图像切块并
统计候选检出数；需要人工标注验证误检和漏检，不能以检出数量替代识别率。
用法：python find_roi.py --image sample.png（不传图片则尝试相机）。
"""

import argparse
import math
import os
import sys
import time

import cv2
from image_io import read_image, write_image
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

# 液滴在训练分布里的目标像素尺寸（模型认得的范围）
TRAIN_LO, TRAIN_HI = 84, 116


# ================================================================ 取图

def grab_hik(width, height, offset_x, offset_y, exposure, gain, frames=12):
    """从海康相机采一帧，返回 BGR 图。"""
    import droplet_core as core
    cam = core.HikCamera(
        width=width, height=height,
        offset_x=offset_x, offset_y=offset_y,
        exposure_time=exposure, gain=gain,
        frame_rate=10.0,
    )
    print(f"相机已打开，访问模式={getattr(cam, 'access_mode', '?')}")
    frame = None
    for i in range(frames):
        f = cam.get_frame(timeout=3000)
        if f is not None:
            frame = f
        time.sleep(0.05)
    cam.close()
    print("相机已释放")
    if frame is None:
        raise RuntimeError("连续取帧失败")
    return frame


# ================================================================ 推理

def detect(model, img, imgsz, conf, device="cpu"):
    """跑一次推理，返回 [(类别名, 置信度, (x1,y1,x2,y2)), ...]（坐标为 img 局部坐标）。"""
    res = model.predict(img, imgsz=imgsz, conf=conf, device=device, verbose=False)[0]
    out = []
    names = res.names
    for b in res.boxes:
        cls = int(b.cls[0])
        c = float(b.conf[0])
        xyxy = tuple(float(v) for v in b.xyxy[0].tolist())
        out.append((names.get(cls, str(cls)), c, xyxy))
    return out


def tile_windows(w, h, size, stride=None):
    """把 w x h 切成 size x size 的块，返回 [(x0, y0, x1, y1), ...]。"""
    stride = stride or size
    xs = list(range(0, max(1, w - size + 1), stride))
    ys = list(range(0, max(1, h - size + 1), stride))
    if not xs or xs[-1] + size < w:
        xs.append(max(0, w - size))
    if not ys or ys[-1] + size < h:
        ys.append(max(0, h - size))
    xs, ys = sorted(set(xs)), sorted(set(ys))
    win = []
    for y0 in ys:
        for x0 in xs:
            win.append((x0, y0, min(w, x0 + size), min(h, y0 + size)))
    return win


# ================================================================ 主流程

def sweep(model, frame, sizes, imgsz_list, conf, device):
    """对每个 (ROI 尺寸, 推理尺寸) 组合做全幅切块检测，统计 droplet 命中。"""
    h, w = frame.shape[:2]
    results = []

    for size in sizes:
        for imgsz in imgsz_list:
            zoom = imgsz / float(size)
            dropped = 0
            lasers = 0
            solids = 0
            hits = []          # (全局坐标 xyxy, conf)
            t0 = time.time()
            windows = tile_windows(w, h, size)
            for (x0, y0, x1, y1) in windows:
                crop = frame[y0:y1, x0:x1]
                if crop.size == 0:
                    continue
                for name, c, xyxy in detect(model, crop, imgsz, conf, device):
                    gx1, gy1, gx2, gy2 = (xyxy[0] + x0, xyxy[1] + y0,
                                          xyxy[2] + x0, xyxy[3] + y0)
                    if name == "droplet":
                        dropped += 1
                        # 换算成"若原尺寸即 imgsz 基准下的等效像素"
                        hits.append(((gx1, gy1, gx2, gy2), c))
                    elif name == "laser":
                        lasers += 1
                    else:
                        solids += 1
            dt = time.time() - t0
            eff_px = 0.0
            if hits:
                # 检出框在裁剪图里的像素尺寸 × 放大倍数 = 推理输入里的像素尺寸
                raw = [max(b[2] - b[0], b[3] - b[1]) for b, _ in hits]
                eff_px = float(np.mean(raw)) / zoom * zoom  # 裁剪图内像素
                eff_px = float(np.mean(raw))
                eff_infer = eff_px * zoom                  # 推理输入内像素
            else:
                eff_infer = 0.0
            results.append({
                "size": size, "imgsz": imgsz, "zoom": zoom,
                "windows": len(windows), "droplet": dropped,
                "laser": lasers, "solid": solids,
                "avg_conf": float(np.mean([c for _, c in hits])) if hits else 0.0,
                "infer_px": eff_infer,
                "hits": hits, "sec": dt,
            })
            print(f"ROI {size:5d}  imgsz {imgsz:5d}  放大 {zoom:4.2f}x  "
                  f"块数 {len(windows):3d}  液滴 {dropped:3d}  光斑 {lasers:3d}  "
                  f"液滴在输入中 {eff_infer:5.1f}px  用时 {dt:5.1f}s")
    return results


def draw_report(frame, results, out_path):
    """把每个配置的命中框画到全幅缩略图上，直观看液滴在哪。"""
    h, w = frame.shape[:2]
    scale = 1400.0 / max(w, h)
    base = cv2.resize(frame, (int(w * scale), int(h * scale)),
                      interpolation=cv2.INTER_AREA)
    best = [r for r in results if r["droplet"] > 0]
    best.sort(key=lambda r: -r["droplet"])
    if not best:
        write_image(out_path, base)
        return None
    top = best[0]
    view = base.copy()
    for (x1, y1, x2, y2), c in top["hits"]:
        cv2.rectangle(view, (int(x1 * scale), int(y1 * scale)),
                      (int(x2 * scale), int(y2 * scale)), (0, 0, 255), 2)
        cv2.putText(view, f"{c:.2f}", (int(x1 * scale), int(y1 * scale) - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
    # 液滴聚集区域框出来
    if top["hits"]:
        xs = [b[0] for b, _ in top["hits"]] + [b[2] for b, _ in top["hits"]]
        ys = [b[1] for b, _ in top["hits"]] + [b[3] for b, _ in top["hits"]]
        cv2.rectangle(view, (int(min(xs) * scale), int(min(ys) * scale)),
                      (int(max(xs) * scale), int(max(ys) * scale)), (0, 255, 0), 2)
    cv2.putText(view,
                f"ROI {top['size']} imgsz {top['imgsz']} zoom {top['zoom']:.2f}x "
                f"-> droplet {top['droplet']}",
                (12, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
    write_image(out_path, view)
    return top


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", default=None, help="用已有图片代替相机")
    ap.add_argument("--exposure-time", type=float, default=15000.0)
    ap.add_argument("--gain", type=float, default=0.0)
    ap.add_argument("--width", type=int, default=3200)
    ap.add_argument("--height", type=int, default=3036)
    ap.add_argument("--offset-x", type=int, default=0)
    ap.add_argument("--offset-y", type=int, default=0)
    ap.add_argument("--model", default=os.path.join(HERE, "weights", "best.pt"))
    ap.add_argument("--conf", type=float, default=0.15)
    ap.add_argument("--imgsz", type=int, nargs="*", default=[1280])
    ap.add_argument("--sizes", type=int, nargs="*",
                    default=[600, 800, 1100, 1600])
    ap.add_argument("--device", default="cpu")
    args = ap.parse_args()

    if args.image:
        frame = read_image(args.image)
        if frame is None:
            print("读不到图片：", args.image)
            return 1
    else:
        frame = grab_hik(args.width, args.height, args.offset_x, args.offset_y,
                         args.exposure_time, args.gain)

    h, w = frame.shape[:2]
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    print()
    print(f"素材尺寸 {w} x {h}")
    print(f"灰度 min {g.min()} max {g.max()} mean {g.mean():.1f}  "
          f"过曝(>250)占比 {(g > 250).mean() * 100:.1f}%")
    write_image("_roi_full.png", frame)
    print("已存全幅原图 _roi_full.png")

    from ultralytics import YOLO
    model = YOLO(args.model)
    print("模型类别：", model.names)
    print()
    print(f"搜索参数：ROI 尺寸 {args.sizes}  x  推理尺寸 {args.imgsz}  conf {args.conf}")
    print("（液滴在训练分布里约 %d~%d px）" % (TRAIN_LO, TRAIN_HI))
    print("-" * 78)

    results = sweep(model, frame, args.sizes, args.imgsz, args.conf, args.device)

    print("-" * 78)
    good = [r for r in results if r["droplet"] > 0]
    good.sort(key=lambda r: (-r["droplet"], r["sec"]))
    if not good:
        print("所有组合都没检出 droplet。")
        print("可能原因：对焦没到位 / 视场里根本没有液滴 / 光照把液滴冲没了。")
        print("建议：重对焦后再跑一次；或把 --conf 降到 0.05 试。")
        draw_report(frame, results, "_roi_report.png")
        return 2

    print("能检出 droplet 的组合（按检出数排序）：")
    for r in good[:8]:
        print(f"  ROI {r['size']:5d}  imgsz {r['imgsz']:5d}  放大 {r['zoom']:4.2f}x"
              f"  液滴 {r['droplet']:3d} 个  平均置信度 {r['avg_conf']:.2f}"
              f"  液滴在输入中 {r['infer_px']:5.1f}px  用时 {r['sec']:.1f}s")

    top = draw_report(frame, results, "_roi_report.png")
    print()
    print("已存命中分布图 _roi_report.png")

    # ---- 推荐相机 ROI：用一个窗口把命中框全包住（留 12% 余量），再对齐到 8 的倍数
    if top and top["hits"]:
        xs = [b[0] for b, _ in top["hits"]] + [b[2] for b, _ in top["hits"]]
        ys = [b[1] for b, _ in top["hits"]] + [b[3] for b, _ in top["hits"]]
        pad_x = (max(xs) - min(xs)) * 0.12 + 120
        pad_y = (max(ys) - min(ys)) * 0.12 + 120
        x0 = min(xs) - pad_x; x1 = max(xs) + pad_x
        y0 = min(ys) - pad_y; y1 = max(ys) + pad_y
        # 尽量做成正方形，且不小于最佳 ROI 尺寸
        side = max(x1 - x0, y1 - y0, top["size"])
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        x0 = max(0, cx - side / 2); y0 = max(0, cy - side / 2)
        x1 = min(w, x0 + side); y1 = min(h, y0 + side)
        # 海康 ROI 要求宽高是 8 的倍数、偏移是 8 的倍数
        def align8(v, lo=0):
            return int(max(lo, round(v / 8.0) * 8))
        rw = align8(x1 - x0, 64)
        rh = align8(y1 - y0, 64)
        rx = align8(x0)
        ry = align8(y0)
        if rx + rw > w:
            rx = align8(w - rw)
        if ry + rh > h:
            ry = align8(h - rh)
        print()
        print("=" * 78)
        print("推荐参数（直接复制到启动脚本或命令行）")
        print("=" * 78)
        print(f"    --width {rw} --height {rh} "
              f"--offset-x {rx} --offset-y {ry} --imgsz {top['imgsz']}")
        print()
        print(f"    => 该 ROI 内液滴约占 {top['infer_px']:.0f} px / imgsz {top['imgsz']} 输入")
        print(f"    => 覆盖液滴区域 {rw} x {rh} px（全幅 {w} x {h} 的 "
              f"{rw * rh / (w * h) * 100:.0f}%）")
        with open("_roi_recommend.txt", "w", encoding="utf-8") as fh:
            fh.write(f"--width {rw} --height {rh} --offset-x {rx} --offset-y {ry} "
                     f"--imgsz {top['imgsz']}\n")
        print()
        print("（同内容已写入 _roi_recommend.txt）")
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
