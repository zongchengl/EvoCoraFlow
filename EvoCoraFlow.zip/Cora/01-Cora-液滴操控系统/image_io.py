"""OpenCV image I/O through Python paths, including Unicode on Windows."""
from pathlib import Path

import cv2
import numpy as np


def read_image(path, flags=cv2.IMREAD_COLOR):
    try:
        data = Path(path).read_bytes()
    except OSError:
        return None
    return cv2.imdecode(np.frombuffer(data, dtype=np.uint8), flags) if data else None


def write_image(path, image, params=None):
    destination = Path(path)
    ok, buffer = cv2.imencode(destination.suffix or ".png", image, params or [])
    if not ok:
        raise OSError(f"Cannot encode image: {destination.name}")
    destination.write_bytes(buffer.tobytes())
    return True
