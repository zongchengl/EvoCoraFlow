# -*- coding: utf-8 -*-
"""Offline tests for the multi-objective route archive."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from multiobjective_planner import generate_candidate_paths, path_objectives


class SeededPlanner:
    calls = 0

    def __init__(self, bounds, obstacles, **kwargs):
        self.offset = SeededPlanner.calls
        SeededPlanner.calls += 1

    def plan(self, start, goal):
        y = 250.0 + (self.offset % 4) * 120.0
        return [start, (500.0, y), goal]


class MultiObjectivePathTests(unittest.TestCase):
    def test_single_pareto_elite_still_supports_differential_mutation(self):
        SeededPlanner.calls = 0
        # Force one nondominated elite while retaining multiple safe parents.
        with patch("multiobjective_planner.pareto_front", side_effect=lambda items: items[:1]):
            path, info = generate_candidate_paths(
                start=(100., 500.), goal=(900., 500.), obstacles=[],
                bounds=(0., 0., 1000., 1000.), planner_class=SeededPlanner,
                planner_kwargs={}, candidate_count=3, mutation_generations=1)
        self.assertIsNotNone(path)
        self.assertGreaterEqual(info["candidate_count"], 1)

    def test_elite_archive_returns_in_bounds_collision_free_candidate(self):
        SeededPlanner.calls = 0
        start, goal = (100.0, 500.0), (900.0, 500.0)
        obstacle = SimpleNamespace(center=(500.0, 500.0), radius=80.0)
        path, info = generate_candidate_paths(
            start=start, goal=goal, obstacles=[obstacle],
            bounds=(0.0, 0.0, 1000.0, 1000.0),
            planner_class=SeededPlanner,
            planner_kwargs={"step_size": 40.0, "smooth_attempts": 0},
            candidate_count=4, seed=23, mutation_generations=0)
        self.assertIsNotNone(path)
        self.assertGreaterEqual(info["candidate_count"], 1)
        self.assertGreaterEqual(info["pareto_count"], 1)
        self.assertEqual(info["method"], "AEG-RRT")
        self.assertEqual(path[0], start)
        self.assertEqual(path[-1], goal)
        metrics = path_objectives(path, [obstacle])
        self.assertGreater(metrics["clearance"], 0)
        self.assertIn("smoothness", metrics)
        self.assertIn("density", metrics)

    def test_empty_planner_result_is_reported_without_fabricated_path(self):
        class FailedPlanner:
            def __init__(self, *args, **kwargs):
                pass

            def plan(self, *_args):
                return None

        path, info = generate_candidate_paths(
            start=(10.0, 10.0), goal=(90.0, 90.0), obstacles=[],
            bounds=(0.0, 0.0, 100.0, 100.0),
            planner_class=FailedPlanner, planner_kwargs={},
            candidate_count=2, mutation_generations=0)
        self.assertIsNone(path)
        self.assertEqual(info["candidate_count"], 0)

    def test_out_of_bounds_candidate_is_rejected(self):
        class OutOfBoundsPlanner:
            def __init__(self, *args, **kwargs):
                pass

            def plan(self, start, goal):
                return [start, (120.0, 50.0), goal]

        path, info = generate_candidate_paths(
            start=(10.0, 10.0), goal=(90.0, 90.0), obstacles=[],
            bounds=(0.0, 0.0, 100.0, 100.0),
            planner_class=OutOfBoundsPlanner, planner_kwargs={},
            candidate_count=2, mutation_generations=0)
        self.assertIsNone(path)
        self.assertEqual(info["candidate_count"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
