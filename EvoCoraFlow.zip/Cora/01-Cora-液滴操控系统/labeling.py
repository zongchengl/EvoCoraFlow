# -*- coding: utf-8 -*-
"""液滴分组与字母编号（Cora 的核心算法之一）。

编号规则（按需求）：
    - 同一类液滴共用一个字母：A1、A2、A3 ……
    - 出现不同类时换下一个字母：B1、B2 ……
    - 组内顺序：从左到右、从上到下。

分组策略 group_mode：
    class  按 YOLO 类别名分组（模型输出多个类别时天然可用）
    color  按液滴区域的视觉颜色聚类 —— 当前模型只有 droplet 一类，
           用这个区分矿物油 / 牛奶 / 染色水 等不同种类
    size   按液滴直径聚类
    none   不分类，全部归 A 组
    auto   类别数 > 1 → class；否则有画面 → color；再否则 none

编号稳定性：
    检测框本身有抖动，若每帧纯按坐标重排，液滴轻微晃动就会导致编号互换。
    这里对坐标做指数平滑（EMA）后再排序，保留"位置决定编号"的语义，
    同时抑制噪声引起的无意义跳号。
"""

import math
import statistics
from collections import Counter
from dataclasses import dataclass, field

import numpy as np

try:
    import cv2
except ImportError:  # 允许在无 OpenCV 环境下做纯逻辑单测
    cv2 = None


LETTER_POOL = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

# 默认颜色聚类容差（归一化后加权欧氏距离，越小越严格）
DEFAULT_COLOR_TOLERANCE = 0.30
DEFAULT_SIZE_TOLERANCE = 0.28
# 组间排序用字母顺序，组内排序用行优先
DEFAULT_ROW_TOLERANCE_RATIO = 1.6   # 行判定阈值 = 中位直径 × 该系数
# 半径低于「中位半径 × 该系数」的检测会被当成误检丢掉。激光光斑被模型
# 认成 droplet 时，半径可能明显小于真实液滴。
DEFAULT_MIN_RADIUS_RATIO = 0.5


@dataclass
class Droplet:
    """一个带编号的液滴。"""
    det: dict = None                 # 原始检测（name/conf/center/xyxy）
    center: tuple = (0.0, 0.0)
    radius: float = 35.0
    feature: tuple = None            # 分组特征（颜色或尺寸）
    group: str = "A"                 # 组字母
    number: int = 0                  # 组内序号
    label: str = ""                  # 完整编号 "A1"
    raw_index: int = -1              # 在原始 detections 中的下标
    raw_center: tuple = None         # 未平滑的实测中心
    identity: str = None             # 持续跟踪的内部身份

    @property
    def name(self):
        return (self.det or {}).get("name", "droplet")

    @property
    def conf(self):
        return float((self.det or {}).get("conf", 1.0))

    def to_dict(self):
        return {
            "label": self.label,
            "group": self.group,
            "number": self.number,
            "center": (round(float(self.center[0]), 1), round(float(self.center[1]), 1)),
            "radius": round(float(self.radius), 1),
            "name": self.name,
            "conf": round(self.conf, 3),
        }


# ---------------------------------------------------------------- 几何工具
def det_center(det):
    c = det.get("center")
    if c is None:
        return None
    return (float(c[0]), float(c[1]))


def det_bbox(det):
    box = det.get("xyxy")
    if box is None:
        return None
    x1, y1, x2, y2 = [float(v) for v in box[:4]]
    return (x1, y1, x2, y2)


def det_radius(det, default=35.0):
    box = det_bbox(det)
    if box is None:
        return float(default)
    x1, y1, x2, y2 = box
    return max(4.0, 0.5 * max(abs(x2 - x1), abs(y2 - y1)))


def is_droplet(det):
    return det.get("name") != "laser"


def dist(a, b):
    return math.hypot(float(a[0]) - float(b[0]), float(a[1]) - float(b[1]))


def _hungarian(cost_matrix):
    """Minimum-cost assignment for a rectangular matrix with rows <= columns."""
    rows = len(cost_matrix)
    if not rows:
        return []
    columns = len(cost_matrix[0])
    if rows > columns or any(len(row) != columns for row in cost_matrix):
        raise ValueError("assignment matrix must be rectangular with rows <= columns")
    u = [0.0] * (rows + 1)
    v = [0.0] * (columns + 1)
    matched_row = [0] * (columns + 1)
    previous_column = [0] * (columns + 1)
    for row in range(1, rows + 1):
        matched_row[0] = row
        current_column = 0
        minimum = [float("inf")] * (columns + 1)
        used = [False] * (columns + 1)
        while True:
            used[current_column] = True
            current_row = matched_row[current_column]
            delta = float("inf")
            next_column = 0
            for column in range(1, columns + 1):
                if used[column]:
                    continue
                value = (float(cost_matrix[current_row - 1][column - 1])
                         - u[current_row] - v[column])
                if value < minimum[column]:
                    minimum[column] = value
                    previous_column[column] = current_column
                if minimum[column] < delta:
                    delta, next_column = minimum[column], column
            for column in range(columns + 1):
                if used[column]:
                    u[matched_row[column]] += delta
                    v[column] -= delta
                else:
                    minimum[column] -= delta
            current_column = next_column
            if matched_row[current_column] == 0:
                break
        while True:
            next_column = previous_column[current_column]
            matched_row[current_column] = matched_row[next_column]
            current_column = next_column
            if current_column == 0:
                break
    assignment = [-1] * rows
    for column in range(1, columns + 1):
        if matched_row[column]:
            assignment[matched_row[column] - 1] = column - 1
    return assignment


# ---------------------------------------------------------------- 颜色特征
def sample_color(frame, center, radius, inner_ratio=0.55):
    """取液滴中心圆形区域的 HSV 中位数，作为颜色特征（h, s, v）。

    比取整个 bbox 更稳：液滴是圆的，bbox 四角是油层背景，会污染特征。
    """
    if frame is None or cv2 is None:
        return None
    h, w = frame.shape[:2]
    cx, cy = float(center[0]), float(center[1])
    r = max(3, int(radius * inner_ratio))
    x0, x1 = int(max(0, cx - r)), int(min(w, cx + r + 1))
    y0, y1 = int(max(0, cy - r)), int(min(h, cy + r + 1))
    if x1 - x0 < 3 or y1 - y0 < 3:
        return None
    patch = frame[y0:y1, x0:x1]
    if patch.size == 0:
        return None
    # 圆形掩膜，只保留液滴内部
    yy, xx = np.ogrid[y0:y1, x0:x1]
    mask = (xx - cx) ** 2 + (yy - cy) ** 2 <= (r * 0.92) ** 2
    if not mask.any():
        return None
    hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)
    pixels = hsv[mask]
    if pixels.size == 0:
        return None
    med = np.median(pixels, axis=0)
    return (float(med[0]), float(med[1]), float(med[2]))


def size_feature(radius):
    return (float(radius),)


def color_distance(a, b):
    """归一化加权距离。色相是环形量，需要处理 0/180 环绕。

    色调权重给得高：不同种类的液滴（矿物油 / 牛奶 / 染色水）在画面上
    最直观的差别就是色调和饱和度，尺寸反而常常一样。
    """
    if a is None or b is None:
        return 1e9
    dh = abs(a[0] - b[0])
    dh = min(dh, 180.0 - dh) / 180.0      # 环形 -> 0..0.5
    ds = abs(a[1] - b[1]) / 255.0
    dv = abs(a[2] - b[2]) / 255.0
    return math.sqrt((2.2 * dh) ** 2 + (1.0 * ds) ** 2 + (0.6 * dv) ** 2)


def size_distance(a, b):
    if not a or not b:
        return 1e9
    m = max(a[0], b[0])
    if m <= 1e-6:
        return 0.0
    return abs(a[0] - b[0]) / m


# ---------------------------------------------------------------- 聚类
def cluster_by_feature(items, distance_fn, tolerance):
    """贪心单链聚类：与已有簇中心足够近就并入，否则新建一簇。

    返回 [[下标, ...], ...]，按各簇"最左上成员"排序，保证编号可复现。
    """
    clusters = []          # [{"members": [...], "sum": [...], "n": int}]
    for idx, item in enumerate(items):
        best = None
        best_d = None
        for cluster in clusters:
            c = tuple(v / cluster["n"] for v in cluster["sum"])
            d = distance_fn(item, c)
            if best_d is None or d < best_d:
                best, best_d = cluster, d
        if best is not None and best_d <= tolerance:
            best["members"].append(idx)
            for i, v in enumerate(item):
                best["sum"][i] += v
            best["n"] += 1
        else:
            clusters.append({"members": [idx], "sum": list(item), "n": 1})

    def anchor(cluster):
        first = items[cluster["members"][0]]
        return first

    clusters.sort(key=lambda c: (anchor(c)[1], anchor(c)[0]))
    return [c["members"] for c in clusters]


# ---------------------------------------------------------------- 排序
def order_row_major(items, row_tolerance=None, key_center=None):
    """从上到下、从左到右排序（行优先）。

    先按 y 分行：与当前行的平均 y 相差不超过 row_tolerance 视为同一行；
    行内按 x 升序；最后按行序拼接。
    """
    if not items:
        return []
    center_of = key_center or (lambda it: it.center)
    radii = [getattr(it, "radius", 35.0) or 35.0 for it in items]
    if row_tolerance is None:
        med = statistics.median(radii) if radii else 35.0
        row_tolerance = max(8.0, med * DEFAULT_ROW_TOLERANCE_RATIO)

    ordered = sorted(items, key=lambda it: center_of(it)[1])
    rows = [[ordered[0]]]
    for item in ordered[1:]:
        row_y = sum(center_of(m)[1] for m in rows[-1]) / len(rows[-1])
        if abs(center_of(item)[1] - row_y) <= row_tolerance:
            rows[-1].append(item)
        else:
            rows.append([item])

    result = []
    for row in rows:
        result.extend(sorted(row, key=lambda it: center_of(it)[0]))
    return result


# ---------------------------------------------------------------- 主类
class DropletLabeler:
    """把每帧的检测结果变成带 A1/A2/B1 编号的液滴列表。"""

    def __init__(self,
                 group_mode="auto",
                 row_tolerance=None,
                 color_tolerance=DEFAULT_COLOR_TOLERANCE,
                 size_tolerance=DEFAULT_SIZE_TOLERANCE,
                 smooth_alpha=0.55,
                 max_match_dist=None,
                 min_radius_ratio=DEFAULT_MIN_RADIUS_RATIO,
                 max_missing_frames=8,
                 association_hysteresis=0.18):
        self.group_mode = group_mode
        self.row_tolerance = row_tolerance
        self.color_tolerance = color_tolerance
        self.size_tolerance = size_tolerance
        # 平滑权重：新观测占 alpha，历史占 1-alpha。越大越跟手，越小越稳。
        self.smooth_alpha = smooth_alpha
        self.max_match_dist = max_match_dist
        self.min_radius_ratio = min_radius_ratio
        self.max_missing_frames = max(0, int(max_missing_frames))
        self.association_hysteresis = max(0.0, float(association_hysteresis))
        self._tracks = {}             # identity -> predicted/smoothed track state
        self._next_track_id = 1
        self._next_group_id = 0
        self._next_number = {}
        self._group_features = {}
        self._class_groups = {}
        self.last_info = {}
        self.dropped_last = 0        # 上一帧剔掉了几个疑似误检

    # ------------------------------------------------------------ 对外入口
    def update(self, detections, frame=None):
        """输入一帧检测，返回 (droplets, info)。"""
        raw = []
        for idx, det in enumerate(detections or []):
            if not is_droplet(det):
                continue
            center = det_center(det)
            if center is None:
                continue
            raw.append((idx, det, center, det_radius(det)))

        raw, self.dropped_last = self._drop_outliers(raw)
        raw, merged = self._dedup_overlap(raw)
        self.dropped_last += merged

        if not raw:
            self._age_missing_tracks(set())
            self.last_info = {"count": 0, "groups": {}, "mode": self.group_mode}
            return [], self.last_info

        # ---- 1. 以运动预测做全局一对一关联，再对中心作 EMA 平滑。
        matched = self._associate(raw)
        items = []
        for raw_i, (idx, det, center, radius) in enumerate(raw):
            track = matched.get(raw_i)
            if track is not None and self.smooth_alpha < 1.0:
                px, py = track["smooth_center"]
                a = self.smooth_alpha
                smooth = (center[0] * a + px * (1 - a), center[1] * a + py * (1 - a))
            else:
                smooth = center
            if track is not None:
                identity = track["identity"]
            else:
                identity = f"T{self._next_track_id}"
                self._next_track_id += 1
            item = Droplet(det=det, center=smooth, radius=radius, raw_index=idx,
                           identity=identity)
            item.raw_center = center
            if track is not None:
                item.group = track["group"]
                item.label = track["label"]
                item.number = track["number"]
            items.append(item)

        # ---- 2. 分组
        mode = self._resolve_mode(items, frame)
        groups_idx = self._group(items, frame, mode)
        self._assign_stable_groups(items, groups_idx, mode)

        # ---- 3. 新目标只分配新编号；已关联目标保留原编号。
        group_letters = {}
        for members in groups_idx:
            cluster_items = [items[index] for index in members]
            group = cluster_items[0].group if cluster_items else "A"
            # A track whose class/group changed is treated as a new label;
            # otherwise its old number is retained through crossings.
            used = set()
            for item in cluster_items:
                prefix = item.label[:1] if item.label else ""
                suffix = item.label[1:] if item.label else ""
                if prefix != group or not suffix.isdigit() or int(suffix) in used:
                    item.label, item.number = "", 0
                else:
                    item.number = int(suffix)
                    used.add(item.number)
            next_number = self._next_number.get(group, 0)
            for item in order_row_major(cluster_items, self.row_tolerance):
                if item.label:
                    next_number = max(next_number, item.number)
                    continue
                next_number += 1
                while next_number in used:
                    next_number += 1
                item.number = next_number
                item.label = f"{group}{next_number}"
                used.add(next_number)
            self._next_number[group] = max(next_number, self._next_number.get(group, 0))

        for item in items:
            group_letters[item.group] = group_letters.get(item.group, 0) + 1
        droplets = sorted(items, key=lambda d: (d.group, d.number, d.center[1], d.center[0]))

        # ---- 4. 保存短时轨迹历史；漏检时保留编号，超时后释放关联。
        active_ids = set()
        for item in droplets:
            old = next((track for track in self._tracks.values()
                        if track["identity"] == item.identity), None)
            if old is None:
                velocity = (0.0, 0.0)
            else:
                vx = item.raw_center[0] - old["center"][0]
                vy = item.raw_center[1] - old["center"][1]
                alpha = 1.0 - self.association_hysteresis
                velocity = (old["velocity"][0] * (1.0 - alpha) + vx * alpha,
                            old["velocity"][1] * (1.0 - alpha) + vy * alpha)
            track = {
                "identity": item.identity, "label": item.label,
                "group": item.group, "number": item.number,
                "center": item.raw_center, "smooth_center": item.center,
                "velocity": velocity, "radius": item.radius,
                "name": item.name, "feature": item.feature,
                "misses": 0,
            }
            self._tracks[item.identity] = track
            active_ids.add(item.identity)
        self._age_missing_tracks(active_ids)

        self.last_info = {
            "count": len(droplets),
            "groups": group_letters,
            "mode": mode,
            "labels": [d.label for d in droplets],
            "dropped": self.dropped_last,
        }
        return droplets, self.last_info

    def relabel(self):
        """丢掉历史，下一帧完全按当前位置重新编号。"""
        self._tracks.clear()
        self._next_track_id = 1
        self._next_group_id = 0
        self._next_number.clear()
        self._group_features.clear()
        self._class_groups.clear()

    # ------------------------------------------------------------ 身份关联
    def _associate(self, raw):
        """Predictive one-to-one assignment with a hysteresis gate.

        Matching all candidate pairs globally prevents two detections from
        inheriting the same old label. A short motion prediction and a
        radius-scaled retention margin reduce identity flips near crossings.
        """
        tracks = list(self._tracks.values())
        if not tracks or not raw:
            return {}
        # Rectangular Hungarian assignment with one private dummy choice per
        # previous track. The dummy cost permits births/deaths without forcing
        # a bad match when droplets appear, disappear or cross.
        row_count = len(tracks)
        detection_count = len(raw)
        unmatched_cost = 0.92
        invalid_cost = 1e6
        cost = [[invalid_cost] * detection_count
                + [unmatched_cost + dummy * 1e-7 for dummy in range(row_count)]
                for _ in tracks]
        for track_i, track in enumerate(tracks):
            for raw_i, (_, det, center, radius) in enumerate(raw):
                if det.get("name", "droplet") != track["name"]:
                    continue
                limit = (float(self.max_match_dist) if self.max_match_dist is not None
                         else max(100.0, 3.0 * (radius + track["radius"])))
                vx, vy = track["velocity"]
                predicted = (track["center"][0] + vx, track["center"][1] + vy)
                gap = dist(center, predicted)
                retention = self.association_hysteresis * min(radius, track["radius"])
                if gap > limit + retention:
                    cost[track_i][raw_i] = invalid_cost
                else:
                    cost[track_i][raw_i] = max(0.0, gap - retention) / max(1.0, limit)

        assignment = _hungarian(cost)
        assignments = {}
        for track_i, column in enumerate(assignment):
            if 0 <= column < detection_count and cost[track_i][column] < unmatched_cost:
                assignments[column] = tracks[track_i]
        return assignments

    def _age_missing_tracks(self, active_ids):
        for identity in list(self._tracks):
            track = self._tracks[identity]
            if identity in active_ids:
                continue
            track["misses"] += 1
            if track["misses"] > self.max_missing_frames:
                del self._tracks[identity]

    def _allocate_group(self):
        index = self._next_group_id
        self._next_group_id += 1
        return LETTER_POOL[index] if index < len(LETTER_POOL) else f"G{index + 1}"

    @staticmethod
    def _feature_center(features, mode):
        features = [tuple(float(v) for v in feature) for feature in features if feature]
        if not features:
            return None
        if mode == "color":
            # Hue is circular in HSV; average its sine/cosine instead of
            # incorrectly placing red samples near the midpoint of the scale.
            angles = [feature[0] * 2.0 * math.pi / 180.0 for feature in features]
            hue = (math.atan2(sum(math.sin(a) for a in angles),
                              sum(math.cos(a) for a in angles)) % (2 * math.pi)) * 180.0 / (2 * math.pi)
            return (hue, statistics.median(feature[1] for feature in features),
                    statistics.median(feature[2] for feature in features))
        return tuple(statistics.median(feature[i] for feature in features)
                     for i in range(len(features[0])))

    def _assign_stable_groups(self, items, groups_idx, mode):
        tolerance = self.color_tolerance if mode == "color" else self.size_tolerance
        for cluster_index, members in enumerate(groups_idx):
            cluster_items = [items[index] for index in members]
            matched_groups = [item.group for item in cluster_items if item.label]
            majority = Counter(matched_groups).most_common(1)
            if mode in ("none", "off", "single"):
                group = "A"
                self._class_groups.setdefault("__all__", group)
            elif mode == "class":
                class_name = cluster_items[0].name
                group = self._class_groups.get(class_name)
                if group is None and majority:
                    group = majority[0][0]
                if group is None:
                    group = self._allocate_group()
                self._class_groups[class_name] = group
            elif majority:
                group = majority[0][0]
            else:
                feature_center = self._feature_center(
                    [item.feature for item in cluster_items], mode)
                best_group, best_distance = None, None
                distance_fn = color_distance if mode == "color" else size_distance
                for candidate_group, candidate_feature in self._group_features.items():
                    value = distance_fn(feature_center, candidate_feature)
                    if best_distance is None or value < best_distance:
                        best_group, best_distance = candidate_group, value
                group = (best_group if best_group is not None and best_distance <= tolerance
                         else self._allocate_group())

            for item in cluster_items:
                if not item.label:
                    item.group = group
            center = self._feature_center([item.feature for item in cluster_items], mode)
            if center is not None:
                old_center = self._group_features.get(group)
                if old_center is None:
                    self._group_features[group] = center
                else:
                    a = 0.25
                    if mode == "color":
                        hue_delta = ((center[0] - old_center[0] + 90.0) % 180.0) - 90.0
                        hue = (old_center[0] + a * hue_delta) % 180.0
                        tail = tuple(old_center[i] * (1.0 - a) + center[i] * a
                                     for i in range(1, len(center)))
                        self._group_features[group] = (hue, *tail)
                    else:
                        self._group_features[group] = tuple(
                            old_center[i] * (1.0 - a) + center[i] * a
                            for i in range(len(center)))

    def _drop_outliers(self, raw):
        """丢掉明显不像液滴的检测，返回 (保留项, 丢弃个数)。

        最典型的误检是**激光光斑**：亮、圆、小，模型很容易给它一个
        droplet 标签。把它编号进去有两个坏处 —— 用户数液滴个数会数错，
        而且落点规划会为了避开这个"幽灵液滴"而缩手缩脚。
        判据只用一条：半径不到同伴中位数的一半。真液滴之间尺寸差异
        很少有这么悬殊，而光斑通常小一大截。
        """
        ratio = float(self.min_radius_ratio or 0)
        if ratio <= 0 or len(raw) < 3:
            return raw, 0
        radii = sorted(float(t[3]) for t in raw)
        med = radii[len(radii) // 2]
        if med <= 0:
            return raw, 0
        limit = med * ratio
        kept = [t for t in raw if float(t[3]) >= limit]
        if not kept:                      # 全被滤掉说明判据不适用，原样返回
            return raw, 0
        return kept, len(raw) - len(kept)

    def _dedup_overlap(self, raw, overlap=0.75):
        """合并「同一颗液滴被检出两次」的情况。

        模型可能同时给出一个紧框和一个松框，或者一个目标既被当成
        droplet 又被当成 solid —— 两个框中心几乎重合、半径差一倍。
        不合并的话，编号里会出现两个名字指向同一颗液滴（比如 C1/C2、D1/D2），
        用户说「把 C1 移过去」就可能动错目标。

        判据：中心距 < 两者较大半径 × overlap 就视为同一个，
        保留优先级更高的那个（droplet 优先于 solid，其次看置信度、半径）。
        """
        if len(raw) < 2:
            return raw, 0

        priority = {"droplet": 2, "solid": 1}

        def rank(item):
            det = item[1]
            try:
                conf = float(det.get("conf", 0.0))
            except Exception:
                conf = 0.0
            return (priority.get(det.get("name"), 0), conf, float(item[3]))

        order = sorted(range(len(raw)), key=lambda i: rank(raw[i]), reverse=True)
        kept = []
        for i in order:
            ci, ri = raw[i][2], float(raw[i][3])
            if any(dist(ci, raw[j][2]) < max(ri, float(raw[j][3])) * overlap
                   for j in kept):
                continue
            kept.append(i)
        if len(kept) == len(raw):
            return raw, 0
        kept.sort()
        return [raw[i] for i in kept], len(raw) - len(kept)

    def _resolve_mode(self, items, frame):
        mode = (self.group_mode or "auto").lower()
        if mode != "auto":
            return mode
        names = {it.name for it in items}
        if len(names) > 1:
            return "class"
        if frame is not None and cv2 is not None:
            return "color"
        return "none"

    def _group(self, items, frame, mode):
        n = len(items)
        if mode in ("none", "off", "single") or n <= 1:
            return [list(range(n))]

        if mode == "class":
            buckets = {}
            for i, it in enumerate(items):
                buckets.setdefault(it.name, []).append(i)
            return self._sort_groups(list(buckets.values()), items)

        if mode == "size":
            feats = [size_feature(it.radius) for it in items]
            groups = cluster_by_feature(feats, size_distance, self.size_tolerance)
            return self._sort_groups(groups, items)

        if mode == "color":
            feats = []
            for it in items:
                f = sample_color(frame, it.center, it.radius)
                if f is None:
                    f = (90.0, 40.0, 160.0)      # 取不到颜色时给中性值
                it.feature = f
                feats.append(f)
            groups = cluster_by_feature(feats, color_distance, self.color_tolerance)
            return self._sort_groups(groups, items)

        return [list(range(n))]

    def _sort_groups(self, groups, items):
        """按「组内最靠左上那个成员」给组排序，决定字母怎么发。

        不排的话字母顺序取决于聚类算法先碰到哪个点 —— 曾出现过画面最右边
        那组拿到 A、左上的反而排到 B，用户看到的编号就完全不是
        "从左往右、从上往下"的直觉顺序了。排完之后左上角那组恒为 A。
        """
        def anchor(members):
            first = order_row_major([items[m] for m in members], self.row_tolerance)[0]
            return (first.center[1], first.center[0])

        return sorted(groups, key=anchor)


# ---------------------------------------------------------------- 便捷函数
def format_roster(droplets, info=None):
    """生成给用户看的液滴清单。"""
    if not droplets:
        return "当前画面里没有检测到液滴。"
    lines = []
    total = len(droplets)
    groups = info.get("groups", {}) if info else {}
    head = f"当前画面共 {total} 个液滴"
    if groups:
        head += "，" + "，".join(f"{k}类 {v} 个" for k, v in groups.items())
    lines.append(head + "：")
    for d in droplets:
        x, y = d.center
        lines.append(f"  {d.label:<4} 位置({x:.0f}, {y:.0f})  半径{d.radius:.0f}px")
    return "\n".join(lines)
