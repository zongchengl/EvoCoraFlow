# -*- coding: utf-8 -*-
"""Cora 画面标注。

把识别结果画成人能一眼看懂的样子：
    - 每个液滴框上标编号 A1 / A2 / B1，同类同色
    - 源液滴高亮，目标落点画十字靶
    - 顶部状态条 + 底部指令回显（中文，借助 PIL 渲染）

OpenCV 的 putText 画不了中文，所以中文一律走 PIL 渲染成小图再贴回去，
并按 (文本, 字号, 颜色) 缓存，避免每帧重复排版拖慢主循环。
"""

import os

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    Image = ImageDraw = ImageFont = None


# 按组分色（BGR），同类液滴同色，便于肉眼区分 A/B/C 类
GROUP_COLORS = [
    (255, 120, 60),      # 蓝
    (60, 200, 255),      # 橙黄
    (120, 230, 120),     # 绿
    (230, 120, 220),     # 紫
    (80, 220, 230),      # 黄
    (255, 180, 120),     # 浅蓝
    (150, 255, 200),     # 薄荷
]

LASER_COLOR = (0, 0, 255)
SOURCE_COLOR = (0, 255, 255)
TARGET_COLOR = (255, 0, 255)
PANEL_BG = (32, 28, 24)
TEXT_LIGHT = (240, 240, 240)
TEXT_DIM = (170, 170, 170)
WARN_COLOR = (60, 180, 255)
OK_COLOR = (120, 230, 120)

_FONT_CANDIDATES = [
    r"C:\Windows\Fonts\msyh.ttc",      # 微软雅黑
    r"C:\Windows\Fonts\msyhl.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    r"C:\Windows\Fonts\simsun.ttc",
]

_font_cache = {}
_text_cache = {}
_TEXT_CACHE_LIMIT = 512


def group_color(letter):
    if not letter:
        return GROUP_COLORS[0]
    idx = (ord(letter.upper()) - ord("A")) % len(GROUP_COLORS)
    return GROUP_COLORS[idx]


def _find_font_path():
    for p in _FONT_CANDIDATES:
        if os.path.exists(p):
            return p
    return None


def get_font(size):
    if ImageFont is None:
        return None
    if size in _font_cache:
        return _font_cache[size]
    path = _find_font_path()
    try:
        font = ImageFont.truetype(path, size) if path else ImageFont.load_default()
    except Exception:
        font = ImageFont.load_default()
    _font_cache[size] = font
    return font


# ---------------------------------------------------------------- 中文绘制
def render_text_patch(text, size, color, bg_color=None, padding=6):
    """把一段中文渲染成 BGR 小图（带透明通道不需要，直接实底贴图）。"""
    key = (text, size, color, bg_color, padding)
    cached = _text_cache.get(key)
    if cached is not None:
        return cached
    if Image is None:
        return None

    font = get_font(size)
    try:
        bbox = font.getbbox(text)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    except Exception:
        tw, th = len(text) * size // 2, size

    w = max(1, tw + padding * 2)
    h = max(1, th + padding * 2)
    img = Image.new("RGB", (w, h), bg_color if bg_color else (0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.text((padding - bbox[0], padding - bbox[1]), text, font=font,
              fill=(color[2], color[1], color[0]))
    patch = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

    if len(_text_cache) > _TEXT_CACHE_LIMIT:
        _text_cache.clear()
    _text_cache[key] = patch
    return patch


def draw_cn_text(img, text, org, size=26, color=TEXT_LIGHT, bg_color=None,
                 padding=6, center=False):
    """在图上画中文。org 为左上角（center=True 时按中心对齐）。"""
    patch = render_text_patch(text, size, color, bg_color, padding)
    if patch is None:
        if cv2 is not None:
            cv2.putText(img, text, (int(org[0]), int(org[1])), cv2.FONT_HERSHEY_SIMPLEX,
                        0.6, color, 2)
        return
    ph, pw = patch.shape[:2]
    x, y = int(org[0]), int(org[1])
    if center:
        x -= pw // 2
        y -= ph // 2
    h, w = img.shape[:2]
    x0, y0 = max(0, x), max(0, y)
    x1, y1 = min(w, x + pw), min(h, y + ph)
    if x1 <= x0 or y1 <= y0:
        return
    img[y0:y1, x0:x1] = patch[y0 - y:y1 - y, x0 - x:x1 - x]


def draw_panel(img, rect, alpha=0.72, color=PANEL_BG):
    """半透明底板，让文字在任何背景上都看得清。"""
    x1, y1, x2, y2 = [int(v) for v in rect]
    h, w = img.shape[:2]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w, x2), min(h, y2)
    if x2 <= x1 or y2 <= y1:
        return
    roi = img[y1:y2, x1:x2]
    overlay = np.full_like(roi, color, dtype=np.uint8)
    cv2.addWeighted(overlay, alpha, roi, 1 - alpha, 0, roi)


# ---------------------------------------------------------------- 元素绘制
def _rect_hit(a, b):
    return not (a[0] >= b[2] or a[2] <= b[0] or a[1] >= b[3] or a[3] <= b[1])


def _place_label(cx, cy, r, pw, ph, shape, avoid=()):
    """给编号底板挑一个不被压住的位置：上方 → 下方 → 右侧 → 左侧。

    状态面板固定在左上角，而液滴可能正好停在那个角落。不避让的话
    编号会被面板整个吞掉，用户就分不清"要动的是哪一个"了。
    """
    h, w = shape[:2]
    candidates = [
        (cx - pw // 2, cy - r - ph - 4),      # 上
        (cx - pw // 2, cy + r + 4),           # 下
        (cx + r + 6, cy - ph // 2),           # 右
        (cx - r - 6 - pw, cy - ph // 2),      # 左
    ]
    for tx, ty in candidates:
        if tx < 0 or ty < 0 or tx + pw > w or ty + ph > h:
            continue
        rect = (tx, ty, tx + pw, ty + ph)
        if any(_rect_hit(rect, a) for a in (avoid or ())):
            continue
        return tx, ty
    return candidates[0]


def draw_droplet(img, droplet, is_source=False, is_target=False, dim=False, avoid=()):
    """画单个液滴：检测框 + 圆圈 + 编号底板。

    配色规则：框色一律用组色，同组同色、跨帧稳定。
    源液滴额外套一圈白环并加 ▶ 前缀，而不是把组色整个换掉 ——
    换色之后 A1 会跟别的组撞色，看着像临时改了分组，反而更乱。
    """
    color = group_color(droplet.group)
    if is_target:
        color = TARGET_COLOR

    cx, cy = int(droplet.center[0]), int(droplet.center[1])
    r = max(6, int(droplet.radius))

    box = droplet.det.get("xyxy") if droplet.det else None
    if box:
        x1, y1, x2, y2 = [int(v) for v in box]
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 3 if is_source else 2)

    cv2.circle(img, (cx, cy), r, color, 3 if is_source else 2)
    if is_source:
        # 白环 + 白心：扫一眼就知道"要动的是它"
        cv2.circle(img, (cx, cy), r + 5, (255, 255, 255), 2)
        cv2.circle(img, (cx, cy), max(2, r // 4), (255, 255, 255), -1)

    # 编号贴在小圆点底板上，避免压住液滴本体
    # 前缀用「源」而不是 ▶/箭头类符号：PIL 配雅黑时这些符号常缺字形，
    # 渲染出来是个豆腐块方框，反而更难认。
    size = 26 if is_source else 22
    label = f"源{droplet.label}" if is_source else droplet.label
    patch = render_text_patch(label, size, (255, 255, 255), color, 5)
    if patch is not None:
        ph, pw = patch.shape[:2]
        tx, ty = _place_label(cx, cy, r, pw, ph, img.shape, avoid)
        h, w = img.shape[:2]
        x0, y0 = max(0, tx), max(0, ty)
        x1, y1 = min(w, tx + pw), min(h, ty + ph)
        if x1 > x0 and y1 > y0:
            img[y0:y1, x0:x1] = patch[y0 - ty:y1 - ty, x0 - tx:x1 - tx]


def draw_target(img, point, label="目标"):
    """画目标落点：十字靶 + 文字。"""
    if point is None:
        return
    x, y = int(point[0]), int(point[1])
    cv2.drawMarker(img, (x, y), TARGET_COLOR, markerType=cv2.MARKER_CROSS,
                   markerSize=34, thickness=2)
    cv2.circle(img, (x, y), 6, TARGET_COLOR, 2)
    draw_cn_text(img, label, (x + 20, y - 34), size=20, color=TARGET_COLOR,
                 bg_color=(40, 40, 70), padding=3)


def status_bar_rect(n_lines, origin=(12, 10), width=None, size=24):
    """预先算出状态面板占的矩形，供编号标签避让。"""
    line_h = size + 12
    return (origin[0], origin[1],
            origin[0] + (width or 520), origin[1] + n_lines * line_h + 14)


def draw_status_bar(img, lines, origin=(12, 10), width=None, size=24):
    """左上角信息面板。lines 为 [(文本, 颜色), ...]。返回占用矩形。"""
    if not lines:
        return None
    line_h = size + 12
    h = len(lines) * line_h + 14
    w = width or 520
    draw_panel(img, (origin[0], origin[1], origin[0] + w, origin[1] + h))
    for i, item in enumerate(lines):
        text, color = item if isinstance(item, (tuple, list)) else (item, TEXT_LIGHT)
        draw_cn_text(img, text, (origin[0] + 14, origin[1] + 8 + i * line_h),
                     size=size, color=color)
    return status_bar_rect(len(lines), origin, width, size)


def draw_hint_bar(img, text, size=24, color=TEXT_LIGHT):
    """底部指令回显条。"""
    if not text:
        return
    h, w = img.shape[:2]
    bar_h = size + 24
    draw_panel(img, (0, h - bar_h, w, h), alpha=0.78)
    draw_cn_text(img, text, (16, h - bar_h + 10), size=size, color=color)


def draw_cora_frame(frame, droplets, info=None, source_label=None, target_point=None,
                    target_label=None, status_lines=None, hint=None, laser_center=None):
    """在一帧上叠加完整的 Cora 标注层。"""
    if cv2 is None:
        return frame
    view = frame.copy()

    # 先算出面板占位，编号才不会画到面板底下
    avoid = []
    if status_lines:
        avoid.append(status_bar_rect(len(status_lines)))
    if hint:
        h = view.shape[0]
        avoid.append((0, h - 48, view.shape[1], h))

    if laser_center is not None:
        lx, ly = int(laser_center[0]), int(laser_center[1])
        cv2.drawMarker(view, (lx, ly), LASER_COLOR, markerType=cv2.MARKER_TILTED_CROSS,
                       markerSize=30, thickness=3)

    for d in droplets:
        draw_droplet(view, d,
                     is_source=(d.label == source_label),
                     is_target=(d.label == target_label),
                     avoid=avoid)

    if target_point is not None:
        draw_target(view, target_point, target_label or "目标")

    if status_lines:
        draw_status_bar(view, status_lines)

    if hint:
        draw_hint_bar(view, hint)

    return view


def build_status_lines(info, executor_state=None, extra=None):
    """组装左上角状态面板的文本。"""
    lines = []
    if info:
        groups = info.get("groups") or {}
        cnt = info.get("count", 0)
        mode_cn = {"class": "按类别", "color": "按颜色", "size": "按尺寸",
                   "none": "不分类"}.get(info.get("mode"), info.get("mode"))
        count_title = "实验保留候选" if info.get("visual_experiment") else "液滴"
        lines.append((f"{count_title} {cnt} 个   分组方式：{mode_cn}", TEXT_LIGHT))
        if info.get("visual_experiment"):
            lines.append(("未校准实验：不代表真实数量，禁止电机执行", WARN_COLOR))
        dropped = int(info.get("dropped") or 0)
        if dropped:
            lines.append((f"已忽略 {dropped} 个疑似误检（激光光斑/噪点）", WARN_COLOR))
        visual_rejected = int(info.get("visual_rejected") or 0)
        if visual_rejected:
            lines.append((f"低纹理待复核 {visual_rejected} 个候选（实验隐藏）", WARN_COLOR))
        if groups:
            summary = "  ".join(f"{k}类×{v}" for k, v in groups.items())
            lines.append((summary, OK_COLOR))
        tracking = info.get("tracking") or {}
        if tracking:
            laser_mode = tracking.get("laser", "lost")
            source_mode = tracking.get("source", "idle")
            lines.append((f"跟踪：激光 {laser_mode} / 源液滴 {source_mode}", TEXT_DIM))
        scale = info.get("scale_recommendation") or {}
        if scale.get("predicted_network_pixels"):
            lines.append((f"尺度建议 imgsz={scale.get('imgsz')}，目标≈{scale.get('predicted_network_pixels')}px",
                          TEXT_DIM))
    else:
        lines.append(("未检测到液滴", WARN_COLOR))
    if executor_state:
        lines.append((executor_state, TEXT_DIM))
    for item in (extra or []):
        lines.append(item)
    return lines

