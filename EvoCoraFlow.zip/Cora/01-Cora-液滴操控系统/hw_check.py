# -*- coding: utf-8 -*-
"""硬件体检：确认相机能出图、电机串口能通信。

只做只读探测，不发任何运动指令，安全。
Cora 启动失败时先跑这个，能快速定位是相机、串口还是模型的问题。
"""
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

OK, BAD, WARN = "[ OK ]", "[FAIL]", "[WARN]"


def sec(title):
    print("\n" + "=" * 62)
    print("  " + title)
    print("=" * 62)


def main():
    sec("Cora 硬件体检")

    # ------------------------------------------------ 1. 海康 SDK 路径
    try:
        import droplet_core as core
        root = core.MVS_ROOT
        print(f"{OK} 已导入 droplet_core")
        print(f"     海康 SDK 路径：{root}")
        print(f"     {'存在' if os.path.isdir(root) else '!! 不存在'}")
    except Exception:
        print(f"{BAD} 导入 droplet_core 失败：")
        traceback.print_exc()
        return 1

    if getattr(core, "MvImport", None) is None and not hasattr(core, "MvCamera"):
        print(f"{BAD} 海康 MvImport 未加载，相机无法使用")
    else:
        print(f"{OK} 海康 MvImport 已加载")

    # ------------------------------------------------ 2. 相机
    sec("2. 海康相机")
    cam = None
    try:
        t0 = time.time()
        cam = core.HikCamera()
        dt = time.time() - t0
        print(f"{OK} 相机已打开（耗时 {dt:.1f}s）")

        for attempt in range(3):
            fr = cam.get_frame(timeout=2000)
            if fr is not None:
                print(f"{OK} 取帧成功，尺寸 {fr.shape}  dtype={fr.dtype}")
                m = float(fr.mean())
                print(f"     亮度均值 {m:.1f}  "
                      f"({'画面偏暗/盖着镜头盖' if m < 8 else '正常'})")
                break
            print(f"     第 {attempt + 1} 次取帧返回空，重试…")
            time.sleep(0.3)
        else:
            print(f"{BAD} 连续取帧失败，相机可能被别的程序占用（MVS 客户端？）")
    except Exception as exc:
        print(f"{BAD} 相机打开失败：{type(exc).__name__}: {exc}")
    finally:
        if cam is not None:
            try:
                cam.close()
                print(f"{OK} 相机已释放")
            except Exception:
                pass

    # ------------------------------------------------ 3. 串口列表
    sec("3. 串口设备")
    try:
        import serial.tools.list_ports as lp
        ports = list(lp.comports())
        if not ports:
            print(f"{BAD} 没枚举到任何串口")
        for p in ports:
            print(f"{OK} {p.device:<6} {p.description}")
    except Exception as exc:
        print(f"{BAD} 枚举串口失败：{exc}")

    # ------------------------------------------------ 4. 电机通信
    sec("4. 步进电机（只读查询，不运动）")
    try:
        import serial
    except ImportError:
        print(f"{BAD} 未安装 pyserial")
        return 1

    # 从命令行取；未指定时交给核心模块自动探测
    port = sys.argv[1] if len(sys.argv) > 1 else None
    print(f"     目标端口：{port}  波特率 115200")
    try:
        ser = serial.Serial(port, 115200, timeout=0.3)
        time.sleep(0.4)
        print(f"{OK} 串口打开成功")

        # 三轴状态查询：0x1F 0x6B（只读，不会让电机转）
        alive = 0
        for axis, addr in (("X", 1), ("Y", 2), ("Z", 3)):
            ser.reset_input_buffer()
            ser.write(bytes([addr, 0x1F, 0x6B]))
            time.sleep(0.12)
            reply = ser.read(64)
            if reply:
                alive += 1
                print(f"{OK} {axis} 轴（地址 {addr}）有应答，"
                      f"{len(reply)} 字节: {' '.join(f'{b:02X}' for b in reply[:12])}")
            else:
                print(f"{WARN} {axis} 轴（地址 {addr}）无应答")
        if alive == 0:
            print(f"{WARN} 三个轴都没应答 —— 检查：驱动器供电？波特率？\n"
                  f"       也可能是该查询指令不被你的固件支持（不一定是故障）")
        ser.close()
        print(f"{OK} 串口已释放")
    except Exception as exc:
        print(f"{BAD} 串口失败：{type(exc).__name__}: {exc}")
        print("       常见原因：端口号不对 / 被别的软件占用 / 驱动没装")

    # ------------------------------------------------ 5. 模型
    sec("5. 检测模型")
    wp = os.path.join(HERE, "weights", "best.pt")
    if os.path.exists(wp):
        print(f"{OK} {wp}  ({os.path.getsize(wp) / 1e6:.1f} MB)")
        try:
            from ultralytics import YOLO
            m = YOLO(wp)
            print(f"{OK} 模型可加载，类别：{m.names}")
        except Exception as exc:
            print(f"{BAD} 模型加载失败：{exc}")
    else:
        print(f"{BAD} 找不到 {wp}")

    sec("体检结束")
    return 0


if __name__ == "__main__":
    sys.exit(main())
