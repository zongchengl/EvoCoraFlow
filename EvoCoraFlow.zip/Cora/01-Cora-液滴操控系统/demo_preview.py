# -*- coding: utf-8 -*-
"""Cora 视觉自检：用一张仿真画面跑通完整链路，生成标注效果图。

链路：造画面 → 模拟检测结果 → 分组编号 → 听懂中文指令 → 规划落点 → 叠加标注。
不需要相机、不需要模型、不需要电机，纯粹用来肉眼核对：
    · 同类液滴是否拿到同一个字母、序号是否从左到右自上而下
    · 中文是否渲染正常（OpenCV 原生 putText 画不出汉字，这里走 PIL）
    · 源液滴 / 目标落点 / 状态面板的位置和可读性
    · 落点有没有避开其它液滴

跑法：python demo_preview.py
输出：Cora-示例1-移到右侧.png、Cora-示例2-停靠到B1旁边.png、Cora-仿真原图.png
"""

import os
import sys

import cv2
from image_io import read_image, write_image
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import overlay                                                # noqa: E402
from command_parser import parse                              # noqa: E402
from executor import (pick_droplet, plan_beside_point,        # noqa: E402
                      plan_landing_point)
from labeling import DropletLabeler, format_roster            # noqa: E402

W, H = 1280, 720
CLEARANCE = 1.35
RNG = np.random.default_rng(7)

# 三类液滴：矿物油（偏琥珀）、染色水（偏青蓝）、牛奶（偏白）
LAYOUT = [
    # (cx, cy, r, BGR, 说明)
    (250, 205, 46, (196, 152, 96), "矿物油"),
    (470, 190, 44, (196, 152, 96), "矿物油"),
    (688, 228, 48, (196, 152, 96), "矿物油"),
    (300, 468, 40, (86, 200, 226), "染色水"),
    (562, 450, 42, (86, 200, 226), "染色水"),
    (902, 296, 38, (240, 240, 240), "牛奶"),
    (1012, 520, 36, (240, 240, 240), "牛奶"),
]
LASER_XY = (352, 300)


# ---------------------------------------------------------------- 造画面
def make_background(w=W, h=H):
    """暗场显微视野：中间亮、四周暗，叠一点传感器噪声。"""
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = w * 0.5, h * 0.5
    r = np.sqrt(((xx - cx) / (w * 0.62)) ** 2 + ((yy - cy) / (h * 0.62)) ** 2)
    glow = np.clip(1.15 - r, 0.18, 1.0)
    base = np.dstack([glow * 40, glow * 47, glow * 58])
    noise = RNG.normal(0, 3.0, (h, w, 1))
    img = np.clip(base + noise, 0, 255).astype(np.uint8)
    return cv2.GaussianBlur(img, (3, 3), 0)


def draw_drop(img, cx, cy, r, bgr):
    """画一个有点体积感的液滴：边缘亮、中心略暗，模拟液滴的透镜效应。"""
    pad = int(r) + 8
    x0, y0 = int(cx - pad), int(cy - pad)
    sx0, sy0 = max(0, x0), max(0, y0)
    sub = img[sy0:y0 + 2 * pad, sx0:x0 + 2 * pad]
    if sub.size == 0:
        return
    yy, xx = np.mgrid[0:sub.shape[0], 0:sub.shape[1]].astype(np.float32)
    dcx, dcy = cx - sx0, cy - sy0
    dist = np.sqrt((xx - dcx) ** 2 + (yy - dcy) ** 2) / float(r)
    shade = 1.0 - 0.40 * np.clip(1.0 - dist, 0, 1) ** 1.5
    rim = np.clip((dist - 0.72) / 0.28, 0, 1) * (dist < 1.02)
    color = np.array(bgr, dtype=np.float32).reshape(1, 1, 3)
    layer = color * shade[..., None] + rim[..., None] * 68.0
    mask = (dist < 1.02)[..., None]
    sub[:] = np.clip(np.where(mask, layer, sub.astype(np.float32)), 0, 255).astype(np.uint8)


def build_scene():
    frame = make_background()
    for cx, cy, r, bgr, _n in LAYOUT:
        draw_drop(frame, cx, cy, r, bgr)
    cv2.circle(frame, LASER_XY, 9, (120, 255, 160), -1)
    cv2.circle(frame, LASER_XY, 17, (66, 176, 118), 2)
    return frame


def fake_detections():
    """模拟 YOLO 的输出格式：name / conf / center / xyxy。"""
    dets = [{"name": "droplet", "conf": 0.94,
             "center": (float(cx), float(cy)),
             "xyxy": (cx - r, cy - r, cx + r, cy + r)}
            for cx, cy, r, _b, _n in LAYOUT]
    dets.append({"name": "laser", "conf": 0.88,
                 "center": (float(LASER_XY[0]), float(LASER_XY[1])),
                 "xyxy": (LASER_XY[0] - 9, LASER_XY[1] - 9,
                          LASER_XY[0] + 9, LASER_XY[1] + 9)})
    return dets


# ---------------------------------------------------------------- 单条指令
def render(text, out_path, frame, droplets, info, laser_center):
    cmd = parse(text)
    print(f"\n指令：{text}")
    print(f"  解析 → {cmd.describe()}")
    if cmd.action != "move":
        print("  （这条不是移动指令，跳过）")
        return None

    source, why = pick_droplet(cmd.source, droplets, frame.shape, laser_center)
    if source is None:
        print(f"  源液滴没找到：{why}")
        return None
    print(f"  源 → {source.label} @ {source.center}（{why}）")

    target_point, why_t = None, ""
    spec = cmd.target or {}
    if spec.get("kind") == "region":
        target_point, why_t = plan_landing_point(
            spec["region"], source, droplets, frame.shape, clearance=CLEARANCE)
    elif spec.get("kind") == "label":
        want = str(spec["label"]).upper()
        anchor = next((d for d in droplets if d.label.upper() == want), None)
        if anchor is None:
            why_t = f"画面里没有 {want}"
        elif anchor.label == source.label:
            why_t = "源和目标不能是同一个液滴"
        else:
            target_point, why_t = plan_beside_point(
                anchor, source, droplets, frame.shape, clearance=CLEARANCE,
                exclude=(source.label,))
    elif spec.get("kind") == "delta":
        from executor import plan_delta_point
        target_point, why_t = plan_delta_point(
            spec.get("region"), spec.get("amount"), spec.get("unit"),
            source, frame.shape, px_per_mm=5.0)
    else:
        why_t = f"不认识的落点描述：{spec}"
    if target_point is None:
        print(f"  目标落点没算出来：{why_t}")
        return None
    print(f"  落点 → ({target_point[0]:.0f}, {target_point[1]:.0f})（{why_t}）")

    status = overlay.build_status_lines(
        info,
        executor_state=f"执行中：{source.label} → 目标点",
        extra=[(f"源液滴：{source.label}（白环标记）", (255, 255, 255)),
               (f"目标落点：({target_point[0]:.0f}, {target_point[1]:.0f})", overlay.TARGET_COLOR)],
    )
    view = overlay.draw_cora_frame(
        frame, droplets, info=info,
        source_label=source.label, target_point=target_point,
        target_label="目标", status_lines=status,
        hint=f"指令：{text}    按 Q 退出",
        laser_center=laser_center,
    )
    write_image(out_path, view)
    print(f"  已保存：{out_path}")
    return view


def main():
    frame = build_scene()
    raw_path = os.path.join(HERE, "Cora-仿真原图.png")
    write_image(raw_path, frame)
    print(f"仿真画面已保存：{raw_path}")

    labeler = DropletLabeler(group_mode="auto")
    drops, info = labeler.update(fake_detections(), frame)
    print("\n" + format_roster(drops, info))

    laser_center = LASER_XY
    render("把最左边的液滴移到右侧",
           os.path.join(HERE, "Cora-示例1-移到右侧.png"),
           frame, drops, info, laser_center)

    # 第二条指令换一组编号：把 A 类第一个挪到 B1 旁边
    render("把 A1 移到 B1 旁边",
           os.path.join(HERE, "Cora-示例2-停靠到B1旁边.png"),
           frame, drops, info, laser_center)
    print("\n全部完成。打开上面三张图核对标注效果。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
