# -*- coding: utf-8 -*-
"""生成启动脚本（GBK 编码）。

踩坑记录：bat 里写中文时，文件必须是 GBK(ANSI) 编码。
    cmd 是按**当前代码页**逐行解码 bat 的，UTF-8 的中文会被拆成乱码字节，
    某些字节恰好被当成命令分隔符，于是出现
    "'机echo' 不是内部或外部命令" 这种莫名其妙的报错。
    另外不要加 chcp 65001 —— Python 3.6+ 在 Windows 控制台走 WriteConsoleW，
    本来就按 Unicode 输出中文，改代码页反而容易把两边搞拧。
"""

import os

HERE = os.path.dirname(os.path.abspath(__file__))
PY = "python"


def bat(title, banner, body):
    lines = [
        "@echo off",
        f"title {title}",
        'cd /d "%~dp0"',
        "",
        "echo " + "=" * 60,
    ]
    lines += [f"echo  {b}" if b else "echo." for b in banner]
    lines += [
        "echo " + "=" * 60,
        "echo.",
        "",
    ]
    lines += body.split("\n")
    lines += [
        "",
        "echo.",
        "echo 程序已退出。",
        "pause",
        "",
    ]
    return "\r\n".join(lines)


FILES = {}

# 工业相机通常同一时刻只允许一个程序访问。厂商客户端开着时，
# 采集程序可能无法获得独占权限；启动前给出可见提示。
# 这段在启动前自动检查，让用户按键确认后再关，不做静默强杀。
MVS_GUARD = """
tasklist /fi "imagename eq MVS.exe" 2>nul | find /i "MVS.exe" >nul
if not errorlevel 1 (
    echo [!] 检测到相机厂商客户端正在运行。
    echo     厂商客户端可能占用相机，请确认后关闭再继续。
    echo.
    echo     按任意键关闭该客户端并继续，或关掉本窗口取消。
    pause >nul
    taskkill /f /im MVS.exe >nul 2>&1
    echo     客户端已关闭，继续启动。
    echo.
)
"""

FILES["1-启动-Cora(真实设备).bat"] = bat(
    "Cora - 液滴操控指令助手（真实设备）",
    ["Cora 液滴操控指令助手 —— 真实设备模式",
     "相机：工业相机        电机：串口自动探测",
     "",
     "画面窗口里按 [空格] 输入指令，按 [Q] 退出",
     "曝光偏亮/偏暗时，改下面的 --exposure-time 数值"],
    MVS_GUARD + "\n"
    f'"{PY}" cora.py --source hik --exposure-time 15000 --gain 0',
)

FILES["6-硬件体检.bat"] = bat(
    "Cora - 硬件体检",
    ["Cora 硬件体检 —— 只读探测，不会让电机运动",
     "依次检查：工业相机 SDK / 相机取图 / 串口 / 电机应答 / 模型加载"],
    f'"{PY}" hw_check.py',
)

FILES["7-曝光扫描.bat"] = bat(
    "Cora - 曝光扫描",
    ["拍一组不同曝光的图，拼成 _expo_sweep.png 供你挑档位",
     "偏亮就往小改 --exposure-time，偏暗往大改；--gain 建议保持 0"],
    f'"{PY}" exposure_sweep.py',
)

FILES["2-启动-Cora(演示模式).bat"] = bat(
    "Cora - 液滴操控指令助手（演示模式）",
    ["Cora 液滴操控指令助手 —— 演示模式",
     "相机：普通 USB 摄像头      电机：不发送指令（只看不动）",
     "",
     "接电机之前先在这里把识别和编号跑通",
     "画面窗口里按 [空格] 输入指令，按 [Q] 退出"],
    f'"{PY}" cora.py --source usb:0 --no-motor',
)

FILES["3-启动-Cora(图片调试).bat"] = bat(
    "Cora - 液滴操控指令助手（图片调试）",
    ["Cora 液滴操控指令助手 —— 图片调试模式",
     "输入源：Cora-仿真原图.png（不接相机、不接电机）",
     "",
     "没有硬件也能看算法效果：分组编号、目标落点",
     "启动后会自动演示两条指令，之后可以自己按空格输入",
     "退出时把标注图存成 Cora-图片调试结果.png，按 Q 退出"],
    "\n".join([
        'if not exist "Cora-仿真原图.png" python demo_preview.py',
        f'"{PY}" cora.py ^',
        '    --source "image:Cora-仿真原图.png" ^',
        "    --no-motor ^",
        '    --save-annotated "Cora-图片调试结果.png" ^',
        '    --command "有哪些液滴" ^',
        '    --command "把最左边的液滴移到右侧"',
    ]),
)

FILES["4-跑离线自测.bat"] = bat(
    "Cora - 离线自测",
    ["Cora 离线自测 —— 不需要相机、模型和电机",
     "检查编号算法、指令解析、落点规划是否全部正常"],
    f'"{PY}" selftest.py',
)

FILES["5-生成标注示例图.bat"] = bat(
    "Cora - 生成标注示例图",
    ["生成 Cora 标注效果示例图",
     "仿真画面演示：分组编号 - 中文指令 - 落点规划 - 画面标注"],
    f'"{PY}" demo_preview.py',
)

def write_bat(path, content):
    """按 cmd 的要求写 bat：GBK 编码 + CRLF 换行。

    两个都是硬性要求，缺一个就出怪问题：
      · 编码必须是 GBK —— cmd 按当前代码页逐行解码，UTF-8 的中文会被拆成
        乱码字节，某些字节恰好被当成命令分隔符，于是报
        "'机echo' 不是内部或外部命令" 这种莫名其妙的错。
      · 换行必须是 CRLF —— 只给 LF 时 cmd 会把行拼错，
        goto/label 全部失效，双击表现为"打不开"或一闪而过。
    """
    text = content.replace("\r\n", "\n").replace("\n", "\r\n")
    with open(path, "w", encoding="gbk", newline="") as fh:
        fh.write(text)


for name, content in FILES.items():
    path = os.path.join(HERE, name)
    write_bat(path, content)
    print("已生成（GBK + CRLF）：", name)


# ---- 包内总入口：双击一个文件，菜单里选模式。脚本不写入用户桌面，
# 这样整理包可以直接复制到另一台电脑而不留下机器专属路径。
DESKTOP_MENU = """@echo off
chcp 936 >nul
title Cora - 液滴操控指令助手
cd /d "%~dp0"

:menu
cls
echo ============================================================
echo     Cora   液滴操控指令助手
echo ============================================================
echo.
echo      [1]  图片调试      不接硬件，先看识别和编号对不对
echo      [2]  演示模式      接 USB 摄像头，只识别不拖液滴
echo      [3]  真实设备      工业相机 + 步进电机，执行任务
echo      [4]  离线自测      逻辑回归检查
echo      [5]  生成示例图    输出三张标注效果图
echo      [6]  硬件体检      相机、串口、电机、模型逐项检查
echo      [7]  曝光扫描      画面太亮/太暗时用来挑档位
echo      [0]  退出
echo.
set "choice="
set /p choice=   请输入序号后回车：
if "%choice%"=="1" goto pic
if "%choice%"=="2" goto demo
if "%choice%"=="3" goto real
if "%choice%"=="4" goto test
if "%choice%"=="5" goto sample
if "%choice%"=="6" goto hw
if "%choice%"=="7" goto expo
if "%choice%"=="0" exit /b
goto menu

:pic
call "3-启动-Cora(图片调试).bat"
goto menu

:demo
call "2-启动-Cora(演示模式).bat"
goto menu

:real
call "1-启动-Cora(真实设备).bat"
goto menu

:test
call "4-跑离线自测.bat"
goto menu

:sample
call "5-生成标注示例图.bat"
goto menu

:hw
call "6-硬件体检.bat"
goto menu

:expo
call "7-曝光扫描.bat"
goto menu
"""

write_bat(os.path.join(HERE, "0-选择运行模式.bat"), DESKTOP_MENU)
print("已生成包内入口：0-选择运行模式.bat")

