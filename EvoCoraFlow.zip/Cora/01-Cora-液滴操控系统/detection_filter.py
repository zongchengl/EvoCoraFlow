# -*- coding: utf-8 -*-
"""Experimental appearance comparison, NOT a validated droplet classifier.

A flat patch may still be a genuine transparent droplet. Defaults therefore
preserve every detection. Explicit experiments must be confined to no-motor
mode by the application; never use these thresholds to clear obstacles.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from time import time_ns

import cv2
import numpy as np


@dataclass(frozen=True)
class VisualQuality:
    texture_std: float
    edge_mean: float
    contrast: float


class DropletVisualFilter:
    def __init__(self, enabled=False, min_texture_std=24.0, min_edge_mean=55.0):
        self.enabled = bool(enabled)
        self.min_texture_std = float(min_texture_std)
        self.min_edge_mean = float(min_edge_mean)
        for value in (self.min_texture_std, self.min_edge_mean):
            if not math.isfinite(value) or value < 0:
                raise ValueError("Visual thresholds must be finite and nonnegative")

    @staticmethod
    def _quality(frame, det):
        if not isinstance(frame, np.ndarray) or frame.dtype != np.uint8 or frame.ndim not in (2, 3):
            return None
        try:
            x1, y1, x2, y2 = [float(v) for v in det["xyxy"]]
            if not all(math.isfinite(v) for v in (x1, y1, x2, y2)):
                return None
            h, w = frame.shape[:2]
            # Partial/bad boxes are not evidence that an object is absent.
            if x1 <= 0 or y1 <= 0 or x2 >= w or y2 >= h or x2-x1 < 5 or y2-y1 < 5:
                return None
            x1, y1, x2, y2 = [int(round(v)) for v in (x1, y1, x2, y2)]
        except (KeyError, TypeError, ValueError, OverflowError):
            return None
        patch = frame[y1:y2, x1:x2]
        if patch.ndim == 2:
            gray = patch
        elif patch.shape[2] == 3:
            gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
        else:
            return None
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
        p10, p90 = np.percentile(gray, [10, 90])
        return VisualQuality(float(gray.std()), float(np.hypot(gx, gy).mean()), float(p90-p10))

    def filter(self, detections, frame):
        """Return (experimentally retained, flagged), leaving raw data intact.

        Flagged means weak texture/edges, NOT verified false positive.
        Laser, solid, unknown classes and unassessed boxes are never removed.
        """
        detections = list(detections or [])
        if not self.enabled:
            return detections, []
        kept, flagged = [], []
        for det in detections:
            quality = self._quality(frame, det) if det.get("name") == "droplet" else None
            if (quality is not None and quality.texture_std < self.min_texture_std
                    and quality.edge_mean < self.min_edge_mean):
                flagged.append(dict(det, filter_reason="low_information_patch",
                                    visual_quality=asdict(quality)))
            else:
                kept.append(det)
        return kept, flagged


class DetectionRecorder:
    """Save a bounded sample of paired ORIGINAL frames/boxes, once per packet.

    No hardware or model is opened here. Each recorder uses a separate run
    directory so repeated launches do not overwrite earlier evidence.
    """
    def __init__(self, directory, limit=10):
        if not 1 <= int(limit) <= 100:
            raise ValueError("Diagnostic frame limit must be between 1 and 100")
        self.directory = Path(directory) / ("run_" + str(time_ns()))
        self.limit = int(limit)
        self.seen = set()

    def record(self, packet, flagged):
        seq = packet.get("seq")
        frame = packet.get("frame")
        if seq is None or seq in self.seen or len(self.seen) >= self.limit or frame is None:
            return False
        self.directory.mkdir(parents=True, exist_ok=True)
        stem = self.directory / ("frame_%04d" % len(self.seen))
        ok, encoded = cv2.imencode(".png", frame)
        if not ok:
            raise OSError("Failed to encode diagnostic frame")
        data = {k: packet.get(k) for k in ("seq", "frame_seq", "timestamp", "infer_ms", "detections")}
        data.update(frame_shape=list(frame.shape), experimental_flagged=flagged,
                    warning="Appearance heuristic only; flagged is NOT ground truth.")
        # Encode JSON before writing either file, so serialization errors are explicit.
        text = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False)
        encoded.tofile(str(stem.with_suffix(".png")))
        stem.with_suffix(".json").write_text(text, encoding="utf-8")
        self.seen.add(seq)
        return True
