# -*- coding: utf-8 -*-
"""Offline replay PID optimization; uses only a synthetic trace."""
import json
import tempfile
import unittest
from pathlib import Path

import droplet_core as core
import cora
from types import SimpleNamespace


def make_trace(count=12):
    trace = []
    for index in range(count):
        ex = 120.0 - 2.0 * index
        ey = 90.0 - 1.5 * index
        trace.append({
            "ex": ex,
            "ey": ey,
            "prev_ex": ex + 2.0 if index else ex,
            "prev_ey": ey + 1.5 if index else ey,
            "dt": 0.1,
            "prev_y_speed": 10.0,
            "prev_x_speed": 8.0,
        })
    return trace


class ReplayPidTests(unittest.TestCase):
    def test_main_chain_exports_recorded_trace_without_device_access(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "logs" / "trace.json"
            app = cora.CoraApp.__new__(cora.CoraApp)
            app.args = SimpleNamespace(metrics_file=str(path))
            app.control_state = {"metrics": {"trace": make_trace()}}
            app._save_metrics()
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["trace"],
                             make_trace())

    def test_plant_estimate_uses_motion_instead_of_waypoint_error_jumps(self):
        trace = []
        for i in range(6):
            trace.append({"ex": 1000 * i, "ey": -1000 * i, "dt": 0.1,
                          "prev_ex": -999, "prev_ey": 999,
                          "prev_x_speed": 10, "prev_y_speed": 10,
                          "laser_position": (2 * i + 2, 3 * i + 3),
                          "previous_laser_position": (2 * i, 3 * i),
                          "pair_valid": True})
        plant = core.estimate_replay_plant(trace)
        self.assertAlmostEqual(plant["pixels_per_speed_second_x"], 2.)
        self.assertAlmostEqual(plant["pixels_per_speed_second_y"], 3.)
        self.assertIsNone(core.estimate_replay_plant([
            dict(sample, pair_valid=False) for sample in trace]))

    def test_final_generation_offspring_can_be_returned_as_best(self):
        optimizer = core.ReplayGuidedRebirthOptimizer(
            lambda vector: (vector[0], (vector[0],)), [(0., 1.)],
            population_size=4, generations=1, seed=5)
        optimizer._random_vector = lambda: [0.8]
        result = optimizer.optimize()
        self.assertLess(result["score"], 0.8)
        self.assertAlmostEqual(result["score"],
                               min(obj[0] for _, obj in result["archive"]))

    def test_tune_writes_explicit_rrt_scope_and_profile_loads_to_rrt_gains(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            metrics = root / "metrics.json"
            output = root / "profile.json"
            metrics.write_text(json.dumps({"trace": make_trace()}), encoding="utf-8")
            args = core.build_arg_parser().parse_args([
                "--tune-from-metrics", str(metrics),
                "--tuned-params-file", str(output),
                "--tune-population", "4", "--tune-generations", "1",
            ])
            result = core.run_pid_tuning(args)
            saved = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(saved["scope"], "rrt")
            self.assertEqual(saved["replay_samples"], len(make_trace()))
            self.assertIn("kp", saved)
            self.assertEqual(result["scope"], "rrt")

            load_args = core.build_arg_parser().parse_args([])
            scope = core.apply_tuned_pid_params(load_args, str(output))
            self.assertEqual(scope, "rrt")
            self.assertAlmostEqual(load_args.rrt_k, saved["kp"])
            self.assertAlmostEqual(load_args.rrt_ki, saved["ki"])
            self.assertAlmostEqual(load_args.rrt_kd, saved["kd"])
            self.assertNotEqual(load_args.multi_k, saved["kp"])

    def test_invalid_nonfinite_profile_is_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            profile = Path(root) / "invalid.json"
            profile.write_text('{"scope":"rrt","kp":Infinity,"ki":0,"kd":0}',
                               encoding="utf-8")
            args = core.build_arg_parser().parse_args([])
            with self.assertRaisesRegex(ValueError, "有限的非负数"):
                core.apply_tuned_pid_params(args, str(profile))


if __name__ == "__main__":
    unittest.main(verbosity=2)
