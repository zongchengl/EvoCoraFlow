# -*- coding: utf-8 -*-
"""曝光/增益扫描：找出不过曝又能看清液滴的档位。

海康相机的默认参数（15000us / gain 10）在强照明下会严重过曝，
大片死白会让 YOLO 完全检不出液滴。这个脚本拍一组不同曝光的图拼成
一张对比图，肉眼挑一档，再用 --exposure-time 传给 Cora。
"""
import os
import sys
import time

import cv2
from image_io import read_image, write_image
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import droplet_core as core  # noqa: E402

EXPOSURES = [500, 1000, 2000, 4000, 8000, 15000]
GAIN = 0.0
OUT = os.path.join(HERE, "_expo_sweep.png")


def grab(cam, exposure, gain):
    cam.cam.MV_CC_SetEnumValue("ExposureAuto", 0)
    cam.cam.MV_CC_SetFloatValue("ExposureTime", float(exposure))
    cam.cam.MV_CC_SetEnumValue("GainAuto", 0)
    cam.cam.MV_CC_SetFloatValue("Gain", float(gain))
    time.sleep(0.35)
    for _ in range(3):          # 丢几帧让新参数生效
        cam.get_frame(timeout=2000)
    return cam.get_frame(timeout=3000)


def main():
    cam = core.HikCamera()
    print(f"相机已打开：访问模式 {cam.access_mode}")
    try:
        cells = []
        for expo in EXPOSURES:
            fr = grab(cam, expo, GAIN)
            if fr is None:
                print(f"曝光 {expo:>6}us  取帧失败")
                continue
            g = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
            over = (g > 250).mean() * 100
            dark = (g < 8).mean() * 100
            print(f"曝光 {expo:>6}us  均值 {g.mean():6.1f}  "
                  f"过曝 {over:5.1f}%  死黑 {dark:5.1f}%  "
                  f"p50={int(np.percentile(g, 50))}")
            thumb = cv2.resize(fr, (fr.shape[1] // 4, fr.shape[0] // 4),
                               interpolation=cv2.INTER_AREA)
            cv2.putText(thumb, f"expo {expo}us", (12, 34),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
            cells.append(thumb)

        if not cells:
            print("没有任何一档取到图")
            return 1

        rows = []
        for i in range(0, len(cells), 2):
            pair = cells[i:i + 2]
            if len(pair) == 1:
                pair.append(np.zeros_like(pair[0]))
            rows.append(np.hstack(pair))
        sheet = np.vstack(rows)
        h, w = sheet.shape[:2]
        if max(h, w) > 1600:
            s = 1600 / max(h, w)
            sheet = cv2.resize(sheet, (int(w * s), int(h * s)))
        write_image(OUT, sheet)
        print(f"\n对比图已保存：{OUT}")
        return 0
    finally:
        cam.close()
        print("相机已释放")


if __name__ == "__main__":
    sys.exit(main())
