# -*- coding: utf-8 -*-
"""Cora —— 液滴操控指令助手。

一句话控制激光拖拽液滴：
    "把最左边的液滴移到右侧"
    "把 A1 移到 B2 旁边"
    "把所有 A 类液滴依次移到右侧"

Cora 做的事：
    1. 摄像头取帧 → YOLO 识别液滴与激光
    2. 给每个液滴编号（同类同字母 A1/A2，异类换字母 B1/B2；从左到右、从上到下）
    3. 听懂你的中文指令，算出"该动哪个液滴、该停在哪里"
    4. 通过串口驱动步进电机，让激光跟着液滴走，把液滴拖到目标位置

运行示例：
    python cora.py --source hik                  # 真实设备（海康相机 + 步进电机）
    python cora.py --source usb:0 --no-motor     # 普通摄像头演练，不发电机指令
    python cora.py --source image:test.jpg --no-motor   # 用一张图调试算法
"""

import json
import os
import queue
import sys
import threading
import time
import traceback

import cv2
from image_io import read_image, write_image
import numpy as np

if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import droplet_core as core                     # noqa: E402
import overlay                                  # noqa: E402
from command_parser import HELP_TEXT, parse     # noqa: E402
from executor import CoraExecutor               # noqa: E402
from labeling import DropletLabeler, format_roster   # noqa: E402
from detection_filter import DropletVisualFilter, DetectionRecorder   # noqa: E402
from tracking import SingleTargetTracker, recommend_detection_scale   # noqa: E402

WINDOW_NAME = "Cora - 液滴操控指令助手"
QUIT_WORDS = {"quit", "exit", "退出", "关闭", "再见"}


# ---------------------------------------------------------------- 启动自检
def has_tensorrt():
    """判断本机能不能吃 .engine。TensorRT 引擎是编译期产物，换了显卡/驱动/
    CUDA 版本往往就打不开，实验室里更稳的还是 .pt。"""
    try:
        import tensorrt  # noqa: F401
        return True
    except Exception:
        return False


def resolve_device(device):
    """把 auto / 0 / cuda / cpu 解析成 ultralytics 认识的写法。

    踩坑提醒：torch 装的是 CPU 版时，device 给 "0" 会直接抛
    "Torch not compiled with CUDA enabled" 把整个程序拦在启动阶段，
    所以这里提前判一次并静默降级。
    """
    want = str(device).strip().lower()
    has_cuda = False
    if want != "cpu":
        try:
            import torch
            has_cuda = bool(torch.cuda.is_available())
        except Exception:
            has_cuda = False
    if want in ("auto", ""):
        return "0" if has_cuda else "cpu"
    if want == "cpu":
        return "cpu"
    if not has_cuda:
        print(f"[Cora] 提示：本机 torch 没有 CUDA，--device {device} 自动改为 cpu")
        return "cpu"
    return device


def _find_weight(filename, search_dirs):
    """在每个目录里**直接**找同名文件。

    故意不递归：外部资源目录可能很大，递归搜索会拖慢启动。
    需要深一层就用 --model-search 把具体目录写进来。
    """
    for root in search_dirs:
        if not root or not os.path.isdir(root):
            continue
        candidate = os.path.join(root, filename)
        if os.path.isfile(candidate):
            return candidate
    return None


def resolve_model_path(path, search_dirs=()):
    """返回 (真正可用的权重路径, 提示语)。

    查找顺序：原路径 → 同目录同名 .pt → 搜索目录里的同名 .pt。
    这样用户从训练机拷过来的 .engine 打不开时，只要旁边有 .pt 就能直接跑。
    """
    path = os.path.expanduser(str(path).strip().strip('"'))
    stem = os.path.splitext(os.path.basename(path))[0]
    dirs = [os.path.dirname(path)] + list(search_dirs)

    needs_trt = path.lower().endswith(".engine") and not has_tensorrt()
    if os.path.exists(path) and not needs_trt:
        return path, ""

    if needs_trt:
        print("[Cora] 提示：.engine 是 TensorRT 引擎，本机没装 tensorrt，正在找同款 .pt …")
    elif not os.path.exists(path):
        print(f"[Cora] 提示：找不到 {path}，正在搜索同名权重 …")

    alt = _find_weight(stem + ".pt", dirs)
    if alt:
        return alt, f"已改用 {alt}"
    alt = _find_weight("best.pt", dirs)
    if alt:
        return alt, f"已改用 {alt}"

    if needs_trt:
        raise RuntimeError(
            f"{os.path.basename(path)} 需要 tensorrt 才能加载，且没找到对应的 .pt。\n"
            f"        两种办法任选其一：\n"
            f"        1) 直接指定 PyTorch 权重：--model xxx\\best.pt\n"
            f"        2) 装 TensorRT：pip install tensorrt（需与显卡驱动/CUDA 版本匹配）\n"
            f"        搜索范围：{', '.join(d for d in dirs if d)}"
        )
    raise FileNotFoundError(
        f"模型文件不存在：{path}\n"
        f"        可用 --model 指定，或用 --model-search 加搜索目录。"
    )


# ================================================================ 取帧源
class SourceBase:
    name = "输入源"

    def get_frame(self):
        raise NotImplementedError

    def get_frame_with_seq(self, timeout=1.0):
        """给推理线程用：保证序号递增，便于判断是否是新帧。"""
        frame = self.get_frame()
        if frame is None:
            raise TimeoutError("取帧失败")
        self._seq = getattr(self, "_seq", 0) + 1
        return self._seq, frame

    def close(self):
        pass


class HikSource(SourceBase):
    name = "海康工业相机"

    def __init__(self, args):
        self.cam = core.ThreadedHikCamera(
            index=args.camera_index,
            width=args.width,
            height=args.height,
            offset_x=args.offset_x,
            offset_y=args.offset_y,
            exposure_time=args.exposure_time,
            gain=args.gain,
            frame_rate=args.frame_rate,
        )

    def get_frame(self):
        return self.cam.get_frame()

    def get_frame_with_seq(self, timeout=1.0):
        return self.cam.get_frame_with_seq(timeout)

    def close(self):
        self.cam.close()


class UsbSource(SourceBase):
    name = "USB 摄像头"

    def __init__(self, index=0, width=None, height=None):
        backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(int(index), backend)
        if width:
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, float(width))
        if height:
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, float(height))
        if not self.cap.isOpened():
            raise RuntimeError(f"打不开摄像头 {index}；试试 --source usb:1")

    def get_frame(self):
        ok, frame = self.cap.read()
        return frame if ok else None

    def close(self):
        self.cap.release()


class ImageSource(SourceBase):
    name = "静态图片"

    def __init__(self, path):
        if os.path.exists(path):
            self.img = read_image(path)
        else:
            self.img = None
        if self.img is None:
            raise RuntimeError(f"读不到图片：{path}")

    def get_frame(self):
        return self.img.copy()


class VideoFileSource(SourceBase):
    name = "视频文件"

    def __init__(self, path):
        self.cap = cv2.VideoCapture(path)
        if not self.cap.isOpened():
            raise RuntimeError(f"打不开视频：{path}")

    def get_frame(self):
        ok, frame = self.cap.read()
        if not ok:                       # 放到结尾就从头循环
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = self.cap.read()
        return frame if ok else None

    def close(self):
        self.cap.release()


def create_source(spec, args):
    """--source 的解析：hik / usb:0 / image:路径 / video:路径"""
    spec = (spec or "hik").strip()
    low = spec.lower()
    if low in ("hik", "camera", "工业相机"):
        return HikSource(args)
    if low.startswith("usb"):
        idx = 0
        if ":" in spec:
            idx = int(spec.split(":", 1)[1])
        return UsbSource(idx, getattr(args, "usb_width", None), getattr(args, "usb_height", None))
    if low.startswith("image:"):
        return ImageSource(spec.split(":", 1)[1])
    if low.startswith("video:"):
        return VideoFileSource(spec.split(":", 1)[1])
    if low.isdigit():
        return UsbSource(int(low))
    # 当作文件路径处理
    if os.path.exists(spec):
        return VideoFileSource(spec)
    raise RuntimeError(f"无法识别的输入源：{spec}（可用 hik / usb:0 / image:xx.jpg / video:xx.mp4）")


# ================================================================ 主程序
class CoraApp:
    def __init__(self, args):
        # Validate before opening cameras, models, serial ports or worker threads.
        experimental = bool(getattr(args, "visual_filter", False))
        diagnostic_dir = getattr(args, "diagnostic_dir", None)
        if (experimental or diagnostic_dir) and not args.no_motor:
            raise ValueError("视觉过滤实验/原始采样必须使用 --no-motor，不允许驱动电机")
        self.args = args
        self.running = True
        self.cmd_queue = queue.Queue()
        self.hint = "按空格输入指令，例如：把最左边的液滴移到右侧（Q 退出）"
        self.task_note = ""
        self.request_stop = False
        self.last_command = (0, 0)
        self.last_command_time = 0.0
        self.was_arrived = False
        self.frame_index = 0

        warmup = max(1, int(getattr(args, "command_warmup", 5)))
        if args.max_frames:
            # 跑批帧数本来就少时，别让预热把命令全吃掉了
            warmup = min(warmup, max(1, args.max_frames // 2))
        self.command_warmup = warmup
        self.command_timeout = max(3.0, float(getattr(args, "command_timeout", 20.0)))
        self.detector_ready = False
        self.started_at = time.time()
        # 未经原始画面验证的启发式默认关闭，仅无电机模式允许试验。
        self.visual_filter = DropletVisualFilter(
            enabled=experimental,
            min_texture_std=getattr(args, "visual_min_texture", 24.0),
            min_edge_mean=getattr(args, "visual_min_edge", 55.0),
        )
        self.detection_recorder = (DetectionRecorder(
            diagnostic_dir, getattr(args, "diagnostic_frames", 10)) if diagnostic_dir else None)
        self._visual_seq = None
        self._visual_detections = []
        self._visual_flagged = []
        self.laser_tracker = SingleTargetTracker(
            backend=getattr(args, "tracking_backend", "auto"),
            position_alpha=getattr(args, "smooth_alpha", 0.55),
            max_lost=getattr(args, "tracking_max_lost", 8),
        )
        self.source_tracker = SingleTargetTracker(
            backend=getattr(args, "tracking_backend", "auto"),
            position_alpha=getattr(args, "smooth_alpha", 0.55),
            max_lost=getattr(args, "tracking_max_lost", 8),
        )
        self.tracking_meta = {"laser": "lost"}
        self.scale_recommendation = None
        self._scale_reported = False

        self.source = create_source(args.source, args)

        # ---- 模型
        self.model = None
        self.model_path = None
        if not args.no_detect:
            if core.YOLO is None:
                raise RuntimeError("未安装 ultralytics，无法做目标检测；"
                                   "请 pip install ultralytics，或加 --no-detect 只看画面")
            search_dirs = ([os.path.join(HERE, "weights"), HERE]
                           + list(args.model_search))
            model_path, note = resolve_model_path(args.model, search_dirs)
            self.model = core.YOLO(model_path, task="detect")
            self.model_path = model_path
            names = getattr(self.model, "names", None) or {}
            pretty = "、".join(f"{k}={v}" for k, v in sorted(names.items()))
            print(f"[Cora] 模型已加载：{model_path}")
            if note:
                print(f"[Cora] {note}")
            if pretty:
                print(f"[Cora] 可识别类别：{pretty}")

        self.detector = None
        if self.model is not None:
            device = resolve_device(args.device)
            print(f"[Cora] 推理设备：{device}")
            self.detector = core.LatestDetectionWorker(
                camera=self.source, model=self.model,
                imgsz=args.imgsz, conf=args.conf, device=device,
                retain_frame=True,
            )

        # ---- 控制状态
        self.control_state = core.make_control_state()
        self.control_state["sequence_order_mode"] = args.multi_order
        self.control_state["sequence_turn_weight"] = args.multi_turn_weight
        self.control_state["rrt_planner"] = core.RRTPlanningWorker()

        # ---- 编号器
        self.labeler = DropletLabeler(
            group_mode=args.group_mode,
            row_tolerance=args.row_tolerance,
            color_tolerance=args.color_tolerance,
            size_tolerance=args.size_tolerance,
            smooth_alpha=args.smooth_alpha,
            min_radius_ratio=getattr(args, "min_radius_ratio", 0.5),
        )

        # ---- 执行器
        self.executor = CoraExecutor(
            self.control_state, args,
            px_per_mm=args.px_per_mm,
            clearance=args.clearance,
            log=lambda m: print(f"[Cora] {m}"),
            on_event=self._on_executor_event,
        )

        # ---- 电机
        self.stage = None
        if not args.no_motor:
            port = core.resolve_serial_port(args.port)
            if not port:
                raise RuntimeError(
                    "没有找到任何串口，无法连接步进电机。请检查：\n"
                    "  1) 驱动器 USB 是否插好、是否上电\n"
                    "  2) 设备管理器里有没有出现 COM 口（CH340 驱动装了吗）\n"
                    "  3) 想先不带电机跑，加 --no-motor")
            args.port = port
            try:
                self.stage = core.Y42XYZ(
                    port=port, x_addr=1, y_addr=2, z_addr=3,
                    verbose=args.motor_verbose,
                    command_delay=args.motor_command_delay,
                    motion_readback=not args.no_motor_readback,
                )
            except Exception as exc:
                raise RuntimeError(
                    f"串口 {port} 打开失败：{exc}\n"
                    "  常见原因：被别的程序（串口助手、MVS、旧进程）占用，\n"
                    "  或 COM 号变了 —— 用 4 号脚本里的硬件体检重新探测。") from exc
            self.stage.clear_protect()
            self.stage.enable()
            self.stage.stop_axis("z")
            print(f"[Cora] 步进电机已使能：{port}")
        else:
            print("[Cora] 演练模式：不发送电机指令")

        self.current_source_label = None
        self.current_target_point = None
        # 外部程序（语音助手）通过这个文件拿回复
        self.reply_path = getattr(args, "reply_log", None)
        if self.reply_path:
            try:
                os.makedirs(os.path.dirname(os.path.abspath(self.reply_path)), exist_ok=True)
                open(self.reply_path, "w", encoding="utf-8").close()
                print(f"[Cora] 回复外发至：{self.reply_path}")
            except Exception as exc:
                print(f"[Cora] 回复文件不可写（{exc}），语音播报会拿不到结果")
                self.reply_path = None

    # ------------------------------------------------------------ 事件
    @staticmethod
    def _det_bbox(det):
        box = det.get("xyxy") if isinstance(det, dict) else None
        return tuple(float(v) for v in box[:4]) if box is not None and len(box) >= 4 else None

    def _augment_control_detections(self, frame, detections, fresh_detection=True,
                                    observation_frame=None):
        """Add explicitly marked short-lived tracker predictions for control only."""
        control = [d for d in (detections or []) if d.get("name") != "laser"]
        laser_det = next((d for d in detections or []
                          if d.get("name") == "laser" and d.get("xyxy")), None)
        tracking_frame = (observation_frame if fresh_detection and observation_frame is not None
                          else frame)
        laser_result = self.laser_tracker.update(
            frame=tracking_frame,
            bbox=self._det_bbox(laser_det) if laser_det is not None and fresh_detection else None,
            confidence=float(laser_det.get("conf", 1.0)) if laser_det is not None else 0.0,
        )
        self.tracking_meta["laser"] = laser_result.mode
        if laser_det is not None:
            # Keep a fresh laser observation in the control packet.  The
            # tracker is still re-seeded from this observation, while the
            # raw confidence/class fields remain available to obstacle logic.
            control.append(laser_det)
        elif laser_result.center is not None:
            box = laser_result.bbox or (laser_result.center[0] - 8, laser_result.center[1] - 8,
                                        laser_result.center[0] + 8, laser_result.center[1] + 8)
            control.append({"name": "laser", "conf": laser_result.confidence,
                            "center": laser_result.center, "xyxy": box,
                            "tracked": True, "track_mode": laser_result.mode})

        source_name = self.control_state.get("selected_source_name")
        source_lock = self.control_state.get("source_lock_center")
        if source_name and source_lock is not None:
            candidates = [d for d in control
                          if d.get("name") == source_name and d.get("center") is not None]
            source_det = min(candidates, key=lambda d: core.distance(d["center"], source_lock), default=None)
            source_result = self.source_tracker.update(
                frame=tracking_frame,
                bbox=self._det_bbox(source_det) if source_det is not None and fresh_detection else None,
                confidence=float(source_det.get("conf", 1.0)) if source_det is not None else 0.0,
            )
            self.tracking_meta["source"] = source_result.mode
            if source_det is None and source_result.center is not None:
                box = source_result.bbox or (source_result.center[0] - 12, source_result.center[1] - 12,
                                             source_result.center[0] + 12, source_result.center[1] + 12)
                control.append({"name": source_name, "conf": source_result.confidence,
                                "center": source_result.center, "xyxy": box,
                                "tracked": True, "track_mode": source_result.mode})
        else:
            self.source_tracker.reset()
            self.tracking_meta["source"] = "idle"
        return control

    def _update_scale_recommendation(self, frame, detections):
        if self._scale_reported or not getattr(self.args, "adaptive_imgsz", True):
            return
        boxes = [d.get("xyxy") for d in detections or []
                 if d.get("name") != "laser" and d.get("xyxy")]
        diameters = [max(float(b[2]) - float(b[0]), float(b[3]) - float(b[1]))
                     for b in boxes]
        if not diameters:
            return
        self.scale_recommendation = recommend_detection_scale(
            frame.shape, diameters, base_imgsz=self.args.imgsz,
            roi_shape=(frame.shape[1], frame.shape[0]),
            target_pixels=getattr(self.args, "target_object_pixels", 96),
            min_imgsz=getattr(self.args, "scale_min_imgsz", 640),
            max_imgsz=getattr(self.args, "scale_max_imgsz", 1536),
            droplet_boxes=boxes,
        )
        self._scale_reported = True
        print(f"[Cora] 尺度标定：{self.scale_recommendation}")
        if self.detector is not None and getattr(self.args, "adaptive_imgsz", True):
            self.detector.imgsz = self.scale_recommendation["imgsz"]
        report_path = getattr(self.args, "scale_report", None)
        if report_path:
            try:
                parent = os.path.dirname(os.path.abspath(report_path))
                if parent:
                    os.makedirs(parent, exist_ok=True)
                with open(report_path, "w", encoding="utf-8") as handle:
                    json.dump(self.scale_recommendation, handle, ensure_ascii=False, indent=2)
            except Exception as exc:
                print(f"[Cora] 尺度报告写入失败：{exc}")

    def _emit_reply(self, action, command, reply):
        """把一次指令的结果写成一行 JSON，立刻 flush。

        语音助手靠它拿到「该播报什么」以及「这条到底是不是 Cora 的指令」
        —— action == "unknown" 时它会转交给大模型回答。
        """
        if not self.reply_path:
            return
        try:
            with open(self.reply_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps({"action": action, "cmd": command,
                                     "reply": reply}, ensure_ascii=False) + "\n")
                fh.flush()
        except Exception:
            pass

    def _on_executor_event(self, kind, message, **extra):
        self.task_note = message
        if kind == "move":
            self.current_source_label = extra.get("source")
            self.current_target_point = extra.get("target")

    # ------------------------------------------------------------ 输入
    def start_stdin_reader(self):
        if sys.stdin is None:
            return

        def _reader():
            try:
                for line in sys.stdin:
                    text = line.strip()
                    if not text:
                        continue
                    if text.lower() in QUIT_WORDS:
                        self.cmd_queue.put("__quit__")
                        break
                    self.cmd_queue.put(text)
            except Exception:
                pass

        threading.Thread(target=_reader, daemon=True).start()

    def _prompt_command(self, frame_shape, droplets, laser_center):
        """按空格/回车弹一个小输入框，省得切回终端敲中文。

        cv2 自己画不出可编辑的输入框，所以借 tkinter 的 simpledialog。
        弹窗期间主循环会停住 —— 用户正在输指令，本来就该停。
        """
        try:
            import tkinter as tk
            from tkinter import simpledialog
        except Exception as exc:
            self.hint = "缺少 tkinter，请在终端里输入指令"
            print(f"[Cora] 无法弹输入框：{exc}")
            return
        root = None
        try:
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            text = simpledialog.askstring("Cora 指令", "输入指令后回车：\n"
                                          "例如：把最左边的液滴移到右侧", parent=root)
        except Exception as exc:
            print(f"[Cora] 输入框出错：{exc}")
            text = None
        finally:
            if root is not None:
                try:
                    root.destroy()
                except Exception:
                    pass
        if text and text.strip():
            self.execute_command(text.strip(), droplets, frame_shape, laser_center)

    def _ready_for_command(self):
        """现在能不能执行指令了？

        至少要等检测器吐出过一帧结果。检测跑在独立线程里，CPU 推理还要
        先热身；不等的话 --command 会在半路上被执行，用户看到的回复是
        "画面里没有检测到液滴" —— 看着像算法坏了，其实只是太早。
        """
        if self.frame_index < self.command_warmup:
            return False
        if self.detector is None or self.detector_ready:
            return True
        # 兜底：相机/模型真的出不来结果时别一直挂着，让指令自己报错
        return (time.time() - self.started_at) > self.command_timeout

    def _drain_commands(self, droplets, frame_shape, laser_center):
        if not self._ready_for_command():
            # 预热期先不消费：此时检测线程多半还没吐第一帧，
            # 执行下去只会回一句"没有检测到液滴"。
            return
        while True:
            try:
                text = self.cmd_queue.get_nowait()
            except queue.Empty:
                return
            if text == "__quit__":
                self.running = False
                return
            self.execute_command(text, droplets, frame_shape, laser_center)

    def execute_command(self, text, droplets, frame_shape, laser_center=None):
        print(f"\n> {text}")
        cmd = parse(text)

        if cmd.action == "list":
            roster = format_roster(droplets, self.labeler.last_info)
            print(roster)
            self.hint = "已列出当前液滴"
            self._emit_reply("list", text, roster)
            return None

        if cmd.action == "help":
            print(HELP_TEXT)
            self.hint = "已显示指令说明"
            self._emit_reply("help", text,
                             "可以说：把最左边的液滴移到右侧，"
                             "或者说把 A1 移到 B2 旁边。")
            return None

        if cmd.action == "relabel":
            self.labeler.relabel()
            self.hint = "已重新编号"
            self._emit_reply("relabel", text, "已按当前位置重新编号")
            return None

        if cmd.action == "unknown":
            msg = cmd.note or "没理解这条指令"
            print(f"[Cora] {msg}")
            self.hint = msg
            # unknown 会被语音助手转交给大模型回答，所以原样带出去
            self._emit_reply("unknown", text, msg)
            return None

        ok, msg = self.executor.handle(cmd, droplets, frame_shape, laser_center)
        if ok:
            print(f"[Cora] {msg}")
            self.hint = msg
            if cmd.action in ("move", "reset", "stop"):
                self.request_stop = True       # 先刹车，下一帧再按新目标起步
        else:
            print(f"[Cora] 无法执行：{msg}")
            self.hint = f"无法执行：{msg}"
        self._emit_reply(cmd.action, text, self.hint)
        return cmd

    # ------------------------------------------------------------ 电机输出
    def _drive_motors(self, step, now):
        if self.stage is None:
            return
        if self.request_stop:
            core.stop_xy(self.stage)
            self.last_command = (0, 0)
            self.last_command_time = 0.0
            return

        stale = not step.get("detected")
        arrived = step.get("state") == core.STATE_ARRIVED
        missing_laser = not step.get("laser_visible")
        active = step.get("detected") and not missing_laser

        if arrived or not active:
            if self.last_command != (0, 0):
                core.stop_xy(self.stage)
                self.last_command = (0, 0)
                self.last_command_time = now
            return

        x_speed = step.get("x_speed", 0)
        y_speed = step.get("y_speed", 0)
        state_changed = step.get("state_changed", False)
        should_send = state_changed or (now - self.last_command_time) >= self.args.command_interval
        if not should_send:
            return
        if (x_speed, y_speed) == self.last_command and x_speed == 0 and y_speed == 0:
            return

        if state_changed and self.last_command != (0, 0):
            core.stop_xy(self.stage)
        self.stage.speed("x", x_speed)
        self.stage.speed("y", y_speed)
        self.last_command = (x_speed, y_speed)
        self.last_command_time = now

    # ------------------------------------------------------------ 主循环
    def run(self):
        if self.args.command:
            pending = list(self.args.command)
        else:
            pending = []
        pending_index = 0
        pending_delay_until = 0.0

        # 静态图模式下先把模型预热，避免第一帧就卡住
        frame = None
        for _ in range(50):
            frame = self.source.get_frame()
            if frame is not None:
                break
            time.sleep(0.1)
        if frame is None:
            raise RuntimeError("取不到图像，请检查相机连接或 --source 参数")

        print(f"[Cora] 输入源：{self.source.name}，画面 {frame.shape[1]}x{frame.shape[0]}")
        print(HELP_TEXT)

        display_scale = self.args.display_scale
        fps_limit = float(getattr(self.args, "fps_limit", 30.0) or 0.0)
        min_interval = (1.0 / fps_limit) if fps_limit > 0 else 0.0

        try:
            while self.running:
                frame = self.source.get_frame()
                if frame is None:
                    self._drive_motors({}, time.time())
                    core.reset_pd_state(self.control_state)
                    time.sleep(0.02)
                    continue
                now = time.time()
                self.frame_index += 1

                # ---- 检测结果
                detections = []
                packet = None
                if self.detector is not None:
                    try:
                        packet = self.detector.get_latest()
                        if packet is not None:
                            detections = packet["detections"]
                            self.detector_ready = True
                    except Exception as exc:
                        print(f"[Cora] 推理线程异常：{exc}")
                        break

                observation_frame = packet.get("frame") if packet else None
                if observation_frame is None:
                    observation_frame = frame
                self._update_scale_recommendation(observation_frame, detections)
                fresh_detection = bool(packet is not None and
                                       packet.get("seq") != getattr(self, "_track_packet_seq", None))
                if fresh_detection:
                    self._track_packet_seq = packet.get("seq")
                packet_age = (now - float(packet.get("timestamp", now))) if packet else float("inf")
                detector_stale = packet is None or packet_age > float(self.args.max_detection_age)
                control_detections = ([] if detector_stale else
                                      self._augment_control_detections(frame, detections,
                                                                       fresh_detection=fresh_detection,
                                                                       observation_frame=observation_frame))

                # Only the no-motor comparison view may hide flagged candidates.
                # Raw boxes remain available to control/obstacle logic below.
                display_detections = detections
                rejected_visual = []
                if packet is not None and (self.visual_filter.enabled or self.detection_recorder):
                    matched_frame = packet.get("frame")
                    if matched_frame is not None:
                        frame = matched_frame
                    if packet["seq"] != self._visual_seq:
                        self._visual_detections, self._visual_flagged = self.visual_filter.filter(
                            detections, matched_frame)
                        if self.detection_recorder:
                            self.detection_recorder.record(packet, self._visual_flagged)
                        self._visual_seq = packet["seq"]
                    display_detections = self._visual_detections
                    rejected_visual = self._visual_flagged

                # ---- 编号（实验视图不代表真实液滴数量）
                droplets, info = self.labeler.update(display_detections, observation_frame)
                info["visual_experiment"] = self.visual_filter.enabled
                info["visual_rejected"] = len(rejected_visual)
                info["tracking"] = dict(self.tracking_meta)
                if self.scale_recommendation:
                    info["scale_recommendation"] = self.scale_recommendation

                laser_center = None
                for det in control_detections:
                    if det.get("name") == "laser" and det.get("center"):
                        laser_center = (float(det["center"][0]), float(det["center"][1]))
                        break

                # ---- 预设指令（按帧间隔依次触发，保证能看到画面）
                if (pending_index < len(pending)
                        and self._ready_for_command()
                        and now >= pending_delay_until):
                    text = pending[pending_index]
                    pending_index += 1
                    self.execute_command(text, droplets, frame.shape, laser_center)
                    pending_delay_until = now + 0.6

                # ---- 用户指令
                self._drain_commands(droplets, frame.shape, laser_center)

                # 以主循环帧为时钟做短周期阻塞检查。检查失败只会发出停止
                # 请求；重新规划成功后下一帧才恢复控制。
                # ---- 控制步
                step = {}
                if self.model is not None and not detector_stale:
                    try:
                        step = core.build_control_step(control_detections, self.args,
                                                       self.control_state, frame.shape)
                    except Exception as exc:
                        print(f"[Cora] 控制步异常：{exc}")
                        traceback.print_exc()
                        step = {}

                # ---- 到达检测 & 队列推进
                arrived_now = step.get("state") == core.STATE_ARRIVED
                if arrived_now and not self.was_arrived:
                    follow_up = self.executor.on_arrived(droplets, frame.shape)
                    if follow_up == "全部完成":
                        self.hint = "全部完成"
                        self.task_note = "全部完成"
                        self.current_target_point = None
                    elif follow_up:
                        self.task_note = follow_up
                        print(f"[Cora] {follow_up}")
                self.was_arrived = arrived_now

                # Queue validation can fail after a target is reached (for
                # example when a queued droplet disappeared or a reserved
                # landing point lost clearance).  The executor exposes that
                # stop request through the same gate used by user stop/reset
                # commands so an old control step cannot be sent afterwards.
                if self.executor.consume_stop_request():
                    self.request_stop = True

                # ---- 刹车请求
                if self.request_stop:
                    core.stop_xy(self.stage)
                    core.reset_pd_state(self.control_state)
                    self.last_command = (0, 0)
                    self.last_command_time = 0.0
                    self.request_stop = False
                    step = {}

                # ---- 电机
                self._drive_motors(step, now)
                if step:
                    recorded_step = dict(step)
                    actual = self.last_command if self.stage is not None else (0, 0)
                    recorded_step["x_speed"], recorded_step["y_speed"] = actual
                    core.update_runtime_metrics(self.control_state, recorded_step, now=now)

                # ---- 绘制
                status = overlay.build_status_lines(
                    info,
                    executor_state=self.task_note,
                    extra=[(f"输入源：{self.source.name}", overlay.TEXT_DIM),
                           ("演练模式（未接电机）" if self.stage is None else f"电机端口 {self.args.port}",
                            overlay.WARN_COLOR if self.stage is None else overlay.OK_COLOR)],
                )
                view = overlay.draw_cora_frame(
                    frame, droplets, info,
                    source_label=self.current_source_label,
                    target_point=self.current_target_point,
                    status_lines=status,
                    hint=self.hint,
                    laser_center=laser_center,
                )

                if display_scale != 1.0:
                    view = cv2.resize(view,
                                      (int(view.shape[1] * display_scale),
                                       int(view.shape[0] * display_scale)),
                                      interpolation=cv2.INTER_AREA)

                self.last_view = view
                if not self.args.no_display:
                    screen_w, screen_h = core.get_screen_size()
                    fitted = core.resize_to_fit(view, max(320, screen_w - 40), screen_h - 60)
                    cv2.imshow(WINDOW_NAME, fitted)
                    key = cv2.waitKey(1) & 0xFF
                    if key in (27, ord("q")):
                        break
                    if key == ord("r"):
                        self.labeler.relabel()
                        self.hint = "已重新编号"
                    if key == ord("1"):
                        print(format_roster(droplets, info))
                    if key in (ord(" "), 13):
                        self._prompt_command(frame.shape, droplets, laser_center)

                if self.args.max_frames and self.frame_index >= self.args.max_frames:
                    print(f"[Cora] 达到 {self.args.max_frames} 帧，退出")
                    break

                # ---- 限速
                # 图片/视频源没有帧率概念，取一帧就是瞬间的事。不限速的话
                # 主循环会以几百 fps 空转：CPU 白烧，而且检测线程根本来不及
                # 出新结果 —— 表现出来就是"一直检测不到液滴"。
                if min_interval > 0:
                    spent = time.time() - now
                    if spent < min_interval:
                        time.sleep(min_interval - spent)

        except KeyboardInterrupt:
            print("\n[Cora] 收到中断信号")
        except Exception as exc:
            print(f"\n[Cora] 主循环崩溃：{exc}")
            traceback.print_exc()
        finally:
            self.cleanup()

    def cleanup(self):
        try:
            if self.args.save_annotated and getattr(self, "last_view", None) is not None:
                write_image(self.args.save_annotated, self.last_view)
                print(f"[Cora] 标注图已保存：{self.args.save_annotated}")
        except Exception as exc:
            print(f"[Cora] 保存标注图失败：{exc}")
        core.stop_xy(self.stage)
        self._save_metrics()
        if self.detector is not None:
            self.detector.close()
        planner = self.control_state.get("rrt_planner")
        if planner is not None:
            planner.close()
        if self.stage is not None:
            self.stage.close()
        try:
            self.source.close()
        except Exception:
            pass
        cv2.destroyAllWindows()

    def _save_metrics(self):
        metrics = self.control_state.get("metrics", {})
        path = getattr(self.args, "metrics_file", None)
        if not path or not metrics.get("trace"):
            return
        try:
            destination = os.path.abspath(path)
            os.makedirs(os.path.dirname(destination), exist_ok=True)
            with open(destination, "w", encoding="utf-8") as handle:
                json.dump(metrics, handle, ensure_ascii=False, indent=2, allow_nan=False)
            print("[Cora] 轨迹指标已保存")
        except (OSError, ValueError) as exc:
            print(f"[Cora] 轨迹指标保存失败：{exc}")


# ================================================================ 入口
def build_parser():
    parser = core.build_arg_parser()
    grp = parser.add_argument_group("Cora")
    parser.set_defaults(device="auto")
    # 项目内置权重优先。原始代码里 --model 指的是训练机上的 .engine 路径，
    # 换机器基本打不开，所以这里给一个开箱即用的默认值。
    bundled = os.path.join(HERE, "weights", "best.pt")
    parser.set_defaults(model=bundled)
    grp = parser.add_argument_group("Cora")
    grp.add_argument("--source", default="hik",
                     help="输入源：hik（海康相机）/ usb:0 / image:xx.jpg / video:xx.mp4")
    grp.add_argument("--no-detect", action="store_true",
                     help="不加载模型，只看画面与编号（无 ultralytics 时可用）")
    grp.add_argument("--model-search", action="append", default=[],
                     help="模型搜不到的额外搜索目录，可重复给。"
                          "用于 .engine 需要 tensorrt 时自动回退到 .pt")
    grp.add_argument("--no-motor", action="store_true",
                     help="演练模式：不发电机指令，只做识别、编号与规划")
    grp.add_argument("--command", action="append",
                     help="启动后自动执行一条指令，可重复多次")
    grp.add_argument("--command-warmup", type=int, default=5,
                     help="启动后先空跑 N 帧再执行 --command（等检测线程出结果）")
    grp.add_argument("--command-timeout", type=float, default=20.0,
                     help="等检测结果的兜底秒数，超过就照常执行指令")
    grp.add_argument("--reply-log", default=None,
                     help="把每条指令的回复追加成一行 JSON 写到该文件，"
                          "供语音助手等外部程序读取播报")
    grp.add_argument("--fps-limit", type=float, default=50.0,
                     help="主循环帧率上限，0=不限速（图片/视频源必须限速）")
    grp.add_argument("--group-mode", default="auto",
                     choices=("auto", "class", "color", "size", "none"),
                     help="液滴分组方式：auto/class/color/size/none")
    grp.add_argument("--row-tolerance", type=float, default=None,
                     help="行判定阈值（像素）。同一行内从左到右编号")
    grp.add_argument("--color-tolerance", type=float, default=0.30,
                     help="颜色聚类容差，越小分组越细")
    grp.add_argument("--size-tolerance", type=float, default=0.28,
                     help="尺寸聚类容差")
    grp.add_argument("--min-radius-ratio", type=float, default=0.5,
                     help="半径小于中位半径×该值的检测按误检丢弃（滤激光光斑），0=不过滤")
    visual = grp.add_mutually_exclusive_group()
    visual.add_argument("--visual-filter", action="store_true", default=False,
                        help="启用未校准纹理过滤实验；必须 --no-motor，不能据此判断真实数量")
    visual.add_argument("--no-visual-filter", action="store_false", dest="visual_filter",
                        help="关闭实验过滤（默认），保留原始候选")
    grp.add_argument("--diagnostic-dir", default=None,
                     help="保存有限组同帧原始 PNG 和检测 JSON；必须 --no-motor")
    grp.add_argument("--diagnostic-frames", type=int, default=10,
                     help="原始采样组数 1-100，默认 10；重复检测包不重复保存")
    grp.add_argument("--visual-min-texture", type=float, default=24.0,
                     help="伪框过滤：局部灰度标准差阈值")
    grp.add_argument("--visual-min-edge", type=float, default=55.0,
                     help="伪框过滤：局部 Sobel 边缘强度阈值")
    grp.add_argument("--smooth-alpha", type=float, default=0.55,
                     help="编号位置平滑系数，越大越跟手、越小越稳")
    grp.add_argument("--tracking-backend", choices=("auto", "kcf", "predict"), default="auto",
                     help="单目标跟踪：可用时优先 KCF，不支持时回退到速度预测与 EMA")
    grp.add_argument("--tracking-max-lost", type=int, default=3,
                     help="跟踪器允许接续的短时丢失帧数")
    grp.add_argument("--adaptive-imgsz", dest="adaptive_imgsz", action="store_true", default=True,
                     help="基于首批检测尺寸自动给出 ROI×imgsz 标定建议并更新推理 imgsz")
    grp.add_argument("--no-adaptive-imgsz", dest="adaptive_imgsz", action="store_false")
    grp.add_argument("--target-object-pixels", type=float, default=96.0,
                     help="尺度标定时的网络输入目标直径，仅用于建议，不代表实测识别率")
    grp.add_argument("--scale-min-imgsz", type=int, default=640)
    grp.add_argument("--scale-max-imgsz", type=int, default=1536)
    grp.add_argument("--scale-report", default=None,
                     help="把首帧液滴尺度标定建议保存为 JSON")
    grp.add_argument("--clearance", type=float, default=1.35,
                     help="落点净空系数，>=1；越大越保守")
    grp.add_argument("--batch-grid", type=int, default=26,
                     help="全液滴批量落点搜索网格边长，默认 26")
    grp.add_argument("--batch-size", type=int, default=8,
                     help="每批最多任务数，用于限制连续执行长度")
    grp.add_argument("--batch-population", type=int, default=10,
                     help="双层批量优化上层候选解数量")
    grp.add_argument("--batch-generations", type=int, default=8,
                     help="双层批量优化上层迭代轮数")
    grp.add_argument("--batch-overhead", type=float, default=120.0,
                     help="每增加一批的代价权重（像素等价项）")
    grp.add_argument("--px-per-mm", type=float, default=None,
                     help="每毫米多少像素，用于「向右移动 20 毫米」这类指令")
    grp.add_argument("--display-scale", type=float, default=1.0,
                     help="显示缩放")
    grp.add_argument("--no-display", action="store_true",
                     help="不开预览窗口（配合 --save-annotated 做无头跑批）")
    grp.add_argument("--max-frames", type=int, default=0,
                     help="跑满 N 帧后退出（调试用，0=不限）")
    grp.add_argument("--save-annotated", default=None,
                     help="退出时把最后一帧标注图保存到该路径")
    grp.add_argument("--list-sources", action="store_true",
                     help="列出可用的摄像头后退出")
    return parser


def list_sources():
    print("可用摄像头：")
    found = False
    for i in range(6):
        backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
        cap = cv2.VideoCapture(i, backend)
        if cap.isOpened():
            ok, frame = cap.read()
            if ok and frame is not None:
                print(f"  usb:{i}  分辨率 {frame.shape[1]}x{frame.shape[0]}")
                found = True
        cap.release()
    if not found:
        print("  （没找到可用的 USB 摄像头）")
    print("\n海康工业相机请用 --source hik")


def main():
    args = build_parser().parse_args()
    if args.list_sources:
        list_sources()
        return

    if args.tune_from_metrics:
        # Keep offline replay optimization out of the camera/motor lifecycle.
        core.run_pid_tuning(args)
        return 0
    if args.apply_tuned_params:
        core.apply_tuned_pid_params(args, args.apply_tuned_params)

    try:
        app = CoraApp(args)
    except Exception as exc:
        print(f"[Cora] 启动失败：{exc}")
        return 1

    app.start_stdin_reader()
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
