# -*- coding: utf-8 -*-
"""Offline behavior tests, not a measurement of detector accuracy."""
import json
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np
import detection_filter as filters


def det(name="droplet", box=(10, 10, 50, 50), conf=0.8):
    x1, y1, x2, y2 = box
    return {"name": name, "conf": conf, "center": ((x1+x2)/2, (y1+y2)/2), "xyxy": box}


class DetectionFilterTests(unittest.TestCase):
    def setUp(self):
        self.frame = np.full((80, 80, 3), 80, dtype=np.uint8)

    def test_default_does_not_remove_possible_low_contrast_droplets(self):
        ds = [det()]
        self.assertEqual(filters.DropletVisualFilter().filter(ds, self.frame), (ds, []))

    def test_explicit_experiment_flags_flat_patch_without_mutating_input(self):
        candidate = det()
        kept, rejected = filters.DropletVisualFilter(enabled=True).filter([candidate], self.frame)
        self.assertEqual(kept, [])
        self.assertEqual(rejected[0]["filter_reason"], "low_information_patch")
        self.assertEqual(rejected[0]["visual_quality"]["texture_std"], 0)
        self.assertNotIn("filter_reason", candidate)

    def test_textured_patch_not_flagged_by_low_information_rule(self):
        self.frame[10:30, 10:50] = 255
        self.frame[30:50, 10:50] = 0
        ds = [det()]
        self.assertEqual(filters.DropletVisualFilter(enabled=True).filter(ds, self.frame), (ds, []))

    def test_laser_and_solid_obstacles_are_not_pruned(self):
        ds = [det("laser"), det("solid"), det("unknown")]
        self.assertEqual(filters.DropletVisualFilter(enabled=True).filter(ds, self.frame), (ds, []))

    def test_missing_frame_is_not_evidence_to_reject(self):
        ds = [det()]
        self.assertEqual(filters.DropletVisualFilter(enabled=True).filter(ds, None), (ds, []))

    def test_invalid_or_clipped_box_is_unassessed_not_rejected(self):
        for box in [(0, 0, 30, 30), (-10, 10, 40, 50), (20, 20, 10, 40),
                    (90, 90, 110, 110), (10, 10, float("nan"), 40), None]:
            with self.subTest(box=box):
                d = det()
                d["xyxy"] = box
                self.assertEqual(filters.DropletVisualFilter(enabled=True).filter([d], self.frame), ([d], []))

    def test_invalid_thresholds_fail_explicitly(self):
        for value in [-1, float("nan"), float("inf")]:
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    filters.DropletVisualFilter(min_texture_std=value)

    def test_grayscale_frame_supported(self):
        kept, rejected = filters.DropletVisualFilter(enabled=True).filter([det()], self.frame[:, :, 0])
        self.assertEqual(len(rejected), 1)

    def test_recorder_writes_bounded_distinct_packets_and_raw_frame(self):
        with tempfile.TemporaryDirectory() as root:
            recorder = filters.DetectionRecorder(root, limit=2)
            packet = {"seq": 0, "frame_seq": 7, "timestamp": 10.0, "infer_ms": 1.0,
                      "frame": self.frame, "detections": [det()]}
            self.assertTrue(recorder.record(packet, []))
            self.assertFalse(recorder.record(packet, []))
            self.assertTrue(recorder.record(dict(packet, seq=1), []))
            self.assertFalse(recorder.record(dict(packet, seq=2), []))
            docs = sorted(Path(root).rglob("*.json"))
            self.assertEqual(len(docs), 2)
            data = json.loads(docs[0].read_text(encoding="utf-8"))
            self.assertEqual(data["frame_seq"], 7)
            self.assertEqual(data["detections"][0]["xyxy"], [10, 10, 50, 50])
            image = cv2.imdecode(np.fromfile(docs[0].with_suffix(".png"), dtype=np.uint8), cv2.IMREAD_COLOR)
            np.testing.assert_array_equal(image, self.frame)

    def test_recorder_without_matching_frame_does_not_write(self):
        with tempfile.TemporaryDirectory() as root:
            recorder = filters.DetectionRecorder(root)
            self.assertFalse(recorder.record({"seq": 0, "detections": [det()]}, []))
            self.assertEqual(list(Path(root).rglob("*.json")), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
