# -*- coding: utf-8 -*-
"""Cora 中文指令解析器。

把"把左侧液滴移到右侧"这种人话，拆成结构化动作：
    Command(action="move",
            source={"kind": "spatial", "region": "left", "extreme": True},
            target={"kind": "region", "region": "right"})

设计原则：解析器只做语法层面的理解，不查当前有哪些液滴。
真正的"哪个液滴"与"落点在哪"由 executor 结合实时画面求值——
这样解析器可以完全离线单测，也让"液滴动了但编号没变"这类情况自然正确。

支持的指令
----------
移动  把左侧液滴移到右侧 / 把A1移到B2旁边 / 把最上面的移到左下角
      将所有A类液滴依次移到右侧 / 把全部液滴自动分批移到右侧
      / 往右移一点 / 把A1向右移动200像素
控制  停止 / 急停 / 复位 / 回到原点
查询  有哪些液滴 / 列出液滴 / 现在状态 / 帮助
整理  重新编号
"""

import re
from dataclasses import dataclass, field

# ---------------------------------------------------------------- 词表
# 长词在前，避免"右下方"被"右"抢先匹配
REGION_WORDS = [
    ("左上", "top_left"), ("右上", "top_right"),
    ("左下", "bottom_left"), ("右下", "bottom_right"),
    ("左边", "left"), ("左面", "left"), ("左侧", "left"), ("左方", "left"), ("左部", "left"), ("左端", "left"),
    ("右边", "right"), ("右面", "right"), ("右侧", "right"), ("右方", "right"), ("右部", "right"), ("右端", "right"),
    ("上面", "top"), ("上边", "top"), ("上方", "top"), ("顶部", "top"), ("上部", "top"), ("上端", "top"),
    ("下面", "bottom"), ("下边", "bottom"), ("下方", "bottom"), ("底部", "bottom"), ("下部", "bottom"), ("下端", "bottom"),
    ("中间", "center"), ("中心", "center"), ("中央", "center"), ("正中", "center"), ("正中央", "center"),
    ("左", "left"), ("右", "right"), ("上", "top"), ("下", "bottom"), ("中", "center"),
]

REGION_CN = {
    "left": "左侧", "right": "右侧", "top": "上方", "bottom": "下方",
    "center": "中央", "top_left": "左上角", "top_right": "右上角",
    "bottom_left": "左下角", "bottom_right": "右下角",
}

# 绝对位移动词（越长越先匹配）
ABS_VERBS = ["移动到", "移动至", "挪动到", "搬运到", "拖动到", "移动去",
             "移到", "挪到", "搬到", "放到", "拖到", "送至", "送到", "移到", "到"]

# 相对位移提示词
REL_HINTS = ["往", "向", "朝", "再"]

_CN_NUM = {"一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
           "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}

LABEL_RE = re.compile(r"([A-Za-z])\s*[-_#]?\s*(\d{1,2})(?!\d)")
ORDINAL_RE = re.compile(r"第\s*([一二三四五六七八九十\d]{1,3})\s*(?:个|颗|滴|枚)")
GROUP_ALL_RE = re.compile(r"(?:所有|全部|全部|全部的|整个|每一?个)\s*([A-Za-z])\s*(?:类|组|种)")
GROUP_ALL_RE2 = re.compile(r"([A-Za-z])\s*(?:类|组)(?:的)?(?:液滴|所有|全部|都)")
LAST_RE = re.compile(r"最后(?:一)?(?:那)?(?:个|颗|滴|枚)")
DISTANCE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(像素|px|pixel|毫米|mm|厘米|cm)?")


def cn_to_int(text):
    """把"三"、"12"、"十五"这类序数转成 int，失败返回 None。"""
    text = (text or "").strip()
    if not text:
        return None
    if text.isdigit():
        return int(text)
    if text == "十":
        return 10
    if text in _CN_NUM:
        return _CN_NUM[text]
    if "十" in text:
        head, _, tail = text.partition("十")
        tens = _CN_NUM.get(head, 1) if head else 1
        ones = _CN_NUM.get(tail, 0) if tail else 0
        return tens * 10 + ones
    return None


@dataclass
class Command:
    action: str = "unknown"          # move/reset/stop/list/relabel/help/status/unknown
    source: dict = None              # 源液滴描述
    target: dict = None              # 目标描述
    raw: str = ""
    note: str = ""                   # 提示或警告
    sweep: bool = False              # 是否为"多个液滴依次移动"
    auto_batch: bool = False         # 是否启用全液滴自动分批与自动落点

    def describe(self):
        parts = []
        if self.source:
            parts.append("源=" + _describe_slot(self.source))
        if self.target:
            parts.append("目标=" + _describe_slot(self.target))
        return f"{self.action}({', '.join(parts)})" if parts else self.action


def _describe_slot(slot):
    kind = slot.get("kind")
    if kind == "label":
        return f"编号{slot['label']}"
    if kind == "ordinal":
        return f"第{slot['index']}个" if slot["index"] != -1 else "最后一个"
    if kind == "group":
        return f"{slot['letter']}类全部"
    if kind == "spatial":
        base = REGION_CN.get(slot.get("region"), slot.get("region"))
        return ("最" + base) if slot.get("extreme") else base
    if kind == "nearest":
        return "离激光最近的"
    if kind == "region":
        return REGION_CN.get(slot.get("region"), slot.get("region"))
    if kind == "delta":
        return f"相对位移({slot.get('dx', 0):.0f},{slot.get('dy', 0):.0f})"
    return str(slot)


# ---------------------------------------------------------------- 归一化
def normalize(text):
    """全角转半角、统一大小写、压掉多余空白。"""
    if not text:
        return ""
    out = []
    for ch in text:
        code = ord(ch)
        if code == 0x3000:
            out.append(" ")
        elif 0xFF01 <= code <= 0xFF5E:
            out.append(chr(code - 0xFEE0))
        else:
            out.append(ch)
    s = "".join(out)
    s = s.replace("　", " ").strip()
    s = re.sub(r"\s+", "", s)
    return s


# ---------------------------------------------------------------- 槽位解析
def find_region(text):
    """返回 (region, matched_word) 或 (None, None)。长词优先。"""
    for word, region in REGION_WORDS:
        if word in text:
            return region, word
    return None, None


def parse_source(text):
    """解析"源液滴"描述。text 为动作前的部分（通常已去掉"把/将"）。"""
    if not text:
        return None

    # 类别集合：所有A类
    m = GROUP_ALL_RE.search(text) or GROUP_ALL_RE2.search(text)
    if m:
        return {"kind": "group", "letter": m.group(1).upper()}

    # 明确编号：A1
    m = LABEL_RE.search(text)
    if m:
        return {"kind": "label", "label": f"{m.group(1).upper()}{m.group(2)}"}

    # 序数：第一个 / 最后那个
    if LAST_RE.search(text):
        return {"kind": "ordinal", "index": -1}
    m = ORDINAL_RE.search(text)
    if m:
        num = cn_to_int(m.group(1))
        if num:
            return {"kind": "ordinal", "index": num}

    # 离激光最近
    if re.search(r"最近|最近的|靠近激光", text):
        return {"kind": "nearest"}

    # 方位
    region, _ = find_region(text)
    if region:
        extreme = bool(re.search(r"最|极|端点", text)) or region in (
            "left", "right", "top", "bottom")
        # "左边的液滴" 也是取左侧区域里最靠左/最靠上的那个，故一律按 extreme 处理
        return {"kind": "spatial", "region": region, "extreme": True}

    # "所有的液滴"
    if re.search(r"所有|全部|每个|各个|逐一", text):
        return {"kind": "group", "letter": None}

    return None


def parse_target(text, default_stride=None):
    """解析"目标位置"描述。"""
    if not text:
        return None

    text = text.strip("的地得")

    # 明确编号目标：移到 B2（或其旁边）
    m = LABEL_RE.search(text)
    if m:
        near = bool(re.search(r"旁边|附近|边上|周围|靠近|挨着|跟|和", text))
        return {"kind": "label", "label": f"{m.group(1).upper()}{m.group(2)}", "near": True}

    # 相对位移：往右移一点 / 向右移动200像素
    rel = any(h in text for h in REL_HINTS)
    region, word = find_region(text)
    if rel and region:
        m = DISTANCE_RE.search(text)
        value = None
        unit = None
        if m:
            value = float(m.group(1))
            unit = m.group(2)
        return {"kind": "delta", "region": region, "amount": value, "unit": unit}

    # 绝对区域：右侧 / 右下角
    if region:
        return {"kind": "region", "region": region}

    return None


def strip_source(text):
    """从整句里剥出"源液滴"的描述，返回 (源文本, 剩余文本)。

    用于「把 A1 往右移一点」这类没有「移到」的句子：
    必须先认出源是 A1，剩下的「往右移一点」才是位移描述。
    """
    if not text:
        return "", ""
    for regex in (LABEL_RE, LAST_RE, ORDINAL_RE, GROUP_ALL_RE):
        m = regex.search(text)
        if m:
            return m.group(0), text[m.end():]
    for word, _region in REGION_WORDS:
        idx = text.find(word)
        if idx >= 0:
            end = idx + len(word)
            return text[:end], text[end:]
    return text, ""


def split_move(text):
    """把"把A1移动到B2"切成源描述、目标描述。

    返回 (source_text, target_text) 或 None。
    """
    for verb in ABS_VERBS:
        if verb in text:
            idx = text.find(verb)
            head = text[:idx]
            tail = text[idx + len(verb):]
            # "移到" 这类词尾可能残留"动/至"等，交给目标解析容错
            return head, tail
    return None


# ---------------------------------------------------------------- 主入口
def parse(text, default_stride=None):
    """解析一句中文指令。"""
    raw = text or ""
    t = normalize(raw)
    if not t:
        return Command(action="unknown", raw=raw, note="指令为空")

    cmd = Command(raw=raw)

    # --- 控制类（优先级最高，避免被误当成长句）
    if re.search(r"急停|紧急停止|立刻停|马上停", t):
        cmd.action = "stop"
        return cmd
    if re.fullmatch(r"(停止|停|停下|停住|刹车|结束|终止)[吧。!！]*", t):
        cmd.action = "stop"
        return cmd
    if re.search(r"复位|归位|回原点|回到原点|回到起点|归零|回位|复原|回家", t):
        cmd.action = "reset"
        return cmd
    if re.search(r"重新编号|刷新编号|重排编号|重新排序|重编|再编一次|编号刷新", t):
        cmd.action = "relabel"
        return cmd
    if re.search(r"^(帮助|help|怎么用|使用说明|指令说明|能做什么)|\?|？$", t):
        cmd.action = "help"
        return cmd
    if re.search(r"有哪些|列出|列一下|清单|几个液滴|多少个液滴|当前液滴|识别到|有什么液滴|盘点", t):
        cmd.action = "list"
        return cmd
    if re.fullmatch(r"(状态|现在怎么样|进度|情况|怎么样了)[吧。!！]*", t):
        cmd.action = "status"
        return cmd

    # --- 移动类
    move_kw = re.search(r"移|挪|搬|放|拖|送|走|来|去", t)
    parts = split_move(t)
    if parts is not None:
        head, tail = parts
        # 去掉"把/将/请/帮我/麻烦"等引导词
        head = re.sub(r"^(请|帮我|麻烦|给我|把|将|让|你)+", "", head)
        cmd.action = "move"
        cmd.source = parse_source(head)
        cmd.target = parse_target(tail)

        # "把所有A类依次移到右侧" —— 通配移动
        if cmd.source and cmd.source.get("kind") == "group":
            cmd.sweep = bool(re.search(r"依次|逐个|一个一个|每个|所有|全部|都|分批|批量", t))
            # 未指定字母时代表全液滴任务；这是新规划器的显式入口。
            if cmd.source.get("letter") is None:
                cmd.auto_batch = True
            elif re.search(r"自动分批|智能分批|批量优化", t):
                cmd.auto_batch = True

        if cmd.source is None:
            cmd.note = "没听出要移动哪个液滴，可以说「A1」或「最左边的液滴」"
            cmd.action = "unknown"
        elif cmd.target is None:
            cmd.note = "没听出要移到哪里，可以说「右侧」或「B2旁边」"
            cmd.action = "unknown"
        return cmd

    # 相对位移：把A1往右移一点（句子里没有「移到」）
    if move_kw:
        cmd.action = "move"
        rest = re.sub(r"^(请|帮我|麻烦|给我|把|将|让|你)+", "", t)
        src_text, remain = strip_source(rest)
        cmd.source = parse_source(src_text) or parse_source(rest)
        cmd.target = parse_target(remain, default_stride=default_stride)
        if cmd.source is None:
            cmd.note = "没听出要移动哪个液滴，可以说「A1」或「最左边的液滴」"
            cmd.action = "unknown"
        elif cmd.target is None:
            cmd.note = "没说清移动方向和距离，比如「往右移一点」"
            cmd.action = "unknown"
        return cmd

    cmd.note = "没理解这条指令，可以说「把最左边的液滴移到右侧」"
    return cmd


# ---------------------------------------------------------------- 帮助
HELP_TEXT = """可用指令示例：
  移动类
    把最左边的液滴移到右侧
    把 A1 移到右下角
    把左上角的液滴移到 B2 旁边
    将第二个液滴移到中间
    把所有A类液滴依次移到右侧
    把全部液滴自动分批移到右侧
    把所有液滴按最短安全方案整理到右侧
    把 A1 往右移一点
    把 A1 向右移动 200 像素
  控制类
    停止 / 急停        立刻停下电机
    复位               激光回到起始液滴位置
  查询类
    有哪些液滴         列出当前编号与位置
    状态               查看当前任务进度
    重新编号           丢掉历史，按当前位置重新编号
    帮助               显示这段说明"""
