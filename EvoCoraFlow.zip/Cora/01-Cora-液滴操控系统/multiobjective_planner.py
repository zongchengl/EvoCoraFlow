# -*- coding: utf-8 -*-
"""自适应精英引导多目标路径选择（AEG-RRT）。

该模块不拥有硬件状态；它以 Informed RRT* 产生多条候选，再用精英档案、
差分式扰动和碰撞检查保留可行多样解，最后按长度、最小净空、平滑度和
障碍密度进行非支配筛选。该方法输出“候选集中的折中路径”，不是全局最优
证明。实际执行前仍需由调用方的独立路线安全校验器复核。
"""

import math
import random


def _distance(a, b):
    return math.hypot(float(a[0]) - float(b[0]), float(a[1]) - float(b[1]))


def _path_length(path):
    return sum(_distance(path[i - 1], path[i]) for i in range(1, len(path)))


def _resample(path, count):
    if len(path) < 2:
        return list(path)
    segment_lengths = [_distance(path[i - 1], path[i]) for i in range(1, len(path))]
    total = sum(segment_lengths)
    if total <= 1e-9:
        return [tuple(path[0]) for _ in range(count)]
    cumulative = [0.0]
    for length in segment_lengths:
        cumulative.append(cumulative[-1] + length)
    samples = []
    for k in range(count):
        target = total * k / max(1, count - 1)
        idx = 0
        while idx < len(segment_lengths) - 1 and cumulative[idx + 1] < target:
            idx += 1
        span = max(1e-9, segment_lengths[idx])
        ratio = max(0.0, min(1.0, (target - cumulative[idx]) / span))
        a, b = path[idx], path[idx + 1]
        samples.append((float(a[0]) + (float(b[0]) - float(a[0])) * ratio,
                        float(a[1]) + (float(b[1]) - float(a[1])) * ratio))
    return samples


def _point_segment_distance(point, a, b):
    vx, vy = b[0] - a[0], b[1] - a[1]
    length_sq = vx * vx + vy * vy
    if length_sq <= 1e-12:
        return _distance(point, a)
    t = max(0.0, min(1.0, ((point[0] - a[0]) * vx + (point[1] - a[1]) * vy) / length_sq))
    return _distance(point, (a[0] + vx * t, a[1] + vy * t))


def _segment_collision(a, b, obstacles):
    return any(_point_segment_distance(obs.center, a, b) <= float(obs.radius)
               for obs in obstacles)


def path_objectives(path, obstacles, spacing=12.0):
    if not path or len(path) < 2:
        return None
    length = _path_length(path)
    min_clearance = float("inf")
    density = 0.0
    smoothness = 0.0
    for a, b in zip(path, path[1:]):
        seg_len = max(1.0, _distance(a, b))
        steps = max(1, int(math.ceil(seg_len / max(1.0, spacing))))
        for index in range(steps + 1):
            t = index / steps
            point = (a[0] + (b[0] - a[0]) * t,
                     a[1] + (b[1] - a[1]) * t)
            for obs in obstacles:
                clearance = _distance(point, obs.center) - float(obs.radius)
                min_clearance = min(min_clearance, clearance)
                # Local obstacle density grows as the path approaches obstacles.
                density += max(0.0, 1.0 - max(0.0, clearance) /
                               max(1.0, float(obs.radius) * 3.0)) / (steps + 1)
    for i in range(1, len(path) - 1):
        before = (path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1])
        after = (path[i + 1][0] - path[i][0], path[i + 1][1] - path[i][1])
        nb = math.hypot(*before)
        na = math.hypot(*after)
        if nb > 1e-9 and na > 1e-9:
            cosine = max(-1.0, min(1.0, (before[0] * after[0] + before[1] * after[1]) / (nb * na)))
            smoothness += math.acos(cosine)
    if not math.isfinite(min_clearance):
        min_clearance = 1e6
    return {
        "length": float(length),
        "clearance": float(min_clearance),
        "smoothness": float(smoothness),
        "density": float(density),
    }


def _objective_tuple(metrics):
    # Maximize clearance by minimizing its negative.
    return (metrics["length"], -metrics["clearance"], metrics["smoothness"], metrics["density"])


def pareto_front(candidates):
    front = []
    for candidate in candidates:
        obj = _objective_tuple(candidate["metrics"])
        dominated = False
        for other in candidates:
            if other is candidate:
                continue
            other_obj = _objective_tuple(other["metrics"])
            if all(a <= b + 1e-9 for a, b in zip(other_obj, obj)) and any(
                    a < b - 1e-9 for a, b in zip(other_obj, obj)):
                dominated = True
                break
        if not dominated:
            front.append(candidate)
    return front


def _route_score(metrics, diagonal):
    diagonal = max(1.0, float(diagonal))
    length = metrics["length"] / diagonal
    clearance = max(0.0, metrics["clearance"]) / diagonal
    smoothness = metrics["smoothness"] / math.pi
    density = metrics["density"]
    return length + 0.55 / (0.04 + clearance) + 0.20 * smoothness + 0.12 * density


def generate_candidate_paths(start, goal, obstacles, bounds, planner_class,
                             planner_kwargs, shortcut_fn=None, candidate_count=5,
                             seed=11, mutation_generations=2,
                             mutation_population=6):
    """Generate a small diverse candidate archive.

    Returns ``(selected_path, metadata)``. Differentially mutated paths are
    accepted only when every segment remains collision-free and in bounds.
    """
    candidate_count = max(1, min(12, int(candidate_count)))
    rng = random.Random(seed)
    base_kwargs = dict(planner_kwargs)
    step_size = float(base_kwargs.get("step_size", 40.0))
    smooth_attempts = int(base_kwargs.pop("smooth_attempts", 60))
    archive = []

    def add(path, label):
        if not path or len(path) < 2:
            return False
        if shortcut_fn is not None:
            try:
                path = shortcut_fn(path, obstacles, bounds, attempts=smooth_attempts,
                                   rng_seed=seed + len(archive) * 73)
            except Exception:
                return False
        path = [(float(p[0]), float(p[1])) for p in path]
        if any(not (bounds[0] <= point[0] <= bounds[2]
                    and bounds[1] <= point[1] <= bounds[3]) for point in path):
            return False
        if (_distance(path[0], start) > 1e-6
                or _distance(path[-1], goal) > 1e-6):
            return False
        if any(_segment_collision(a, b, obstacles) for a, b in zip(path, path[1:])):
            return False
        metrics = path_objectives(path, obstacles, spacing=max(8.0, step_size * 0.45))
        if metrics is None:
            return False
        signature = tuple((round(p[0] / 3.0), round(p[1] / 3.0)) for p in _resample(path, 7))
        if any(item["signature"] == signature for item in archive):
            return False
        archive.append({"path": path, "metrics": metrics, "signature": signature,
                        "origin": label})
        return True

    # RRT* seed ensemble produces topologically different routes in dense scenes.
    for index in range(candidate_count):
        kwargs = dict(base_kwargs)
        kwargs["rng_seed"] = int(seed + index * 104729)
        try:
            planner = planner_class(bounds=bounds, obstacles=obstacles, **kwargs)
            route = planner.plan(start, goal)
        except Exception:
            route = None
        if route is not None:
            add(route, "informed_rrt_star")

    # Differential elite guidance: align a few elite paths by arc length,
    # mutate interior waypoint coordinates, and reject any unsafe segment.
    for generation in range(max(0, int(mutation_generations))):
        if len(archive) < 2:
            break
        elite = pareto_front(archive)
        elite.sort(key=lambda item: _route_score(item["metrics"],
                                                math.hypot(bounds[2] - bounds[0], bounds[3] - bounds[1])))
        elite = elite[:max(2, min(5, len(elite)))]
        pool = list(archive)
        for _ in range(max(1, int(mutation_population))):
            base = rng.choice(elite)
            left, right = rng.sample(elite if len(elite) >= 2 else pool, 2)
            points = [_resample(item["path"], 7) for item in (base, left, right)]
            mutant = [tuple(points[0][0]), *[None] * 5, tuple(points[0][-1])]
            factor = rng.uniform(0.25, 0.75)
            for i in range(1, 6):
                x = points[0][i][0] + factor * (points[1][i][0] - points[2][i][0])
                y = points[0][i][1] + factor * (points[1][i][1] - points[2][i][1])
                if rng.random() < 0.45:
                    x = points[1][i][0]
                    y = points[1][i][1]
                x = max(bounds[0], min(bounds[2], x))
                y = max(bounds[1], min(bounds[3], y))
                mutant[i] = (x, y)
            if any(_segment_collision(a, b, obstacles) for a, b in zip(mutant, mutant[1:])):
                continue
            add(mutant, "elite_differential_mutation")
        front = pareto_front(archive)
        if not front:
            break
        # Keep some diverse non-dominated routes and cap memory/selection cost.
        front.sort(key=lambda item: _route_score(item["metrics"],
                                                 math.hypot(bounds[2] - bounds[0], bounds[3] - bounds[1])))
        archive = front[:max(candidate_count * 2, 8)]

    if not archive:
        return None, {"candidate_count": 0, "pareto_count": 0, "selected": None}

    front = pareto_front(archive)
    diagonal = math.hypot(bounds[2] - bounds[0], bounds[3] - bounds[1])
    selected = min(front, key=lambda item: _route_score(item["metrics"], diagonal))
    summary = {
        "candidate_count": len(archive),
        "pareto_count": len(front),
        "selected": dict(selected["metrics"]),
        "objectives": ["path_length", "clearance", "smoothness", "obstacle_density"],
        "method": "AEG-RRT",
    }
    return selected["path"], summary

