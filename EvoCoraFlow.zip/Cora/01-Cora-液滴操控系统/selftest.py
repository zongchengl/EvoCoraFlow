# -*- coding: utf-8 -*-
"""Cora 离线自测：不需要相机、模型、电机，纯逻辑验证。

跑法：python selftest.py
"""

import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from command_parser import HELP_TEXT, parse                    # noqa: E402
from executor import (plan_beside_point, plan_delta_point,     # noqa: E402
                      plan_landing_point, pick_droplet, region_rect)
from labeling import (Droplet, DropletLabeler, format_roster,  # noqa: E402
                      order_row_major, sample_color)

PASS = 0
FAIL = 0


def check(name, cond, detail=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [OK]   {name}")
    else:
        FAIL += 1
        print(f"  [FAIL] {name}   {detail}")


def mkdet(cx, cy, r=30, name="droplet", conf=0.9):
    return {"name": name, "conf": conf, "center": (float(cx), float(cy)),
            "xyxy": (cx - r, cy - r, cx + r, cy + r)}


def labels_of(droplets):
    return [d.label for d in droplets]


# ================================================================ 1 编号
def test_labeling():
    print("\n== 1. 液滴编号 ==")

    # 横排：从左到右
    lab = DropletLabeler(group_mode="none")
    ds, info = lab.update([mkdet(900, 500), mkdet(100, 500), mkdet(500, 500)])
    check("横排按从左到右编号", labels_of(ds) == ["A1", "A2", "A3"], labels_of(ds))
    check("最左的是 A1", ds[0].center[0] == 100, ds[0].center)

    # 两行：从上到下、行内从左到右
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(600, 500), mkdet(200, 150),
                        mkdet(600, 150), mkdet(200, 500)])
    expect_centers = [(200, 150), (600, 150), (200, 500), (600, 500)]
    got = [(int(d.center[0]), int(d.center[1])) for d in ds]
    check("两行按从上到下、行内从左到右", got == expect_centers, got)

    # 斜排（y 略有差异但属于同一行）
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(100, 500), mkdet(400, 512), mkdet(700, 495)])
    check("轻微高低差仍算同一行", labels_of(ds) == ["A1", "A2", "A3"], labels_of(ds))

    # 多类别：同类同字母，异类换字母
    lab = DropletLabeler(group_mode="class")
    ds, info = lab.update([mkdet(600, 100, name="oil"),
                           mkdet(100, 100, name="droplet"),
                           mkdet(100, 300, name="droplet")])
    got = {d.label: d.name for d in ds}
    check("异类换字母（droplet=A, oil=B）",
          got == {"A1": "droplet", "A2": "droplet", "B1": "oil"}, got)
    check("分组统计正确", info["groups"] == {"A": 2, "B": 1}, info["groups"])

    # 三个类别
    lab = DropletLabeler(group_mode="class")
    ds, info = lab.update([mkdet(100, 100, name="droplet"),
                           mkdet(300, 100, name="oil"),
                           mkdet(500, 100, name="milk")])
    check("三类各占一个字母", sorted(d.group for d in ds) == ["A", "B", "C"],
          [d.group for d in ds])

    # 抖动稳定性
    lab = DropletLabeler(group_mode="none")
    lab.update([mkdet(300, 300), mkdet(500, 300)])
    ds, _ = lab.update([mkdet(305, 302), mkdet(498, 301)])
    check("相邻液滴微动后编号不互换", labels_of(ds) == ["A1", "A2"], labels_of(ds))

    # 真正互换位置后，编号跟随位置（用未平滑的实测中心判断）
    ds, _ = lab.update([mkdet(520, 300), mkdet(280, 300)])
    got = [(d.label, int(d.raw_center[0])) for d in ds]
    check("位置互换后编号跟随位置", got == [("A1", 280), ("A2", 520)], got)

    # 新增液滴
    lab = DropletLabeler(group_mode="none")
    lab.update([mkdet(500, 300)])
    ds, _ = lab.update([mkdet(100, 300), mkdet(500, 300)])
    check("新增的左侧液滴成为 A1", labels_of(ds) == ["A1", "A2"], labels_of(ds))

    # 单液滴
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(400, 400)])
    check("单个液滴编号为 A1", labels_of(ds) == ["A1"], labels_of(ds))

    # 空画面
    lab = DropletLabeler(group_mode="none")
    ds, info = lab.update([])
    check("空画面返回空列表", ds == [] and info["count"] == 0)

    # laser 不参与编号
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(100, 100), mkdet(200, 200, name="laser")])
    check("激光不参与编号", labels_of(ds) == ["A1"], labels_of(ds))

    # 行优先排序函数
    items = [Droplet(center=(10, 100), radius=20), Droplet(center=(80, 20), radius=20)]
    ordered = order_row_major(items)
    check("order_row_major 先上后左",
          ordered[0].center == (80, 20), [i.center for i in ordered])


# ================================================================ 2 颜色分组
def test_color_grouping():
    print("\n== 2. 颜色分组（同类/异类判定）==")

    frame = np.full((600, 800, 3), 200, dtype=np.uint8)   # 浅灰背景（模拟油层）
    # 两个红色液滴 + 一个蓝色液滴
    import cv2
    cv2.circle(frame, (150, 300), 40, (0, 0, 255), -1)     # 红
    cv2.circle(frame, (350, 300), 40, (0, 0, 255), -1)     # 红
    cv2.circle(frame, (600, 300), 40, (255, 0, 0), -1)     # 蓝

    dets = [mkdet(150, 300, 40), mkdet(350, 300, 40), mkdet(600, 300, 40)]
    lab = DropletLabeler(group_mode="color")
    ds, info = lab.update(dets, frame)
    groups = {}
    for d in ds:
        groups.setdefault(d.group, []).append(d.label)
    check("同色归一组、异色换字母",
          len(groups) == 2 and sorted(len(v) for v in groups.values()) == [1, 2],
          groups)

    # 三个都一样 → 一个组
    frame2 = np.full((600, 800, 3), 200, dtype=np.uint8)
    cv2.circle(frame2, (150, 300), 40, (0, 0, 255), -1)
    cv2.circle(frame2, (400, 300), 40, (0, 0, 255), -1)
    lab = DropletLabeler(group_mode="color")
    ds, info = lab.update([mkdet(150, 300, 40), mkdet(400, 300, 40)], frame2)
    check("颜色相同只用一个字母", all(d.group == "A" for d in ds),
          [d.group for d in ds])

    # 取色函数本身
    c = sample_color(frame, (150, 300), 40)
    check("能取到液滴颜色", c is not None and c[1] > 100, c)


# ================================================================ 3 指令解析
def test_parser():
    print("\n== 3. 中文指令解析 ==")

    cases = [
        ("把最左边的液滴移到右侧", "move", "spatial", "region"),
        ("将左侧液滴移动到右边", "move", "spatial", "region"),
        ("把A1移到B2旁边", "move", "label", "label"),
        ("把 A2 挪到左上角", "move", "label", "region"),
        ("把所有A类液滴依次移到右侧", "move", "group", "region"),
        ("把第二个液滴移到中间", "move", "ordinal", "region"),
        ("将最后那个液滴放到右下角", "move", "ordinal", "region"),
        ("把上面的液滴移到下边", "move", "spatial", "region"),
        ("停止", "stop", None, None),
        ("急停", "stop", None, None),
        ("复位", "reset", None, None),
        ("回到原点", "reset", None, None),
        ("有哪些液滴", "list", None, None),
        ("重新编号", "relabel", None, None),
        ("帮助", "help", None, None),
        ("把A1往右移一点", "move", "label", "delta"),
        ("把A1向右移动200像素", "move", "label", "delta"),
    ]
    for text, action, src_kind, tgt_kind in cases:
        cmd = parse(text)
        ok = cmd.action == action
        if src_kind:
            ok = ok and cmd.source is not None and cmd.source.get("kind") == src_kind
        if tgt_kind:
            ok = ok and cmd.target is not None and cmd.target.get("kind") == tgt_kind
        check(f"「{text}」→ {action}", ok,
              f"得到 action={cmd.action} source={cmd.source} target={cmd.target}")

    # 细节断言
    cmd = parse("把最左边的液滴移到右侧")
    check("方位解析正确",
          cmd.source.get("region") == "left" and cmd.target.get("region") == "right",
          (cmd.source, cmd.target))

    cmd = parse("把A1移到B2旁边")
    check("编号解析正确",
          cmd.source.get("label") == "A1" and cmd.target.get("label") == "B2",
          (cmd.source, cmd.target))

    cmd = parse("把所有A类液滴依次移到右侧")
    check("类别集合 + 依次标记",
          cmd.source.get("kind") == "group" and cmd.sweep is True, (cmd.source, cmd.sweep))

    cmd = parse("把第二个液滴移到左上角")
    check("序数解析正确", cmd.source.get("index") == 2, cmd.source)

    cmd = parse("把带三个液滴移到右边")
    check("乱指令被拒绝", cmd.action == "unknown" and cmd.note, (cmd.action, cmd.note))

    cmd = parse("把A9移到右边")
    check("编号语法能解析（存在性留给执行期判断）",
          cmd.action == "move" and cmd.source.get("label") == "A9", cmd.source)

    check("帮助文本非空", len(HELP_TEXT) > 100)


# ================================================================ 4 落点规划
def test_planning():
    print("\n== 4. 目标落点规划 ==")

    shape = (1000, 1000, 3)
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(200, 500, 40), mkdet(500, 500, 40)])
    source = ds[0]

    point, msg = plan_landing_point("right", source, ds, shape)
    check("右侧能找到落点", point is not None, msg)
    if point:
        ok = True
        for d in ds:
            need = (d.radius + source.radius) * 1.0
            if ((point[0] - d.center[0]) ** 2 + (point[1] - d.center[1]) ** 2) ** 0.5 < need:
                ok = False
        check("落点与其他液滴保持净空", ok, point)
        check("落点确实在右侧", point[0] > 600, point)

    # 区域被占满时给出可读的失败原因（密集铺满整个右侧区域）
    crowded = [mkdet(x, y, 45)
               for x in range(660, 951, 55)
               for y in range(130, 871, 55)]
    lab = DropletLabeler(group_mode="none")
    cds, _ = lab.update(crowded)
    point, msg = plan_landing_point("right", cds[0], cds, shape)
    check("区域占满时返回 None 且有提示",
          point is None and ("占满" in msg or "放不下" in msg), (point, msg))

    # 停在某个液滴旁边
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(200, 500, 40), mkdet(600, 500, 40)])
    point, msg = plan_beside_point(ds[1], ds[0], ds, shape)
    check("能找到停靠点", point is not None, msg)
    if point and ds:
        d = ((point[0] - ds[1].center[0]) ** 2 + (point[1] - ds[1].center[1]) ** 2) ** 0.5
        check("停靠点与目标液滴有间距", d >= (ds[0].radius + ds[1].radius) * 0.9, d)

    # 相对位移
    point, msg = plan_delta_point("right", None, None, source, shape)
    check("相对位移默认步长可用", point is not None and point[0] > source.center[0], msg)
    point, msg = plan_delta_point("right", 200, "像素", source, shape)
    check("指定像素位移正确",
          point is not None and abs(point[0] - (source.center[0] + 200)) < 1, (point, msg))
    point, msg = plan_delta_point("right", 20, "毫米", source, shape, px_per_mm=None)
    check("没给 px_per_mm 时给出提示", point is None and "px-per-mm" in msg, msg)
    point, msg = plan_delta_point("right", 20, "毫米", source, shape, px_per_mm=5)
    check("给 px_per_mm 后毫米换算正确",
          point is not None and abs(point[0] - (source.center[0] + 100)) < 1, point)

    # 区域矩形
    rect = region_rect("left", 1000, 1000)
    check("左侧区域在画面左半部分", rect[2] < 500, rect)


# ================================================================ 5 液滴选择
def test_picking():
    print("\n== 5. 液滴选择 ==")

    shape = (1000, 1000, 3)
    lab = DropletLabeler(group_mode="none")
    ds, _ = lab.update([mkdet(100, 100, 40), mkdet(500, 100, 40),
                        mkdet(100, 700, 40), mkdet(800, 800, 40)])

    d, why = pick_droplet({"kind": "label", "label": "A2"}, ds, shape)
    check("按编号选中", d is not None and d.label == "A2", (d, why))

    d, why = pick_droplet({"kind": "label", "label": "Z9"}, ds, shape)
    check("编号不存在时给出提示", d is None and "没找到" in why, why)

    d, why = pick_droplet({"kind": "ordinal", "index": 1}, ds, shape)
    check("第 1 个 = 最左上的", d is not None and d.center == (100.0, 100.0), (d and d.center, why))

    d, why = pick_droplet({"kind": "ordinal", "index": -1}, ds, shape)
    check("最后一个 = 最右下的", d is not None and d.center == (800.0, 800.0), (d and d.center, why))

    d, why = pick_droplet({"kind": "ordinal", "index": 99}, ds, shape)
    check("越界序数给出提示", d is None and "没有第" in why, why)

    d, why = pick_droplet({"kind": "spatial", "region": "left"}, ds, shape, None)
    check("最左边的是 x 最小的", d is not None and d.center[0] == 100, (d and d.center, why))

    d, why = pick_droplet({"kind": "spatial", "region": "bottom_right"}, ds, shape, None)
    check("右下角选中正确的那个", d is not None and d.center == (800.0, 800.0), (d and d.center, why))

    d, why = pick_droplet({"kind": "nearest"}, ds, shape, (820.0, 820.0))
    check("离激光最近的", d is not None and d.center == (800.0, 800.0), (d and d.center, why))

    d, why = pick_droplet(None, ds, shape)
    check("没给源描述时提示", d is None, why)

    d, why = pick_droplet({"kind": "label", "label": "A1"}, [], shape)
    check("空画面时提示", d is None and "没有检测到" in why, why)


# ================================================================ 6 端到端
def test_end_to_end():
    print("\n== 6. 端到端：一句话 → 该动哪个液滴、停在哪 ==")

    shape = (1000, 1000, 3)
    lab = DropletLabeler(group_mode="none")
    ds, info = lab.update([mkdet(150, 500, 40), mkdet(400, 500, 40), mkdet(880, 600, 40)])

    # 把最左边的液滴移到右侧
    cmd = parse("把最左边的液滴移到右侧")
    source, why = pick_droplet(cmd.source, ds, shape)
    check("选中最左边的液滴", source is not None and source.center[0] == 150, why)
    point, msg = plan_landing_point(cmd.target["region"], source, ds, shape)
    check("给出右侧落点", point is not None and point[0] > 600, (point, msg))
    if point:
        near = min((((point[0] - d.center[0]) ** 2 + (point[1] - d.center[1]) ** 2) ** 0.5
                    for d in ds if d.label != source.label), default=999)
        check("落点避开其他液滴", near > 60, near)

    # 把 A2 移到 A3 旁边
    cmd = parse("把A2移到A3旁边")
    source, _ = pick_droplet(cmd.source, ds, shape)
    target, _ = pick_droplet({"kind": "label", "label": cmd.target["label"]}, ds, shape)
    check("A2/A3 都找到了", source is not None and target is not None)
    if source and target:
        point, msg = plan_beside_point(target, source, ds, shape)
        check("A3 旁边有停靠点", point is not None, msg)

    # 清单输出
    text = format_roster(ds, info)
    check("清单里含编号与位置", "A1" in text and "位置" in text, text[:80])


def main():
    print("=" * 62)
    print("Cora 离线自测")
    print("=" * 62)
    test_labeling()
    test_color_grouping()
    test_parser()
    test_planning()
    test_picking()
    test_end_to_end()
    print("\n" + "=" * 62)
    print(f"通过 {PASS} 项，失败 {FAIL} 项")
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
