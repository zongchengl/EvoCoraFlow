# -*- coding: utf-8 -*-
"""全液滴双层任务规划（纯逻辑，无硬件副作用）。

上层使用可变长批次编码与各液滴的落点候选序号，联合搜索分批、顺序先验
和落点；下层用最近邻 + 2-opt 改善批内顺序，并在 26×26 网格中解码落点。
规划失败会整体拒绝，不返回可被
误执行的部分计划。
"""

from dataclasses import dataclass
import math
import random

from labeling import dist


REGION_RECTS = {
    "left": (0.05, 0.10, 0.36, 0.90),
    "right": (0.64, 0.10, 0.95, 0.90),
    "top": (0.10, 0.05, 0.90, 0.36),
    "bottom": (0.10, 0.64, 0.90, 0.95),
    "center": (0.34, 0.34, 0.66, 0.66),
    "top_left": (0.05, 0.05, 0.36, 0.36),
    "top_right": (0.64, 0.05, 0.95, 0.36),
    "bottom_left": (0.05, 0.64, 0.36, 0.95),
    "bottom_right": (0.64, 0.64, 0.95, 0.95),
}


def region_rect(region, width, height):
    fx1, fy1, fx2, fy2 = REGION_RECTS.get(region, REGION_RECTS["center"])
    return (fx1 * width, fy1 * height, fx2 * width, fy2 * height)


def _radius(droplet):
    return max(2.0, float(getattr(droplet, "radius", 30.0) or 30.0))


def _clearance(a, b):
    return dist(a, b)


def greedy_nearest_order(points, start=None):
    """确定性最近邻初解。points 为 (id, center) 列表。"""
    remaining = list(points)
    order = []
    current = start
    while remaining:
        if current is None:
            next_item = min(remaining, key=lambda item: (item[1][1], item[1][0], item[0]))
        else:
            next_item = min(remaining, key=lambda item: (dist(current, item[1]), item[0]))
        remaining.remove(next_item)
        order.append(next_item[0])
        current = next_item[1]
    return order


def optimize_order_2opt(order, points_by_id, start=None, turn_weight=0.0):
    order = list(order)
    if len(order) < 3:
        return order

    def cost(candidate):
        total = 0.0
        prev = start
        for key in candidate:
            point = points_by_id[key]
            if prev is not None:
                total += dist(prev, point)
            prev = point
        if turn_weight > 0.0:
            prev = start
            for i in range(len(candidate) - 1):
                cur = points_by_id[candidate[i]]
                nxt = points_by_id[candidate[i + 1]]
                if prev is not None:
                    ax, ay = prev[0] - cur[0], prev[1] - cur[1]
                    bx, by = nxt[0] - cur[0], nxt[1] - cur[1]
                    na, nb = math.hypot(ax, ay), math.hypot(bx, by)
                    if na > 1e-6 and nb > 1e-6:
                        cosine = max(-1.0, min(1.0, (ax * bx + ay * by) / (na * nb)))
                        total += turn_weight * (1.0 - cosine) * 100.0
                prev = cur
        return total

    best = cost(order)
    changed = True
    while changed:
        changed = False
        for i in range(len(order) - 2):
            for j in range(i + 2, len(order) + 1):
                candidate = order[:i] + list(reversed(order[i:j])) + order[j:]
                value = cost(candidate)
                if value + 1e-6 < best:
                    order, best, changed = candidate, value, True
    return order


def _flatten_chromosome(chromosome):
    return [label for batch in chromosome for label in batch]


def _cut_positions(chromosome):
    cuts = set()
    offset = 0
    for batch in chromosome[:-1]:
        offset += len(batch)
        cuts.add(offset - 1)
    return cuts


def _make_chromosome(order, cuts, max_batch_size):
    """Encode a route as a variable-length list of non-empty task batches."""
    order = list(order)
    if not order:
        return []
    cuts = {int(pos) for pos in (cuts or ()) if 0 <= int(pos) < len(order) - 1}
    batches = []
    current = []
    for index, label in enumerate(order):
        current.append(label)
        at_limit = len(current) >= max_batch_size
        if index == len(order) - 1 or at_limit or index in cuts:
            batches.append(current)
            current = []
    return batches


def _order_crossover(first, second, rng):
    """Order-preserving crossover for two label permutations."""
    if len(first) < 2:
        return list(first)
    left, right = sorted(rng.sample(range(len(first)), 2))
    child = [None] * len(first)
    child[left:right + 1] = first[left:right + 1]
    used = set(child[left:right + 1])
    fill = [label for label in second[right + 1:] + second[:right + 1]
            if label not in used]
    slots = list(range(right + 1, len(first))) + list(range(0, left))
    for slot, label in zip(slots, fill):
        child[slot] = label
    return child


def _nondominated(points):
    front = []
    for candidate in points:
        dominated = False
        for other in points:
            if other is candidate:
                continue
            if (all(a <= b + 1e-9 for a, b in zip(other["objectives"], candidate["objectives"]))
                    and any(a < b - 1e-9 for a, b in zip(other["objectives"], candidate["objectives"]))):
                dominated = True
                break
        if not dominated:
            front.append(candidate)
    return front


@dataclass
class BatchTask:
    label: str
    source_center: tuple
    target_point: tuple
    radius: float
    batch_index: int
    order_index: int
    source_group: str = "A"

    def to_dict(self):
        return {
            "label": self.label,
            "source_center": tuple(round(float(v), 2) for v in self.source_center),
            "target_point": tuple(round(float(v), 2) for v in self.target_point),
            "radius": round(float(self.radius), 2),
            "batch_index": int(self.batch_index),
            "order_index": int(self.order_index),
        }


class DualLayerBatchPlanner:
    """可变长分批搜索 + 安全网格落点分配 + 批内近邻/2-opt。"""

    def __init__(self, grid=26, clearance=1.35, population_size=10,
                 generations=8, seed=17, max_batch_size=8,
                 batch_overhead=120.0, turn_weight=0.12):
        self.grid = max(4, int(grid))
        self.clearance = max(1.0, float(clearance))
        self.population_size = max(4, int(population_size))
        self.generations = max(1, int(generations))
        self.seed = int(seed)
        self.max_batch_size = max(1, int(max_batch_size))
        self.batch_overhead = max(0.0, float(batch_overhead))
        self.turn_weight = max(0.0, float(turn_weight))

    def _candidate_points(self, source, region, frame_shape, static_droplets,
                          remaining, reserved, median_radius):
        height, width = frame_shape[:2]
        x1, y1, x2, y2 = region_rect(region, width, height)
        cx, cy = (x1 + x2) * 0.5, (y1 + y2) * 0.5
        diag = max(1.0, math.hypot(width, height))
        radius = _radius(source)
        clearance = self.clearance
        scored = []
        for iy in range(self.grid):
            y = y1 + (y2 - y1) * (iy + 0.5) / self.grid
            for ix in range(self.grid):
                x = x1 + (x2 - x1) * (ix + 0.5) / self.grid
                point = (x, y)
                if x < radius * 1.15 or x > width - radius * 1.15 or y < radius * 1.15 or y > height - radius * 1.15:
                    continue
                min_margin = float("inf")
                valid = True
                # All unmoved sources and nonmoving objects remain obstacles.
                for other in list(static_droplets) + list(remaining):
                    need = (radius + _radius(other)) * clearance
                    gap = _clearance(point, other.center) - need
                    min_margin = min(min_margin, gap)
                    if gap < 0:
                        valid = False
                        break
                if not valid:
                    continue
                for other_point, other_radius in reserved:
                    need = (radius + other_radius) * clearance
                    gap = _clearance(point, other_point) - need
                    min_margin = min(min_margin, gap)
                    if gap < 0:
                        valid = False
                        break
                if not valid:
                    continue
                center_cost = _clearance(point, (cx, cy)) / diag
                travel_cost = _clearance(point, source.center) / diag
                safety_reward = max(-0.15, min(0.35, min_margin / max(1.0, median_radius * 4.0)))
                score = center_cost * 0.18 + travel_cost * 0.82 - safety_reward * 0.12
                scored.append((score, point, min_margin))
        scored.sort(key=lambda item: (item[0], -item[2]))
        return scored

    def _evaluate(self, chromosome, by_label, movable, frame_shape, region,
                  laser_center, fixed_droplets, median_radius, landing_choices=None):
        landing_choices = dict(landing_choices or {})
        remaining = list(movable)
        reserved = []
        cursor = laser_center
        tasks = []
        total_distance = 0.0
        min_margin = float("inf")
        label_batches = [list(batch) for batch in chromosome]
        labels = _flatten_chromosome(label_batches)
        if (not label_batches or any(not batch or len(batch) > self.max_batch_size
                                     for batch in label_batches)
                or len(labels) != len(by_label) or len(set(labels)) != len(labels)
                or set(labels) != set(by_label)):
            return None

        # The lower layer selects the within-batch route before assigning
        # landing points. This keeps each target valid for the actual execution
        # order: every not-yet-moved droplet is still treated as an obstacle.
        for batch_index, labels in enumerate(label_batches):
            point_map = {label: by_label[label].center for label in labels}
            route = greedy_nearest_order(
                [(label, point_map[label]) for label in labels], cursor)
            route = optimize_order_2opt(route, point_map, start=cursor,
                                        turn_weight=self.turn_weight)
            for label in route:
                source = by_label[label]
                occupied = [d for d in remaining if d.label != label]
                candidates = self._candidate_points(
                    source, region, frame_shape, fixed_droplets, occupied,
                    reserved, median_radius)
                if not candidates:
                    return None
                # The upper layer chooses a rank among the best feasible grid
                # points. Decode only after route ordering, so untransported
                # droplets and all reserved targets retain their clearance.
                rank = min(max(0, int(landing_choices.get(label, 0))),
                           min(7, len(candidates) - 1))
                _, target, margin = candidates[rank]
                if cursor is not None:
                    total_distance += dist(cursor, source.center)
                total_distance += dist(source.center, target)
                cursor = target
                min_margin = min(min_margin, margin)
                tasks.append(BatchTask(
                    label=label, source_center=source.center,
                    target_point=target, radius=_radius(source),
                    batch_index=batch_index, order_index=len(tasks),
                    source_group=getattr(source, "group", "A")))
                reserved.append((target, _radius(source)))
                remaining = [d for d in remaining if d.label != label]

        # Route-length, batch overhead, and inverse safety margin are kept as
        # separate objectives; the scalar score selects a practical compromise.
        batch_count = len(label_batches)
        if math.isinf(min_margin):
            min_margin = max(1.0, math.hypot(frame_shape[1], frame_shape[0]))
        safety_penalty = 1.0 / max(1.0, min_margin + median_radius)
        crowding = 1.0 / max(1.0, median_radius + min_margin)
        objectives = (total_distance, float(batch_count), safety_penalty + crowding)
        scalar = total_distance + self.batch_overhead * max(0, batch_count - 1) + safety_penalty * 1.5e4 + crowding * 4e3
        return {"tasks": tasks, "objectives": objectives, "score": scalar,
                "batches": batch_count, "distance": total_distance,
                "min_margin": min_margin, "batch_cuts": max(0, batch_count - 1),
                "landing_choices": landing_choices}

    def plan(self, droplets, target_region, frame_shape, laser_center=None,
             moving_labels=None):
        """Return ``(plan, error)``. No partial plan is returned on failure."""
        droplets = list(droplets or [])
        if not droplets:
            return None, "没有可执行的液滴"
        moving_labels = set(moving_labels or [d.label for d in droplets])
        movable = [d for d in droplets if d.label in moving_labels]
        fixed = [d for d in droplets if d.label not in moving_labels]
        if not movable:
            return None, "没有选择到待移动液滴"
        by_label = {d.label: d for d in movable}
        heights, widths = frame_shape[:2]
        rect = region_rect(target_region, widths, heights)
        if rect[2] - rect[0] < 2 or rect[3] - rect[1] < 2:
            return None, "目标区域无效"
        median_radius = sorted(_radius(d) for d in movable)[len(movable) // 2]
        points_by_id = {d.label: d.center for d in movable}
        base_order = greedy_nearest_order([(d.label, d.center) for d in movable], laser_center)
        if laser_center is not None:
            base_order = optimize_order_2opt(base_order, points_by_id,
                                             start=laser_center,
                                             turn_weight=self.turn_weight)

        rng = random.Random(self.seed + len(movable) * 101 + int(sum(d.center[0] for d in movable)))
        population = []

        candidates_orders = [base_order, sorted(base_order), list(reversed(base_order))]
        if len(base_order) > 3:
            far_first = list(base_order)
            far_first.sort(key=lambda label: dist(laser_center, points_by_id[label])
                           if laser_center is not None else -points_by_id[label][0], reverse=True)
            candidates_orders.append(far_first)
        for index in range(self.population_size):
            order = list(candidates_orders[index % len(candidates_orders)])
            if index >= len(candidates_orders):
                rng.shuffle(order)
            # The chromosome's outer length and each batch's length both vary.
            # Max-size splits are enforced by the encoder as a hard bound.
            cut_positions = set()
            if len(order) > 1 and index > 0:
                batch_span = rng.randint(1, self.max_batch_size)
                cut_positions.update(range(batch_span - 1, len(order) - 1, batch_span))
                cut_positions = {cut for cut in cut_positions if rng.random() < 0.55}
            chromosome = _make_chromosome(order, cut_positions, self.max_batch_size)
            landing_choices = {label: (0 if index == 0 else rng.randrange(8))
                               for label in order}
            evaluated = self._evaluate(chromosome, by_label, movable, frame_shape,
                                       target_region, laser_center, fixed, median_radius,
                                       landing_choices)
            if evaluated is not None:
                population.append((chromosome, evaluated))

        if not population:
            return None, (f"{target_region}区域无法为全部 {len(movable)} 个液滴分配满足净空的落点；"
                          "未启动移动。请扩大目标区域或降低拥挤程度。")

        pareto_archive = []
        for _, evaluation in population:
            pareto_archive = _nondominated(pareto_archive + [evaluation])
        for _ in range(self.generations):
            population.sort(key=lambda item: item[1]["score"])
            elites = population[:max(2, self.population_size // 3)]
            children = list(elites)
            while len(children) < self.population_size:
                parent, parent_eval = rng.choice(elites)
                mate, mate_eval = rng.choice(elites)
                order = _order_crossover(_flatten_chromosome(parent),
                                         _flatten_chromosome(mate), rng)
                if len(order) > 1 and rng.random() < 0.7:
                    i, j = sorted(rng.sample(range(len(order)), 2))
                    if rng.random() < 0.5:
                        order[i], order[j] = order[j], order[i]
                    else:
                        order[i:j + 1] = reversed(order[i:j + 1])
                parent_cuts = _cut_positions(parent)
                mate_cuts = _cut_positions(mate)
                old_cuts = {pos for pos in range(len(order) - 1)
                            if rng.random() < (0.65 if pos in parent_cuts else
                                               0.35 if pos in mate_cuts else 0.0)}
                if len(order) > 1 and rng.random() < 0.5:
                    pos = rng.randrange(len(order) - 1)
                    if pos in old_cuts:
                        old_cuts.remove(pos)
                    else:
                        old_cuts.add(pos)
                chromosome = _make_chromosome(order, old_cuts,
                                              self.max_batch_size)
                landing_choices = {
                    label: (parent_eval if rng.random() < 0.5 else mate_eval)
                    ["landing_choices"].get(label, 0) for label in order}
                if order:
                    landing_choices[rng.choice(order)] = rng.randrange(8)
                evaluated = self._evaluate(chromosome, by_label, movable,
                                           frame_shape, target_region,
                                           laser_center, fixed, median_radius,
                                           landing_choices)
                if evaluated is not None:
                    children.append((chromosome, evaluated))
                else:
                    children.append((parent, parent_eval))
            population = children[:self.population_size]
            for _, evaluation in population:
                pareto_archive = _nondominated(pareto_archive + [evaluation])

        population.sort(key=lambda item: item[1]["score"])
        selected = population[0][1]

        # Evaluation already applied the lower-layer route before assigning
        # targets. Preserve those exact boundaries and order in the output.
        batches = [[] for _ in range(selected["batches"])]
        for task in selected["tasks"]:
            if not 0 <= task.batch_index < len(batches):
                return None, "批量优化产生了无效批次，未启动移动"
            batches[task.batch_index].append(task)
        if any(not batch for batch in batches):
            return None, "批量优化产生了空批次，未启动移动"
        flat = [task for batch in batches for task in batch]
        plan = {
            "region": target_region,
            "batches": [[task.to_dict() for task in batch] for batch in batches],
            "tasks": [task.to_dict() for task in flat],
            "objectives": {
                "estimated_distance_px": round(float(selected["distance"]), 2),
                "batch_count": len(batches),
                "minimum_clearance_margin_px": round(float(selected["min_margin"]), 2),
                "pareto_candidates": len(pareto_archive),
            },
            "encoding": "variable_length_batches_of_label_permutations",
            "landing_choice_ranks": selected["landing_choices"],
            "grid": self.grid,
        }
        return plan, None

