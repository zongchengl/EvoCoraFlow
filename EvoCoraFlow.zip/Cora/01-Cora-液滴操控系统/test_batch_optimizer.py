# -*- coding: utf-8 -*-
"""Batch planning and queue tests; all actuators are replaced by test doubles."""
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import batch_optimizer
import executor
from command_parser import parse


def droplet(label, x, y, radius=14):
    center = (float(x), float(y))
    return SimpleNamespace(
        label=label,
        center=center,
        raw_center=center,
        radius=float(radius),
        group="A",
        det={"name": "droplet", "center": center,
             "xyxy": (x-radius, y-radius, x+radius, y+radius)},
    )


def planner(max_batch_size=3, **kwargs):
    return batch_optimizer.DualLayerBatchPlanner(
        grid=26, clearance=1.35, population_size=6, generations=3,
        seed=17, max_batch_size=max_batch_size, **kwargs)


class BatchPlanningTests(unittest.TestCase):
    def test_upper_landing_gene_changes_feasible_decoded_target(self):
        source = droplet("A1", 100, 250)
        solver = planner()
        args = ([["A1"]], {"A1": source}, [source], (1000, 1000, 3),
                "right", (60, 250), [], source.radius)
        first = solver._evaluate(*args, landing_choices={"A1": 0})
        alternative = solver._evaluate(*args, landing_choices={"A1": 7})
        self.assertIsNotNone(first)
        self.assertIsNotNone(alternative)
        self.assertNotEqual(first["tasks"][0].target_point,
                            alternative["tasks"][0].target_point)

    def test_single_droplet_is_a_nonempty_one_task_batch(self):
        plan, error = planner().plan(
            [droplet("A1", 100, 250)], "right", (1000, 1000, 3),
            laser_center=(60, 250))
        self.assertIsNone(error)
        self.assertEqual(len(plan["tasks"]), 1)
        self.assertEqual([len(batch) for batch in plan["batches"]], [1])
        self.assertEqual(plan["tasks"][0]["label"], "A1")

    def test_variable_batches_cover_all_tasks_and_respect_clearance(self):
        items = [droplet(f"A{i+1}", 100 + (i % 4) * 130,
                         140 + (i // 4) * 260) for i in range(9)]
        solver = planner(max_batch_size=3)
        plan, error = solver.plan(items, "right", (1000, 1000, 3),
                                  laser_center=(60, 80))
        self.assertIsNone(error)
        self.assertEqual(sorted(t["label"] for t in plan["tasks"]),
                         sorted(d.label for d in items))
        self.assertTrue(all(0 < len(batch) <= 3 for batch in plan["batches"]))
        self.assertEqual(sum(map(len, plan["batches"])), len(items))

        by_label = {item.label: item for item in items}
        moved = set()
        reserved = []
        for task in plan["tasks"]:
            source = by_label[task["label"]]
            target = task["target_point"]
            for other in items:
                if other.label == source.label or other.label in moved:
                    continue
                need = (source.radius + other.radius) * solver.clearance
                self.assertGreaterEqual(batch_optimizer._clearance(target, other.center) + 1e-6,
                                        need)
            for point, radius in reserved:
                need = (source.radius + radius) * solver.clearance
                self.assertGreaterEqual(batch_optimizer._clearance(target, point) + 1e-6,
                                        need)
            moved.add(source.label)
            reserved.append((target, source.radius))

    def test_overcrowded_target_fails_without_partial_plan(self):
        moving = droplet("A1", 100, 500, 18)
        fixed = [droplet(f"B{i+1}", 660 + (i % 5) * 65,
                         120 + (i // 5) * 65, 60) for i in range(60)]
        plan, error = planner(max_batch_size=3).plan(
            [moving] + fixed, "right", (1000, 1000, 3),
            laser_center=(60, 500), moving_labels=["A1"])
        self.assertIsNone(plan)
        self.assertIn("未启动移动", error)

    def test_full_droplet_command_executes_planned_queue_in_order(self):
        items = [droplet("A1", 100, 160), droplet("A2", 180, 420),
                 droplet("A3", 300, 700)]
        command = parse("把全部液滴自动分批移到右侧")
        self.assertTrue(command.auto_batch)
        self.assertEqual(command.source["letter"], None)

        args = SimpleNamespace(
            batch_grid=26, batch_population=6, batch_generations=3,
            rrt_seed=17, batch_size=2, batch_overhead=120.0,
            multi_turn_weight=0.12, association_radius=80.0)
        state = {"state": "WAIT_DROPLET"}
        engine = executor.CoraExecutor(state, args, clearance=1.35,
                                       log=lambda _message: None)
        started = []
        with patch.object(executor, "rrt_select_source_from_click",
                          side_effect=lambda *_args: None), \
             patch.object(executor, "rrt_select_fixed_target",
                          side_effect=lambda _state, point, *_args: started.append(tuple(point))), \
             patch.object(engine, "_resolve_target",
                          side_effect=lambda spec, *_args: (tuple(spec), "planned")):
            ok, message = engine.handle(command, items, (1000, 1000, 3),
                                        laser_center=(60, 100))
            self.assertTrue(ok, message)
            planned = [dict(task) for task in engine.queue]
            self.assertEqual(len(started), 1)
            while engine.queue:
                follow_up = engine.on_arrived(items, (1000, 1000, 3))
                self.assertIn("继续移动", follow_up)
            self.assertEqual(engine.on_arrived(items, (1000, 1000, 3)), "全部完成")

        self.assertEqual(len(started), len(items))
        self.assertEqual(engine.batch_active, False)
        self.assertTrue("规划完成" in message)

    def test_missing_queued_source_aborts_queue_and_requests_stop_once(self):
        args = SimpleNamespace(batch_grid=26, batch_population=6,
                               batch_generations=2, rrt_seed=17,
                               batch_size=2, batch_overhead=120.0,
                               multi_turn_weight=0.12,
                               association_radius=80.0)
        state = {"state": "MOVE_TO_TARGET", "route_id": 2}
        engine = executor.CoraExecutor(state, args, log=lambda _message: None)
        engine.batch_active = True
        engine.queue_active = True
        engine.queue = [{"label": "A9", "source_center": (300.0, 300.0),
                         "target_point": (800.0, 500.0)}]
        with patch.object(executor, "switch_mode", side_effect=lambda cs, mode: cs.update(
                state="WAIT_DROPLET", mode=mode)):
            result = engine.on_arrived([], (1000, 1000, 3))
        self.assertIn("批量任务已中止", result)
        self.assertFalse(engine.queue)
        self.assertFalse(engine.queue_active)
        self.assertTrue(engine.consume_stop_request())
        self.assertFalse(engine.consume_stop_request())


if __name__ == "__main__":
    unittest.main(verbosity=2)
