# -*- coding: utf-8 -*-
"""No hardware tests: synthetic frames, detector packets and control boundary."""
import tempfile
import time
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, Mock

import cv2
import numpy as np
import cora
from test_detection_filter import det


class DetectionIntegrationTests(unittest.TestCase):
    def test_normal_labeling_uses_inference_frame_for_color_features(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "input.png"
            cv2.imwrite(str(path), np.zeros((80, 80, 3), dtype=np.uint8))
            args = cora.build_parser().parse_args([
                "--source", "image:" + str(path), "--no-detect", "--no-motor",
                "--no-display", "--max-frames", "1", "--fps-limit", "0"])
            app = cora.CoraApp(args)
            matched = np.full((80, 80, 3), 77, dtype=np.uint8)
            packet = {"seq": 0, "timestamp": time.time(), "detections": [],
                      "frame": matched}
            app.detector = SimpleNamespace(get_latest=lambda: packet, close=lambda: None)
            app.model = object()
            with patch.object(app.labeler, "update", wraps=app.labeler.update) as update, \
                 patch.object(cora.core, "build_control_step", return_value={}):
                app.run()
            self.assertIs(update.call_args.args[1], matched)

    def test_scale_uses_actual_frame_independent_of_camera_config(self):
        recommendations = []
        for size in (640, 9999):
            app = cora.CoraApp.__new__(cora.CoraApp)
            app.args = cora.build_parser().parse_args(["--width", str(size),
                                                     "--height", str(size)])
            app.model = object()
            app.detector = None
            app._scale_reported = False
            app._update_scale_recommendation(np.zeros((720, 1280, 3), np.uint8),
                                              [det()])
            recommendations.append(app.scale_recommendation)
        self.assertEqual(*recommendations)

    def test_missing_camera_frame_brakes_before_next_observation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "input.png"
            frame = np.zeros((80, 80, 3), dtype=np.uint8)
            cv2.imwrite(str(path), frame)
            args = cora.build_parser().parse_args([
                "--source", "image:" + str(path), "--no-detect", "--no-motor",
                "--no-display", "--max-frames", "1", "--fps-limit", "0"])
            app = cora.CoraApp(args)
            app.stage = Mock()
            app.last_command = (4, 5)
            calls = []
            def next_frame():
                calls.append(True)
                if len(calls) == 2:
                    return None
                if len(calls) == 3:
                    self.assertEqual(app.last_command, (0, 0))
                    app.stage.stop_axis.assert_any_call("x")
                    app.stage.stop_axis.assert_any_call("y")
                return frame
            app.source.get_frame = next_frame
            app.run()
            self.assertEqual(len(calls), 3)

    def test_offline_pid_tuning_branch_does_not_construct_device_app(self):
        with patch.object(cora.core, "run_pid_tuning") as tune, \
             patch.object(cora, "CoraApp", side_effect=AssertionError("device app started")), \
             patch.object(sys, "argv", ["cora.py", "--tune-from-metrics", "offline.json"]):
            self.assertEqual(cora.main(), 0)
        tune.assert_called_once()

    def test_default_launch_does_not_enable_unvalidated_filter(self):
        args = cora.build_parser().parse_args([])
        self.assertFalse(args.visual_filter)
        self.assertIsNone(args.diagnostic_dir)

    def test_experimental_mode_rejected_before_opening_any_source(self):
        args = cora.build_parser().parse_args(["--visual-filter"])
        # create_source may open hardware; replace it with a failure sentinel.
        with patch.object(cora, "create_source", side_effect=AssertionError("hardware opened")):
            with self.assertRaisesRegex(ValueError, "no-motor"):
                cora.CoraApp(args)

    def test_diagnostic_recording_requires_no_motor_before_opening_source(self):
        args = cora.build_parser().parse_args(["--diagnostic-dir", "unused"])
        with patch.object(cora, "create_source", side_effect=AssertionError("hardware opened")):
            with self.assertRaisesRegex(ValueError, "no-motor"):
                cora.CoraApp(args)

    def test_worker_keeps_owned_frame_for_the_actual_prediction(self):
        pixels = np.full((80, 80, 3), 77, dtype=np.uint8)
        class Camera:
            def get_frame_with_seq(self, timeout):
                return 7, pixels
        class Model:
            def predict(self, frame, **kwargs):
                return [SimpleNamespace(boxes=None)]
        worker = cora.core.LatestDetectionWorker(Camera(), Model(), 1280, .3, "cpu", retain_frame=True)
        try:
            deadline = time.monotonic() + 5
            packet = None
            while packet is None and time.monotonic() < deadline:
                packet = worker.get_latest()
                time.sleep(.01)
            self.assertIsNotNone(packet)
            pixels[:] = 0
            self.assertEqual(packet["frame_seq"], 7)
            self.assertTrue(np.all(packet["frame"] == 77))
        finally:
            worker.close()

    def test_display_experiment_uses_matching_frame_but_control_keeps_raw_boxes(self):
        with tempfile.TemporaryDirectory() as root:
            root = Path(root)
            live_frame = np.zeros((80, 80, 3), dtype=np.uint8)
            live_frame[::2] = 255
            cv2.imencode(".png", live_frame)[1].tofile(str(root / "input.png"))
            args = cora.build_parser().parse_args([
                "--source", "image:" + str(root / "input.png"), "--no-detect", "--no-motor",
                "--no-display", "--max-frames", "2", "--fps-limit", "0", "--visual-filter",
                "--diagnostic-dir", str(root / "samples")])
            app = cora.CoraApp(args)
            raw = [det(), det("laser")]
            packet = {"seq": 0, "frame_seq": 4, "timestamp": time.time(), "infer_ms": 1.0,
                      "detections": raw, "frame": np.full((80,80,3), 80, dtype=np.uint8)}
            app.detector = SimpleNamespace(get_latest=lambda: packet, close=lambda: None)
            app.model = object()
            labeled = []
            control_inputs = []
            real_update = app.labeler.update
            def label(ds, frame):
                labeled.append(list(ds))
                return real_update(ds, frame)
            def control(ds, *unused):
                control_inputs.append(list(ds))
                return {}
            app.labeler.update = label
            with patch.object(cora.core, "build_control_step", side_effect=control):
                app.run()
            self.assertEqual(len(labeled), 2)
            self.assertEqual(labeled, [[raw[1]], [raw[1]]])
            self.assertEqual(control_inputs, [raw, raw])
            self.assertEqual(len(list((root / "samples").rglob("*.json"))), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
