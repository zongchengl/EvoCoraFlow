# -*- coding: utf-8 -*-
"""Cora 指令执行器。

把解析器输出的抽象槽位，结合**当前这一帧的真实画面**求值成具体动作：
    「最左边的液滴」 -> 某一帧检测框
    「右侧」         -> 一个不撞到任何液滴的安全落点

之所以在这里才求值，是因为液滴一直在动：指令解析时不该假设画面静止。
"""

import math

from labeling import dist, order_row_major

try:
    from droplet_core import (
        select_source_from_click,
        select_target_from_click,
        return_laser_to_home,
        STATE_ARRIVED,
        rrt_select_source_from_click,
        rrt_select_fixed_target,
        MODE_RRT,
        switch_mode,
        MODE_POINT,
    )
    from batch_optimizer import DualLayerBatchPlanner
except ImportError:      # 允许脱离完整核心做逻辑单测
    select_source_from_click = None
    select_target_from_click = None
    return_laser_to_home = None
    STATE_ARRIVED = "ARRIVED"
    rrt_select_source_from_click = None
    rrt_select_fixed_target = None
    MODE_RRT = "RRT_PLANNER"
    switch_mode = None
    MODE_POINT = "POINT_TARGET"
    DualLayerBatchPlanner = None


# 各区域相对画面的占比（x1, y1, x2, y2）
REGION_RECTS = {
    "left":         (0.05, 0.10, 0.36, 0.90),
    "right":        (0.64, 0.10, 0.95, 0.90),
    "top":          (0.10, 0.05, 0.90, 0.36),
    "bottom":       (0.10, 0.64, 0.90, 0.95),
    "center":       (0.34, 0.34, 0.66, 0.66),
    "top_left":     (0.05, 0.05, 0.36, 0.36),
    "top_right":    (0.64, 0.05, 0.95, 0.36),
    "bottom_left":  (0.05, 0.64, 0.36, 0.95),
    "bottom_right": (0.64, 0.64, 0.95, 0.95),
}

DIRECTION_VECTORS = {
    "left": (-1.0, 0.0), "right": (1.0, 0.0),
    "top": (0.0, -1.0), "bottom": (0.0, 1.0),
    "top_left": (-0.7071, -0.7071), "top_right": (0.7071, -0.7071),
    "bottom_left": (-0.7071, 0.7071), "bottom_right": (0.7071, 0.7071),
}

DEFAULT_CLEARANCE = 1.35       # 落点所需净空 = (源半径 + 邻居半径) × 该系数
DEFAULT_REL_STRIDE = 0.15      # "往右移一点" 的默认步长（画面短边的比例）


def region_rect(region, width, height):
    fx1, fy1, fx2, fy2 = REGION_RECTS.get(region, REGION_RECTS["center"])
    return (fx1 * width, fy1 * height, fx2 * width, fy2 * height)


def rect_center(rect):
    x1, y1, x2, y2 = rect
    return ((x1 + x2) * 0.5, (y1 + y2) * 0.5)


def point_in_rect(point, rect):
    x, y = point
    x1, y1, x2, y2 = rect
    return x1 <= x <= x2 and y1 <= y <= y2


# ================================================================ 源液滴选择
def pick_droplet(spec, droplets, frame_shape, laser_center=None):
    """按槽位挑出一个液滴。返回 (droplet, 说明文字) 或 (None, 原因)。"""
    if not droplets:
        return None, "画面里没有检测到液滴"
    if not spec:
        return None, "没有指定要移动哪个液滴"

    width, height = frame_shape[1], frame_shape[0]
    kind = spec.get("kind")

    if kind == "label":
        want = spec["label"].upper()
        for d in droplets:
            if d.label.upper() == want:
                return d, f"锁定 {d.label}"
        return None, f"没找到编号 {want}（当前有 {', '.join(d.label for d in droplets)}）"

    if kind == "nearest":
        if laser_center is None:
            return droplets[0], "没有激光位置信息，取第一个液滴"
        best = min(droplets, key=lambda d: dist(d.center, laser_center))
        return best, f"离激光最近的是 {best.label}"

    if kind == "group":
        letter = spec.get("letter")
        if letter:
            members = [d for d in droplets if d.group.upper() == letter.upper()]
            if not members:
                return None, f"没有 {letter} 类液滴"
            ordered = order_row_major(members)
            return ordered[0], f"{letter} 类共 {len(members)} 个，从 {ordered[0].label} 开始"
        ordered = order_row_major(droplets)
        return ordered[0], f"共 {len(ordered)} 个液滴，从 {ordered[0].label} 开始"

    if kind == "ordinal":
        ordered = order_row_major(droplets)
        idx = spec.get("index", 1)
        if idx == -1:
            return ordered[-1], f"最后一个是 {ordered[-1].label}"
        if 1 <= idx <= len(ordered):
            return ordered[idx - 1], f"第 {idx} 个是 {ordered[idx - 1].label}"
        return None, f"只有 {len(ordered)} 个液滴，没有第 {idx} 个"

    if kind == "spatial":
        return _pick_spatial(spec.get("region"), droplets, width, height)

    return None, "无法识别的液滴描述"


def _pick_spatial(region, droplets, width, height):
    rect = region_rect(region, width, height)
    inside = [d for d in droplets if point_in_rect(d.center, rect)]
    pool = inside if inside else droplets
    scope = "该区域内" if inside else "全画面"

    if region == "left":
        best = min(pool, key=lambda d: d.center[0])
    elif region == "right":
        best = min(pool, key=lambda d: -d.center[0])
    elif region == "top":
        best = min(pool, key=lambda d: d.center[1])
    elif region == "bottom":
        best = min(pool, key=lambda d: -d.center[1])
    elif region == "center":
        cx, cy = rect_center(rect)
        best = min(pool, key=lambda d: dist(d.center, (cx, cy)))
    else:                                   # 四个角：取离该角最近的
        ax = rect[0] if "left" in region else rect[2]
        ay = rect[1] if "top" in region else rect[3]
        best = min(pool, key=lambda d: dist(d.center, (ax, ay)))

    return best, f"{scope}最靠{_region_cn(region)}的是 {best.label}"


def _region_cn(region):
    return {"left": "左", "right": "右", "top": "上", "bottom": "下",
            "center": "中", "top_left": "左上", "top_right": "右上",
            "bottom_left": "左下", "bottom_right": "右下"}.get(region, region)


# ================================================================ 落点规划
def _clearance_ok(point, source, droplets, clearance, exclude_labels=()):
    """落点是否对所有液滴都留够了净空。"""
    for d in droplets:
        if d.label in exclude_labels:
            continue
        need = (d.radius + source.radius) * clearance
        if dist(point, d.center) < need:
            return False
    return True


def _margin_ok(point, source, width, height, edge_factor=1.15):
    r = source.radius * edge_factor
    x, y = point
    return r <= x <= width - r and r <= y <= height - r


def plan_landing_point(region, source, droplets, frame_shape,
                       clearance=DEFAULT_CLEARANCE, grid=26, exclude=()):
    """在目标区域里找一个安全的落点。

    策略：区域内网格采样 → 过滤掉与任何液滴冲突/贴边的点 →
    在剩下的点里选"离区域中心近、离原位置远"的那个。
    若一个都不剩，逐步放宽净空要求，最多三轮。
    """
    height, width = frame_shape[0], frame_shape[1]
    rect = region_rect(region, width, height)
    cx, cy = rect_center(rect)
    x1, y1, x2, y2 = rect
    if x2 - x1 < 1 or y2 - y1 < 1:
        return None, f"目标区域 {_region_cn(region)} 太小"

    # Clearance is a hard constraint, including single-droplet tasks.
    attempts = [clearance]
    for attempt_i, clr in enumerate(attempts):
        best, best_score = None, None
        for iy in range(grid):
            for ix in range(grid):
                px = x1 + (x2 - x1) * (ix + 0.5) / grid
                py = y1 + (y2 - y1) * (iy + 0.5) / grid
                if not _margin_ok((px, py), source, width, height):
                    continue
                if not _clearance_ok((px, py), source, droplets, clr, exclude_labels=set(exclude)):
                    continue
                # 越靠近区域中心越好；同时希望离起始位置有实际位移
                d_center = dist((px, py), (cx, cy))
                d_source = dist((px, py), source.center)
                diag = math.hypot(width, height)
                score = -(d_center / diag) * 1.0 + (d_source / diag) * 0.35
                if best_score is None or score > best_score:
                    best, best_score = (px, py), score
        if best is not None:
            msg = f"落点 ({best[0]:.0f}, {best[1]:.0f})"
            if attempt_i:
                msg += f"（净空放宽到 {clr:.2f}×）"
            return best, msg

    return None, (f"{_region_cn(region)}区域被其他液滴占满，放不下；"
                  f"可以先把旁边的液滴挪开，或者换一个区域")


def plan_beside_point(target, source, droplets, frame_shape, clearance=DEFAULT_CLEARANCE,
                      samples=28, exclude=()):
    """目标是一个液滴时，在它周围找一个能停靠的空位。"""
    height, width = frame_shape[0], frame_shape[1]
    base = (target.radius + source.radius) * clearance
    for ratio in (1.0, 1.25, 1.5, 1.8):
        radius = base * ratio
        candidates = []
        for i in range(samples):
            ang = 2 * math.pi * i / samples
            px = target.center[0] + radius * math.cos(ang)
            py = target.center[1] + radius * math.sin(ang)
            if not _margin_ok((px, py), source, width, height):
                continue
            if not _clearance_ok((px, py), source, droplets, clearance,
                                 exclude_labels=set(exclude) | {target.label}):
                continue
            candidates.append((px, py))
        if candidates:
            # 选离源液滴最近的那个：位移最小、最省时间
            best = min(candidates, key=lambda p: dist(p, source.center))
            return best, f"停在 {target.label} 旁边 ({best[0]:.0f}, {best[1]:.0f})"
    return None, f"围绕 {target.label} 没有找到能停下的空位"


def plan_delta_point(region, amount, unit, source, frame_shape, px_per_mm=None):
    """相对位移：往右移一点 / 向右移动 200 像素。"""
    vec = DIRECTION_VECTORS.get(region)
    if vec is None:
        return None, "不支持的移动方向"
    height, width = frame_shape[0], frame_shape[1]
    if amount is None:
        distance = min(width, height) * DEFAULT_REL_STRIDE
    elif unit in ("毫米", "mm"):
        if not px_per_mm:
            return None, "要按毫米移动需要先设置 --px-per-mm（每毫米多少像素）"
        distance = amount * px_per_mm
    elif unit in ("厘米", "cm"):
        if not px_per_mm:
            return None, "要按厘米移动需要先设置 --px-per-mm"
        distance = amount * px_per_mm * 10.0
    else:
        distance = amount

    px = source.center[0] + vec[0] * distance
    py = source.center[1] + vec[1] * distance
    px = min(max(px, source.radius), width - source.radius)
    py = min(max(py, source.radius), height - source.radius)
    return (px, py), f"向{_region_cn(region)}移动 {distance:.0f}px"


# ================================================================ 执行器
class CoraExecutor:
    """把指令作用到控制状态上。"""

    def __init__(self, control_state, args, px_per_mm=None, clearance=DEFAULT_CLEARANCE,
                 log=print, on_event=None):
        self.cs = control_state
        self.args = args
        self.px_per_mm = px_per_mm
        self.clearance = clearance
        self.log = log
        self.on_event = on_event        # 回调，用于把消息送到界面
        # 依次移动的任务队列
        self.queue = []                 # [(droplet, target_spec), ...]
        self.queue_active = False
        # A batch remains active even when its first task is the only task.
        # This lets the ARRIVED edge emit the same completion event for one
        # and many droplets without changing ordinary single-move behavior.
        self.batch_active = False
        self.batch_meta = None
        self.batch_planner = (DualLayerBatchPlanner(
            grid=getattr(args, "batch_grid", 26),
            clearance=clearance,
            population_size=getattr(args, "batch_population", 10),
            generations=getattr(args, "batch_generations", 8),
            seed=getattr(args, "rrt_seed", None) or 17,
            max_batch_size=getattr(args, "batch_size", 8),
            batch_overhead=getattr(args, "batch_overhead", 120.0),
            turn_weight=getattr(args, "multi_turn_weight", 0.12),
        ) if DualLayerBatchPlanner is not None else None)

    # ------------------------------------------------------------ 事件
    def _emit(self, kind, message, **extra):
        if self.on_event:
            try:
                self.on_event(kind, message, **extra)
            except Exception:
                pass
        self.log(message)

    # ------------------------------------------------------------ 主入口
    def handle(self, cmd, droplets, frame_shape, laser_center=None):
        """执行一条指令。返回 (ok, message)。"""
        action = cmd.action

        if action == "stop":
            self._stop_all()
            return True, "已停止"

        if action == "reset":
            self._stop_all()
            if return_laser_to_home is None:
                return False, "复位功能不可用"
            ok = return_laser_to_home(self.cs)
            return (True, "激光正在回到起始液滴位置") if ok else (False, "还没选过液滴，无法复位")

        if action == "move":
            if getattr(cmd, "auto_batch", False):
                return self._do_auto_batch(cmd, droplets, frame_shape, laser_center)
            return self._do_move(cmd, droplets, frame_shape, laser_center)

        if action == "list":
            return True, ""          # 由上层用 format_roster 输出

        if action == "relabel":
            return True, "已重新编号"

        if action == "status":
            return True, self._status_text()

        if action == "help":
            return True, ""

        return False, cmd.note or "没理解这条指令"

    def _status_text(self):
        state = self.cs.get("state", "-")
        src = self.cs.get("selected_source_name")
        return f"当前状态：{state}；已选源液滴：{src or '无'}"

    def _stop_all(self):
        self.queue = []
        self.queue_active = False
        self.batch_active = False
        self.batch_meta = None
        # 交回主循环去 stop_xy，并让控制状态回到等待
        if switch_mode is not None:
            switch_mode(self.cs, MODE_POINT)
        else:
            self.cs["state"] = "WAIT_DROPLET"
            self.cs["route_id"] = self.cs.get("route_id", 0) + 1
            self.cs["selected_source_name"] = None
            self.cs["source_lock_center"] = None
        self.cs.pop("_stop_requested", None)
        self._stop_requested = True

    # ------------------------------------------------------------ 移动
    def _do_move(self, cmd, droplets, frame_shape, laser_center):
        if select_source_from_click is None:
            return False, "控制核心未加载"
        self.queue = []
        self.queue_active = False
        self.batch_active = False
        self.batch_meta = None

        source, why = pick_droplet(cmd.source, droplets, frame_shape, laser_center)
        if source is None:
            return False, why

        label = source.label

        # 依次移动：先在局部变量中准备队列，只有首个任务成功规划后
        # 才提交，避免目标解析失败留下半截队列。
        pending_queue = []
        if cmd.sweep and cmd.source and cmd.source.get("kind") == "group":
            letter = cmd.source.get("letter")
            members = [d for d in droplets
                       if (not letter or d.group.upper() == letter.upper())]
            members = [d for d in members if d.label != label]
            pending_queue = [(d, cmd.target) for d in order_row_major(members)]

        point, target_msg = self._resolve_target(cmd.target, source, droplets, frame_shape)
        if point is None:
            return False, target_msg

        if not self._start_move(source, point):
            return False, "路径规划控制不可用，未启动移动"
        self.queue = pending_queue
        self.queue_active = bool(pending_queue)
        msg = f"{why} → {target_msg}"
        if self.queue_active:
            msg += f"（后续还有 {len(self.queue)} 个液滴排队）"
        self._emit("move", msg, source=label, target=point)
        return True, msg

    def _do_auto_batch(self, cmd, droplets, frame_shape, laser_center):
        self.queue = []
        self.queue_active = False
        self.batch_active = False
        self.batch_meta = None
        if not droplets:
            return False, "画面里没有检测到液滴"
        if not cmd.target or cmd.target.get("kind") != "region":
            return False, "全液滴自动分批目前需要指定一个目标区域"
        if self.batch_planner is None:
            return False, "批量优化模块不可用"
        movable = list(droplets)
        start = laser_center or self.cs.get("laser_smooth")
        plan, error = self.batch_planner.plan(
            movable,
            cmd.target["region"],
            frame_shape,
            laser_center=start,
            moving_labels=[d.label for d in movable],
        )
        if error:
            return False, error
        tasks = list(plan.get("tasks", []))
        if not tasks:
            return False, "优化器没有生成可执行任务"
        first = tasks.pop(0)
        source, reason = self._find_task_droplet(first, droplets)
        if source is None:
            return False, f"首个批量任务失效：{reason}"
        self.queue = tasks
        self.queue_active = bool(tasks)
        self.batch_active = True
        self.batch_meta = plan.get("objectives", {})
        target = first["target_point"]
        if not self._start_move(source, target):
            self.queue = []
            self.queue_active = False
            self.batch_active = False
            self.batch_meta = None
            return False, "路径规划控制不可用，批量任务未启动"
        msg = (f"全液滴规划完成：{len(droplets)} 个液滴，"
               f"{self.batch_meta.get('batch_count', 1)} 批，网格 {plan.get('grid', 26)}×{plan.get('grid', 26)}；"
               f"首个任务 {source.label} → ({target[0]:.0f}, {target[1]:.0f})")
        if self.queue_active:
            msg += f"，后续 {len(self.queue)} 个任务"
        self._emit("batch_plan", msg, plan=plan)
        self._emit("move", msg, source=source.label, target=target)
        return True, msg

    def _find_task_droplet(self, task, droplets):
        """Resolve a planned identity by its saved position before its display label."""
        wanted_center = task.get("source_center") if isinstance(task, dict) else None
        wanted_label = task.get("label") if isinstance(task, dict) else None
        if wanted_center is None and isinstance(task, tuple) and task:
            wanted_label = getattr(task[0], "label", None)
            wanted_center = getattr(task[0], "center", None)
        if wanted_label:
            exact = next((d for d in droplets if d.label == wanted_label), None)
            if exact is not None and (wanted_center is None or dist(exact.center, wanted_center) <= max(30.0, exact.radius * 2.0)):
                return exact, "按编号匹配"
        if wanted_center is None:
            return None, "缺少位置锚点"
        candidates = sorted(droplets, key=lambda d: dist(d.center, wanted_center))
        if not candidates:
            return None, "液滴已离开画面"
        closest = candidates[0]
        limit = max(40.0, float(getattr(self.args, "association_radius", 80.0)), closest.radius * 2.5)
        if dist(closest.center, wanted_center) > limit:
            return None, "计划位置附近未找到待移动液滴"
        if len(candidates) > 1 and abs(dist(candidates[1].center, wanted_center) - dist(closest.center, wanted_center)) < max(5.0, closest.radius * 0.15):
            return None, "计划位置存在歧义，暂停该任务"
        return closest, "按位置匹配"

    def _resolve_target(self, spec, source, droplets, frame_shape):
        if isinstance(spec, (tuple, list)) and len(spec) == 2:
            point = (float(spec[0]), float(spec[1]))
            height, width = frame_shape[:2]
            if not _margin_ok(point, source, width, height):
                return None, "批量落点已接近画面边界，任务暂停"
            if not _clearance_ok(point, source, droplets, self.clearance,
                                 exclude_labels={source.label}):
                return None, "批量落点周围净空已变化，任务暂停并等待重新规划"
            return point, "已分配的批量落点"
        """把目标槽位算成一个坐标。"""
        if not spec:
            return None, "没说清要移到哪里"

        kind = spec.get("kind")

        if kind == "region":
            point, msg = plan_landing_point(spec["region"], source, droplets, frame_shape,
                                            clearance=self.clearance)
            return point, msg

        if kind == "label":
            target_det = None
            for d in droplets:
                if d.label.upper() == spec["label"].upper():
                    target_det = d
                    break
            if target_det is None:
                return None, f"没找到目标液滴 {spec['label']}"
            if target_det.label == source.label:
                return None, "源和目标不能是同一个液滴"
            point, msg = plan_beside_point(target_det, source, droplets, frame_shape,
                                           clearance=self.clearance,
                                           exclude=(source.label,))
            return point, msg

        if kind == "delta":
            point, msg = plan_delta_point(spec.get("region"), spec.get("amount"),
                                          spec.get("unit"), source, frame_shape,
                                          px_per_mm=self.px_per_mm)
            return point, msg

        if kind == "point":
            point = spec.get("point")
            if point is None or len(point) < 2:
                return None, "批量落点无效"
            return (float(point[0]), float(point[1])), "已分配的批量落点"

        return None, "无法理解的目标位置"

    def _start_move(self, source, point):
        """把源液滴和目标点写进控制状态，主循环下一帧就会开始驱动。"""
        det = source.det
        if det is None:
            return False
        try:
            if rrt_select_source_from_click is not None and rrt_select_fixed_target is not None:
                rrt_select_source_from_click(self.cs, det, self.args)
                rrt_select_fixed_target(self.cs, point, det, self.args)
            elif select_source_from_click is not None and select_target_from_click is not None:
                select_source_from_click(self.cs, det, self.args)
                select_target_from_click(self.cs, point)
            else:
                return False
        except Exception as exc:
            if switch_mode is not None:
                switch_mode(self.cs, MODE_POINT)
            self.log(f"路径规划初始化失败：{exc}")
            return False
        self._stop_requested = False
        return True

    def _abort_queued_tasks(self, reason):
        self.queue = []
        self.queue_active = False
        self.batch_active = False
        self.batch_meta = None
        if switch_mode is not None:
            switch_mode(self.cs, MODE_POINT)
        self.cs.pop("_stop_requested", None)
        self._stop_requested = True
        self.cs["_stop_requested"] = True
        message = f"批量任务已中止：{reason}"
        self._emit("batch_abort", message)
        return message

    # ------------------------------------------------------------ 队列推进
    def on_arrived(self, droplets, frame_shape):
        """主循环检测到 ARRIVED 时调用；有排队任务就启动下一个。"""
        if not self.queue_active and not self.batch_active:
            return None
        if not self.queue:
            self.queue_active = False
            self.batch_active = False
            self.batch_meta = None
            return "全部完成"

        queued = self.queue.pop(0)
        if isinstance(queued, dict):
            fresh, why = self._find_task_droplet(queued, droplets)
            target_spec = queued.get("target_point")
            label = queued.get("label", "目标液滴")
        else:
            next_droplet, target_spec = queued
            fresh, why = self._find_task_droplet({
                "label": getattr(next_droplet, "label", None),
                "source_center": getattr(next_droplet, "center", None),
            }, droplets)
            label = getattr(next_droplet, "label", "目标液滴")
        if fresh is None:
            return self._abort_queued_tasks(f"{label} 无法安全匹配（{why}）")
        point, msg = self._resolve_target(target_spec, fresh, droplets, frame_shape)
        if point is None:
            return self._abort_queued_tasks(f"{fresh.label}：{msg}")
        if not self._start_move(fresh, point):
            return self._abort_queued_tasks("路径规划控制不可用，已停在当前落点")
        return f"继续移动 {fresh.label} → {msg}（{why}）"

    # ------------------------------------------------------------ 停止标志
    def consume_stop_request(self):
        flag = getattr(self, "_stop_requested", False)
        self._stop_requested = False
        return flag
