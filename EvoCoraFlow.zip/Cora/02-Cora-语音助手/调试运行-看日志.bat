@echo off
cd /d "%~dp0"
set PY=python
"%PY%" "%~dp0main.py"
pause
