"""Voice entry/bridge regression tests without UI, network or devices."""
import ast
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from va.cora_bridge import CoraBridge


class BridgeTests(unittest.TestCase):
    def test_default_bridge_disables_motor_and_preserves_custom_roi(self):
        bridge = CoraBridge("unused", extra_args=["--width", "1024"])
        cmd = bridge.build_command()
        self.assertIn("--no-motor", cmd)
        self.assertEqual(cmd[cmd.index("--width") + 1], "1024")
        self.assertNotIn("--offset-x", cmd)

    def test_device_access_requires_explicit_motor_enable(self):
        cmd = CoraBridge("unused", hardware_enabled=True).build_command()
        self.assertNotIn("--no-motor", cmd)

    def test_camera_occupation_returns_error_without_killing_client(self):
        with tempfile.TemporaryDirectory() as folder:
            Path(folder, "cora.py").write_text("", encoding="utf-8")
            bridge = CoraBridge(folder)
            with patch.object(bridge, "_mvs_running", return_value=True), \
                 patch("va.cora_bridge.subprocess.Popen") as launch, \
                 patch("va.cora_bridge.subprocess.run") as command:
                ok, message = bridge.start()
            self.assertFalse(ok)
            self.assertIn("手动关闭", message)
            launch.assert_not_called()
            command.assert_not_called()

    def test_control_mode_is_explicit_opt_in_without_loading_ui(self):
        # Isolate the parser so this test can run without microphone/Tk packages.
        source = Path(__file__).with_name("main.py").read_text(encoding="utf-8-sig")
        tree = ast.parse(source)
        fn = next(node for node in tree.body
                  if isinstance(node, ast.FunctionDef) and node.name == "parse_startup_args")
        scope = {}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), "startup_parser", "exec"), scope)
        self.assertFalse(scope["parse_startup_args"]([]).enable_control)
        self.assertTrue(scope["parse_startup_args"](["--enable-control"]).enable_control)


if __name__ == "__main__":
    unittest.main()
