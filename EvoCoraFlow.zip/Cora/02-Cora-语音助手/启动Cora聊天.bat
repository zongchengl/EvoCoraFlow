@echo off
cd /d "%~dp0"
set "PY=pythonw"
start "" "%PY%" "%~dp0main.py"
