# -*- coding: utf-8 -*-
"""生成 Cora 语音助手的图标（.ico），并可选地在桌面创建带该图标的快捷方式。

图标风格与主界面一致：靛蓝→紫渐变底 + 一只发光水母。
用法：
    python make_icon.py                 # 只生成 ico
    python make_icon.py --shortcut      # 生成 ico 并在桌面建快捷方式
"""

import argparse
import base64
import math
import os
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(HERE, "cora.ico")
APP = os.path.join(HERE, "main.py")

GRAD_TOP = (16, 17, 32)
GRAD_BOT = (35, 24, 66)


def _lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def _background(size):
    """竖向渐变 + 中央一团紫色柔光，再切成圆角方形。"""
    w = h = size
    img = Image.new("RGB", (w, h))
    px = img.load()
    for y in range(h):
        t = y / max(1, h - 1)
        t = t * t * (3 - 2 * t) * 0.5 + t * 0.5
        base = _lerp(GRAD_TOP, GRAD_BOT, t)
        for x in range(w):
            px[x, y] = tuple(int(v) for v in base)

    glow = Image.new("RGB", (w, h), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    r = w * 0.62
    gd.ellipse([w / 2 - r, h * 1.02 - r, w / 2 + r, h * 1.02 + r], fill=(70, 44, 130))
    glow = glow.filter(ImageFilter.GaussianBlur(w * 0.22))
    img = Image.blend(img, Image.blend(img, glow, 0.55), 0.75)

    # 圆角遮罩（Windows 图标习惯用圆角方形）
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1],
                                           radius=int(size * 0.22), fill=255)
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out


def _jelly(size):
    """一只发光水母，尺寸约 size 像素。"""
    w = int(size)
    h = int(size * 1.34)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cx = w * 0.5
    rx, ry = w * 0.40, w * 0.27
    cy = w * 0.40
    tint = (126, 216, 255)

    for i in range(7):
        x0 = cx + (i / 6.0 - 0.5) * rx * 0.9
        pts = []
        for s in range(16):
            u = s / 15.0
            pts.append((x0 + math.sin(u * 3.2 + i * 0.9) * w * 0.055 * (0.3 + u),
                        cy + ry * 0.5 + u * (h - cy - ry * 0.5) * 0.94))
        d.line(pts, fill=tint + (170,), width=max(1, int(w * 0.028)), joint="curve")

    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=tint + (215,))
    d.ellipse([cx - rx * 0.5, cy - ry * 0.68, cx + rx * 0.42, cy - ry * 0.06],
              fill=(235, 252, 255, 175))
    return img.filter(ImageFilter.GaussianBlur(max(0.6, w * 0.012)))


def build_master(size=256):
    base = _background(size).convert("RGBA")
    spr = _jelly(size * 0.56)
    pos = (int(size * 0.5 - spr.width / 2), int(size * 0.30))
    halo = spr.filter(ImageFilter.GaussianBlur(size * 0.05))
    base.alpha_composite(halo, pos)
    base.alpha_composite(spr, pos)
    return base


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shortcut", action="store_true",
                    help="同时在桌面创建带此图标的快捷方式")
    ap.add_argument("--name", default="Cora 语音助手",
                    help="桌面快捷方式的名字（不含 .lnk）")
    args = ap.parse_args()

    master = build_master(256)
    master.save(ICON_PATH, sizes=[(16, 16), (24, 24), (32, 32), (48, 48),
                                  (64, 64), (128, 128), (256, 256)])
    print("图标已生成：%s  (%.1f KB)" % (ICON_PATH, os.path.getsize(ICON_PATH) / 1024))
    master.save(os.path.join(HERE, "cora_icon_preview.png"))
    print("预览图：%s" % os.path.join(HERE, "cora_icon_preview.png"))

    if not args.shortcut:
        return

    # 目标用 pythonw.exe（无控制台窗口），配上工作目录，双击即用
    py = sys.executable
    if py.lower().endswith("pythonw.exe"):
        target = py
    else:
        cand = os.path.join(os.path.dirname(py), "pythonw.exe")
        target = cand if os.path.exists(cand) else py

    desktop = None
    for cand in (os.path.join(os.path.expanduser("~"), "Desktop"),):
        if os.path.isdir(cand):
            desktop = cand
            break
    if desktop is None:
        print("找不到桌面目录，跳过快捷方式")
        return

    lnk = os.path.join(desktop, args.name + ".lnk")
    # 用 -EncodedCommand 传脚本：避免中文路径在编码转换里被搞坏
    ps = (
        "$w = New-Object -ComObject WScript.Shell; "
        "$s = $w.CreateShortcut('%s'); "
        "$s.TargetPath = '%s'; "
        "$s.Arguments = '\"%s\"'; "
        "$s.WorkingDirectory = '%s'; "
        "$s.IconLocation = '%s,0'; "
        "$s.Description = 'Cora 桌面语音助手'; "
        "$s.Save(); "
        "if (Test-Path '%s') { 'OK' } else { 'FAIL' }"
    ) % (lnk, target, APP, HERE, ICON_PATH, lnk)

    enc = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive",
                        "-EncodedCommand", enc],
                       capture_output=True, timeout=90)
    out = (r.stdout or b"").decode("utf-8", "replace").strip()
    err = (r.stderr or b"").decode("utf-8", "replace").strip()
    print("powershell 退出码:", r.returncode, "| 输出:", out or "(空)")
    if err:
        print("stderr:", err[:400])

    if os.path.exists(lnk):
        print("快捷方式已创建：%s  (%.0f 字节)" % (lnk, os.path.getsize(lnk)))
    else:
        print("快捷方式创建失败")


if __name__ == "__main__":
    main()
