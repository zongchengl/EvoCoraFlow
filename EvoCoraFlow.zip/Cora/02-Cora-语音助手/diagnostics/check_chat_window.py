"""GUI regression check. Uses no network, audio stream, camera, or serial port."""
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import tkinter as tk
from PIL import ImageGrab
import main
from va.chat_background import ArtworkCanvas

errors = []
root = tk.Tk()
root.report_callback_exception = lambda *args: errors.append(str(args[1]))

def pump(seconds=.3):
    until = time.monotonic() + seconds
    while time.monotonic() < until:
        root.update()
        time.sleep(.015)

try:
    with patch.object(main.VoiceAssistant, '_boot'), \
         patch.object(main, 'CoraBridge') as bridge, \
         patch.object(main.Recorder, 'start') as record:
        app = main.VoiceAssistant(root)
        app.set_state('idle', '仅聊天 · 摄像头 / 电机未连接')
        pump(.5)
        assert app.canvas._photo is not None, 'Background did not load'
        assert str(app.cora_btn['state']) == 'disabled'
        app.cora_btn.invoke()
        app.toggle_cora()
        app._start_cora()
        bridge.assert_not_called()
        assert app.bridge is None
        bg = app.canvas._bg_id
        for i in range(24):
            app._bubble(f'滚动检查 {i+1}：聊天消息应当保持在左侧，不遮挡右侧人物。',
                        'user' if i % 2 else 'ai')
        pump()
        assert app.canvas.yview()[0] > 0, 'Long chat did not scroll'
        for move in (lambda: app.canvas.yview_moveto(0),
                     lambda: app.canvas.yview_scroll(2, 'units'),
                     lambda: app.canvas.yview('moveto', .5),
                     lambda: app.canvas.yview_moveto(1)):
            move()
            pump(.05)
            assert abs(app.canvas.coords(bg)[1] - app.canvas.canvasy(0)) < 1
            assert app.canvas.find_all()[0] == bg, 'Background covered the messages'
        for geometry in ('820x620', '1120x780'):
            root.geometry(geometry)
            pump(.4)
            assert app.canvas._size == (app.canvas.winfo_width(), app.canvas.winfo_height())
            for i in range(len(app.bubbles)):
                box = app.canvas.bbox(f'b{i}')
                assert box[2] <= app.canvas.winfo_width() * .56, 'Message crossed portrait column'
            assert len(app.canvas.find_withtag('bg')) == 1
        photo = app.canvas._photo
        app.clear_chat()
        pump(.2)
        assert app.canvas._bg_id == bg
        assert app.canvas._photo is photo, 'Clear chat needlessly rendered the background'
        # Missing background remains a working plain-color canvas.
        missing = ArtworkCanvas(root, ROOT / 'assets' / 'missing-for-test.png', bg='#090f25')
        assert missing._source is None
        missing.repaint()
        missing.destroy()
        record.assert_not_called()
        assert not errors, errors
        root.lift()
        root.attributes('-topmost', True)
        pump(.4)
        # Capture only the native window; avoid logical/physical DPI coordinate mismatch.
        ImageGrab.grab(window=int(root.frame(), 0)).save(
            ROOT / 'diagnostics' / 'cora-chat-preview.png')
        root.attributes('-topmost', False)
        print('PASS: background load, resize, scroll pinning, message layout, clear, fallback, device guards')
        print('PASS: no camera/motor bridge or audio recording started; no Tk callback errors')
finally:
    root.destroy()
