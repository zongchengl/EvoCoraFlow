from pathlib import Path
import ast
import os

root = Path(__file__).resolve().parent.parent
path = root / "main.py"
s = path.read_text(encoding="utf-8-sig")

def replace(old, new):
    global s
    assert s.count(old) == 1, f"Expected exactly one anchor: {old[:75]!r}"
    s = s.replace(old, new, 1)

replace('from va.cora_bridge import CoraBridge                     # noqa: E402',
        'from va.cora_bridge import CoraBridge                     # noqa: E402\nfrom va.chat_background import ArtworkCanvas                 # noqa: E402')
replace('CONFIG_PATH = os.path.join(APP_DIR, "config.json")', '''CONFIG_PATH = os.path.join(APP_DIR, "config.json")
CHAT_ONLY_PROMPT = (
    "你是 Cora，一位友好、简洁的中文语音助手。当前运行在仅聊天模式，"
    "没有连接摄像头、步进电机或激光器，也无法执行设备指令。"
    "不能声称已经观察画面、移动液滴或操控硬件。可以讨论实验方案，但要明确未执行。"
    "如果不确定，直接说明。"
)
''')
replace('def __init__(self, root: tk.Tk):', 'def __init__(self, root: tk.Tk, *, chat_only=True):')
replace('        self.root = root\n        self.cfg = Config(CONFIG_PATH)',
        '        self.root = root\n        self.chat_only = bool(chat_only)\n        self.cfg = Config(CONFIG_PATH)')
replace('            system_prompt=self.cfg.get("llm.system_prompt"),',
        '            system_prompt=CHAT_ONLY_PROMPT if self.chat_only else self.cfg.get("llm.system_prompt"),')
replace('        r.title("Cora · 桌面语音问答")', '        r.title("Cora · 星空聊天" + (" · 仅聊天模式" if self.chat_only else ""))')
replace('''        size = self.cfg.get("ui.window_size", "560x760")
        r.geometry(size)
        r.minsize(460, 620)''', '''        # Wide composition keeps the portrait on the right, outside the chat column.
        screen_w, screen_h = r.winfo_screenwidth(), r.winfo_screenheight()
        width, height = min(1120, screen_w - 80), min(780, screen_h - 100)
        r.geometry(f"{width}x{height}+{max(0, (screen_w-width)//2)}+{max(0, (screen_h-height)//2-20)}")
        r.minsize(min(820, width), min(580, height))''')
replace('tk.Label(top, text="语音问答",', 'tk.Label(top, text="星空语音助手",')
replace('        self.cora_btn.pack(side="right", padx=(0, 10), pady=13)', '''        self.cora_btn.pack(side="right", padx=(0, 10), pady=13)
        if self.chat_only:
            self.cora_btn.configure(text="仅聊天", state="disabled", bg=CARD,
                                    disabledforeground=ACCENT_2, cursor="arrow")''')
# Replace the whole incomplete block; never glue snippets to an unknown newline.
start = s.index('        # 渐变底 + 三团柔光：')
end = s.index('        self.scroll = ttk.Scrollbar', start)
s = s[:start] + '''        self.canvas = ArtworkCanvas(
            wrap, image_path=os.path.join(APP_DIR, "assets", "gpt-image-01.png"), bg="#090f25")
''' + s[end:]
replace('        self.canvas.configure(yscrollcommand=self.scroll.set)',
        '        self.canvas.set_scrollbar(self.scroll.set)')
# Replace the oversized footer control layout while preserving existing handlers.
start = s.index('        # 麦克风按钮\n')
end = s.index('        self._update_model_chip()\n', start)
s = s[:start] + '''        # Compact composer leaves more room for the background and messages.
        composer = tk.Frame(bottom, bg=FOOTER_BG)
        composer.pack(fill="x", padx=16, pady=(4, 10))
        self.btn = tk.Canvas(composer, width=110, height=100, bg=FOOTER_BG,
                             highlightthickness=0, cursor="hand2")
        self.btn.pack(side="left", padx=(0, 12))
        self._draw_mic(0.0, False)
        self.btn.bind("<ButtonPress-1>", lambda e: self.start_recording())
        self.btn.bind("<ButtonRelease-1>", lambda e: self.stop_recording())
        input_panel = tk.Frame(composer, bg=FOOTER_BG)
        input_panel.pack(side="left", fill="both", expand=True, pady=(12, 0))
        self.hint = tk.Label(input_panel, text="按住空格或圆钮说话 · 输入文字后按回车发送",
                             bg=FOOTER_BG, fg=MUTED, font=F_SMALL)
        self.hint.pack(anchor="w", pady=(0, 8))
        row = tk.Frame(input_panel, bg=FOOTER_BG)
        row.pack(fill="x")
        self.entry = tk.Entry(row, bg=CARD, fg=TEXT, insertbackground=TEXT, font=F_UI,
                              relief="flat", bd=0, highlightthickness=1,
                              highlightbackground=BORDER, highlightcolor=ACCENT)
        self.entry.pack(side="left", fill="x", expand=True, ipady=9)
        self.entry.bind("<Return>", lambda e: self.send_text())
        self.entry.bind("<FocusIn>", lambda e: self._set_hint_focus(True))
        self.entry.bind("<FocusOut>", lambda e: self._set_hint_focus(False))
        self._mk_btn(row, "发送", self.send_text, width=6).pack(side="left", padx=(8, 0))

''' + s[end:]
replace('        cx, cy = 80, 58\n        base_r = 34', '        cx, cy = 55, 50\n        base_r = 27')
replace('        area_w = c.winfo_width()\n        if area_w < 50:\n            area_w = 520', '''        full_width = max(c.winfo_width(), 460)
        # Both speakers stay in the left column, not on top of Cora's face.
        area_w = max(230, int(full_width * 0.54))''')
replace('c.configure(scrollregion=(0, 0, max(area_w, 10), max(y, 10)))',
        'c.configure(scrollregion=(0, 0, full_width, max(y, c.winfo_height())))')
replace('''        背景的重渲由画布自己的 Configure（带防抖）负责，这里只管气泡，
        免得拖窗口时每移动一像素就重渲一次全部水母帧。''', '''        背景由静态画布按尺寸缓存，这里只重新排版左侧的聊天气泡。''')
replace('        if self.cora_on:\n            try:', '        if not self.chat_only and self.cora_on:\n            try:')
replace('''        bridge = self.bridge
        if bridge is None or not bridge.ready():''', '''        if self.chat_only:
            return False
        bridge = self.bridge
        if bridge is None or not bridge.ready():''')
replace('    def toggle_cora(self):\n        if self.cora_on:', '    def toggle_cora(self):\n        if self.chat_only:\n            return\n        if self.cora_on:')
replace('''        """后台线程：拉起 cora.py 并等它的主循环真正跑起来。"""
        try:''', '''        """后台线程：拉起 cora.py 并等它的主循环真正跑起来。"""
        if self.chat_only:
            return
        try:''')
start = s.index('    def _welcome(self):')
end = s.index('    def _update_model_chip(self):', start)
s = s[:start] + '''    def _welcome(self):
        theme = "你好，我是 Cora。\\n\\n星空已就位，想聊些什么？"
        if self.chat_only:
            theme += "\\n\\n当前仅聊天，摄像头和电机未连接。"
        if not self.llm.ready:
            theme += "\\n\\n请先在右上角「设置」填写对话服务的 API Key，再开始问答。"
        self._bubble(theme, "ai")

''' + s[end:]
replace('state = "已连接" if self.llm.ready else "未配置 Key"',
        'state = "已配置" if self.llm.ready else "未配置 Key"')
# All anchors and syntax are validated BEFORE replacing the existing file.
ast.parse(s)
compile(s, str(path), "exec")
temp = path.with_suffix('.py.tmp')
temp.write_text(s, encoding='utf-8')
os.replace(temp, path)
print('main.py syntax verified before atomic replacement')
