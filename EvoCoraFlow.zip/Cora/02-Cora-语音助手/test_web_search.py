import json
import os
import shutil
import uuid
import unittest
from pathlib import Path
from unittest.mock import patch

from va.config import Config
from va.llm import LLM
from va.web_search import BingRssSearch, SearchError, TavilySearch, create_search


TEST_ROOT = Path(__file__).resolve().parent / ".test_runtime"


def local_temp_dir():
    path = TEST_ROOT / uuid.uuid4().hex
    path.mkdir(parents=True, exist_ok=False)
    return path


def remove_local_temp(path):
    shutil.rmtree(path, ignore_errors=True)


class TavilySearchTests(unittest.TestCase):
    def response(self, payload, status=200):
        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self, limit=-1):
                data = json.dumps(payload).encode()
                return data if limit < 0 else data[:limit]

        return FakeResponse()

    def test_search_returns_only_limited_public_fields(self):
        payload = {"results": [
            {"title": f"Title {i}", "url": f"https://example.com/{i}",
             "content": "摘要" * 1000, "score": 0.9, "extra": "discard"}
            for i in range(8)
        ]}
        with patch("va.web_search.urlopen", return_value=self.response(payload)) as open_url:
            results = TavilySearch("secret-key").search("  天气  ")
        self.assertEqual(len(results), 5)
        self.assertEqual(set(results[0]), {"title", "url", "content"})
        self.assertLessEqual(len(results[0]["content"]), 600)
        request = open_url.call_args.args[0]
        self.assertEqual(request.get_header("Authorization"), "Bearer secret-key")
        self.assertEqual(json.loads(request.data)["query"], "天气")

    def test_empty_query_is_rejected_without_network(self):
        with patch("va.web_search.urlopen") as open_url:
            with self.assertRaises(SearchError):
                TavilySearch("secret-key").search("  ")
        open_url.assert_not_called()

    def test_errors_do_not_disclose_api_key(self):
        with patch("va.web_search.urlopen", side_effect=OSError("secret-key leaked")):
            with self.assertRaises(SearchError) as caught:
                TavilySearch("secret-key").search("查询")
        self.assertNotIn("secret-key", str(caught.exception))


class BingRssSearchTests(unittest.TestCase):
    def test_default_search_backend_is_deepseek_compatible_no_key_mode(self):
        self.assertIsInstance(create_search("bing_rss"), BingRssSearch)
        self.assertIsInstance(create_search(""), BingRssSearch)

    def test_rss_results_are_normalized_and_limited(self):
        rss = '''<?xml version="1.0" encoding="UTF-8"?>
        <rss><channel>
          <item><title>实时新闻</title><link>https://example.com/a</link>
          <description>&lt;b&gt;摘要&lt;/b&gt; 内容</description></item>
          <item><title>重复</title><link>https://example.com/a</link><description>x</description></item>
          <item><title>无效链接</title><link>javascript:bad</link><description>x</description></item>
        </channel></rss>'''.encode('utf-8')

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self, limit=-1):
                return rss[:limit] if limit >= 0 else rss

        with patch("va.web_search.urlopen", return_value=FakeResponse()):
            results = BingRssSearch().search("最新消息")
        self.assertEqual(results, [{
            "title": "实时新闻",
            "url": "https://example.com/a",
            "content": "摘要 内容",
        }])

class LLMWebContextTests(unittest.TestCase):
    def test_web_context_is_used_for_request_but_not_saved_to_history(self):
        llm = LLM("https://example.com/v1", "key", "model")
        captured = {}

        class Chunk:
            choices = [type("Choice", (), {"delta": type("Delta", (), {"content": "答案"})()})()]

        class Completions:
            def create(self, **kwargs):
                captured.update(kwargs)
                return [Chunk()]

        client = type("Client", (), {"chat": type("Chat", (), {"completions": Completions()})()})()
        with patch.object(llm, "_client", return_value=client):
            answer = "".join(llm.ask_stream("现在发生什么？", web_context="网页临时上下文"))
        self.assertEqual(answer, "答案")
        self.assertIn("网页临时上下文", captured["messages"][-1]["content"])
        self.assertEqual(llm.history, [
            {"role": "user", "content": "现在发生什么？"},
            {"role": "assistant", "content": "答案"},
        ])


class WebSearchConfigTests(unittest.TestCase):
    def test_search_disabled_by_default_and_env_key_is_not_persisted(self):
        temp = local_temp_dir()
        try:
            path = temp / "config.json"
            with patch.dict(os.environ, {"TAVILY_API_KEY": "env-search-secret"}):
                cfg = Config(str(path))
                self.assertFalse(cfg.get("web_search.enabled"))
                self.assertEqual(cfg.get("web_search.api_key"), "env-search-secret")
                cfg.save()
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(saved["web_search"]["api_key"], "")
        finally:
            remove_local_temp(temp)

    def test_key_entered_in_settings_is_runtime_only(self):
        temp = local_temp_dir()
        try:
            with patch.dict(os.environ, {}, clear=True):
                path = temp / "config.json"
                cfg = Config(str(path))
                cfg.set("web_search.api_key", "ui-entered-secret")
                cfg.set("web_search.enabled", True)
                cfg.save()
                persisted_text = path.read_text(encoding="utf-8")
                saved = json.loads(persisted_text)
                self.assertEqual(cfg.get("web_search.api_key"), "ui-entered-secret")
            self.assertTrue(saved["web_search"]["enabled"])
            self.assertEqual(saved["web_search"]["api_key"], "")
            self.assertNotIn("ui-entered-secret", persisted_text)
        finally:
            remove_local_temp(temp)

    def test_legacy_config_key_is_ignored_on_restart(self):
        temp = local_temp_dir()
        try:
            with patch.dict(os.environ, {}, clear=True):
                path = temp / "config.json"
                path.write_text(json.dumps({"web_search": {
                    "enabled": True, "api_key": "legacy-config-secret"
                }}), encoding="utf-8")
                cfg = Config(str(path))
            self.assertTrue(cfg.get("web_search.enabled"))
            self.assertEqual(cfg.get("web_search.api_key"), "")
        finally:
            remove_local_temp(temp)


if __name__ == "__main__":
    unittest.main()


