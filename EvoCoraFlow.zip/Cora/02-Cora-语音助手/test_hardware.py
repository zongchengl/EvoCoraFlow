"""Offline safety-first tests for Cora hardware interfaces."""
import os
from pathlib import Path
import unittest

from va.hardware import (
    CameraController,
    HardwareSafetyGate,
    MotorController,
    SafetyError,
    VisionModelController,
    label_droplets,
)


class HardwareSafetyTests(unittest.TestCase):
    def test_devices_start_disconnected_and_motor_is_locked(self):
        gate = HardwareSafetyGate()
        camera = CameraController(simulated=True)
        motor = MotorController(simulated=True, safety_gate=gate)
        self.assertFalse(camera.connected)
        self.assertFalse(motor.connected)
        with self.assertRaises(SafetyError):
            motor.jog("right")

    def test_simulated_camera_connects_and_returns_a_frame(self):
        camera = CameraController(simulated=True)
        camera.connect(2)
        self.assertTrue(camera.connected)
        frame = camera.read()
        self.assertTrue(frame["simulated"])
        self.assertEqual(frame["device_index"], 2)
        camera.disconnect()
        self.assertFalse(camera.connected)

    def test_stop_is_available_after_connect_even_when_locked(self):
        motor = MotorController(simulated=True)
        motor.connect("SIM")
        self.assertEqual(motor.jog("stop")["action"], "stop")

    def test_unlock_requires_explicit_phrase_and_whitelisted_motion(self):
        gate = HardwareSafetyGate()
        motor = MotorController(simulated=True, safety_gate=gate)
        motor.connect("SIM")
        with self.assertRaises(SafetyError):
            motor.jog("right")
        self.assertFalse(gate.unlock("解锁"))
        self.assertTrue(gate.unlock("确认解锁硬件"))
        result = motor.jog("right", steps=20, confirmed=True)
        self.assertEqual(result["action"], "right")
        self.assertEqual(result["steps"], 20)
        with self.assertRaises(SafetyError):
            motor.jog("任意系统命令", confirmed=True)

    def test_emergency_stop_overrides_unlock(self):
        gate = HardwareSafetyGate()
        motor = MotorController(simulated=True, safety_gate=gate)
        motor.connect("SIM")
        gate.unlock("确认解锁硬件")
        motor.emergency_stop()
        with self.assertRaises(SafetyError):
            motor.jog("left", confirmed=True)
        gate.reset_emergency()
        self.assertTrue(gate.unlock("确认解锁硬件"))
        self.assertEqual(motor.jog("stop", confirmed=True)["action"], "stop")


class VisionAndLabelTests(unittest.TestCase):
    def test_droplets_are_numbered_in_reading_order_by_class(self):
        droplets = [
            {"x": 80, "y": 30, "class_id": 1},
            {"x": 20, "y": 10, "class_id": 0},
            {"x": 60, "y": 10, "class_id": 0},
            {"x": 10, "y": 90, "class_id": 1},
        ]
        labeled = label_droplets(droplets)
        self.assertEqual([item["label"] for item in labeled], ["A1", "A2", "B1", "B2"])
        self.assertEqual([(item["x"], item["y"]) for item in labeled], [(20, 10), (60, 10), (80, 30), (10, 90)])

    def test_missing_engine_path_has_clear_error_and_existing_path_loads(self):
        model = VisionModelController(simulated=True)
        with self.assertRaises(FileNotFoundError):
            model.load("missing.engine")
        path = Path(__file__).resolve().parent / "assets" / "gpt-image-01.png"
        self.assertTrue(model.load(str(path)))
        self.assertTrue(model.loaded)


if __name__ == "__main__":
    unittest.main()

