# Cora 语音交互链

本模块提供本地 Whisper 识别、兼容对话接口、Edge TTS 播报和主链联动。聊天内容由配置的对话服务处理，语音合成也需要网络；本地语音识别不要求把录音上传到对话服务。

## 安装与启动

使用 Python 3.10–3.12，安装 `requirements.txt`。Whisper 还需要 FFmpeg，桌面界面需要 Tk，录音需要可用麦克风。

```text
python -m pip install -r requirements.txt
python main.py
```

默认仅聊天，不建立主链桥接。API 密钥通过 `DEEPSEEK_API_KEY` 环境变量注入，也可在设置中临时输入；密钥不保存到配置文件。联网搜索默认关闭。

## 语音与文字控制

```text
python main.py --enable-control
```

也可双击 `启动主链联动.bat`。此模式显示“联动 Cora”按钮，点击后才启动液滴程序。默认带 `--no-motor`，会访问配置的相机和模型。真实电机联动需在 `config.json` 中显式设置 `hardware.enabled=true`，并通过 `hardware.cora_args` 配置现场参数，例如：

```json
{"hardware": {"enabled": false, "cora_args": ["--source", "usb:0", "--imgsz", "1280"]}}
```

`cora_args` 按主链命令行规则填写 ROI、模型和串口；主链的模型路径与语音界面独立设备面板的模型路径分别配置。`hardware.simulated` 控制独立设备面板的模拟适配器，不会把桥接进程转换为仿真。工业相机被其他程序占用时，桥接返回提示，请手动释放采集，不会强行关闭客户端。

示例指令：“有哪些液滴”“把 A1 移到右侧”“把全部液滴自动分批移到右侧”“停止”。桥接把文本交给主链的受限指令解析器；大模型生成的任意文字不会作为系统命令或电机脚本执行。主链返回的是受理、规划或当前执行状态，最终到达以主链画面为准。

## 离线验证

```text
python -m unittest discover -v
```

测试不连接相机、串口或网络，聊天路由测试使用无窗口对象，可在缺少 Tk/音频运行库时验证控制隔离。真实界面、录音和播报仍需完整依赖。独立设备面板有自己的连接、解锁和急停门，主链桥接受主链执行状态与 `hardware.enabled` 开关约束。
