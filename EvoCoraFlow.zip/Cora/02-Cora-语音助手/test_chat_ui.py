"""Offline regression tests; no camera, serial port, network or Tk window."""
import ast
import importlib
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import Mock, patch
from PIL import Image

ROOT = Path(__file__).resolve().parent

class BackgroundTests(unittest.TestCase):
    def test_main_parses(self):
        ast.parse((ROOT / "main.py").read_text(encoding="utf-8-sig"))

    def render(self, source, size):
        from va.chat_background import render_background
        return render_background(source, *size)

    def test_background_fits_sizes_without_mutating_source(self):
        source = Image.new("RGB", (160, 90), "white")
        for size in ((1100, 570), (820, 400), (460, 600), (1, 1)):
            result = self.render(source, size)
            self.assertEqual(result.size, size)
        self.assertEqual(source.getpixel((0, 0)), (255, 255, 255))
        self.assertEqual(source.size, (160, 90))

    def test_only_chat_side_is_dimmed(self):
        result = self.render(Image.new("RGB", (160, 90), "white"), (160, 90))
        self.assertLess(result.getpixel((0, 45))[0], 240)
        self.assertEqual(result.getpixel((150, 45)), (255, 255, 255))

    def test_right_edge_of_portrait_survives_narrow_crop(self):
        source = Image.new("RGB", (160, 90), "black")
        source.paste((255, 0, 0), (140, 0, 160, 90))
        result = self.render(source, (80, 90))
        self.assertEqual(result.getpixel((75, 45)), (255, 0, 0))

    def test_invalid_dimensions_rejected(self):
        for size in ((0, 30), (30, -1)):
            with self.assertRaises(ValueError):
                self.render(Image.new("RGB", (10, 10)), size)

    def test_background_asset_decodes(self):
        with Image.open(ROOT / "assets" / "gpt-image-01.png") as image:
            image.load()
            self.assertGreater(image.width, image.height)

class ChatOnlyTests(unittest.TestCase):
    def make_app(self):
        module = importlib.import_module("main")
        app = module.VoiceAssistant.__new__(module.VoiceAssistant)
        app.chat_only = True
        app.bridge = None
        app.cora_on = False
        return module, app

    def test_link_button_and_direct_start_never_create_bridge(self):
        module, app = self.make_app()
        with patch.object(module, "CoraBridge") as bridge:
            app.toggle_cora()
            app._start_cora()
            bridge.assert_not_called()
        self.assertIsNone(app.bridge)

    def test_chat_only_cannot_forward_even_if_stale_cora_flag_is_set(self):
        _, app = self.make_app()
        app.cora_on = True
        app._ask_cora = Mock(return_value=True)
        app._answer = Mock()
        app._route("把 A1 移到右侧")
        app._ask_cora.assert_not_called()
        app._answer.assert_called_once_with("把 A1 移到右侧", web_enabled=False)

    def test_direct_forward_is_blocked_in_chat_only(self):
        _, app = self.make_app()
        app.bridge = Mock()
        self.assertFalse(app._ask_cora("移动 A1"))
        app.bridge.send.assert_not_called()

if __name__ == "__main__":
    unittest.main()

