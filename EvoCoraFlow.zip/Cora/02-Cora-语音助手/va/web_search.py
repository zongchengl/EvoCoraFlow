"""联网搜索适配器。

Cora 的联网模式使用 DeepSeek 负责理解和回答，搜索适配器负责取得网页片段：
- 默认使用 Bing RSS，免额外 API Key；
- 仍保留 Tavily 适配器，便于需要时切换。

注意：DeepSeek Chat API 本身是对话模型，不会因为拥有 API Key 就自动浏览网页。
因此这里把“搜索”和“DeepSeek 总结”拆开，避免伪造实时信息。
"""

import html
import json
import os
import re
import xml.etree.ElementTree as ET
from urllib.error import HTTPError, URLError
from urllib.parse import quote_plus
from urllib.request import Request, urlopen


class SearchError(Exception):
    """安全的用户可见搜索错误；不包含请求头或密钥。"""


class _BaseSearch:
    TIMEOUT = 12
    MAX_RESPONSE_BYTES = 1_000_000

    @staticmethod
    def _query(query):
        query = str(query or "").strip()[:300]
        if not query:
            raise SearchError("搜索词为空，请补充问题后重试。")
        return query

    @staticmethod
    def _clean_text(value, limit=600):
        text = html.unescape(str(value or ""))
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:limit]


class BingRssSearch(_BaseSearch):
    """免 Key 的 Bing RSS 搜索，供 DeepSeek 联网模式使用。"""

    ENDPOINT = "https://www.bing.com/search?format=rss&setlang=zh-CN&q="

    def search(self, query):
        query = self._query(query)
        request = Request(
            self.ENDPOINT + quote_plus(query),
            headers={
                "User-Agent": "Cora/1.0 (desktop assistant)",
                "Accept": "application/rss+xml, application/xml;q=0.9, */*;q=0.8",
            },
            method="GET",
        )
        try:
            with urlopen(request, timeout=self.TIMEOUT) as response:
                raw = response.read(self.MAX_RESPONSE_BYTES + 1)
            if len(raw) > self.MAX_RESPONSE_BYTES:
                raise SearchError("搜索结果过大，本轮没有完成实时检索。")
            root = ET.fromstring(raw)
            results = []
            seen = set()
            for item in root.findall(".//item"):
                title = self._clean_text(item.findtext("title"), 200) or "网页"
                url = self._clean_text(item.findtext("link"), 1000)
                content = self._clean_text(item.findtext("description"), 600)
                if not url.startswith(("https://", "http://")) or url in seen:
                    continue
                seen.add(url)
                results.append({"title": title, "url": url, "content": content})
                if len(results) >= 5:
                    break
            if not results:
                raise SearchError("搜索没有返回可用结果；本轮没有完成实时检索。")
            return results
        except SearchError:
            raise
        except (HTTPError, URLError, TimeoutError, OSError, ET.ParseError, ValueError):
            raise SearchError("公网搜索失败或超时；本轮没有完成实时检索。") from None
        except Exception:
            raise SearchError("公网搜索失败；本轮没有完成实时检索。") from None


class TavilySearch(_BaseSearch):
    """Tavily 搜索客户端，保留作可选高级搜索后端。"""

    ENDPOINT = "https://api.tavily.com/search"

    def __init__(self, api_key=None):
        self.api_key = (api_key if api_key is not None else os.getenv("TAVILY_API_KEY", "")).strip()

    def search(self, query):
        query = self._query(query)
        if not self.api_key:
            raise SearchError("未配置 Tavily 搜索密钥。")

        body = json.dumps({
            "query": query, "max_results": 5, "search_depth": "basic",
            "include_answer": False, "include_raw_content": False,
        }).encode("utf-8")
        request = Request(self.ENDPOINT, data=body, headers={
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }, method="POST")
        try:
            with urlopen(request, timeout=8) as response:
                payload = json.loads(response.read(self.MAX_RESPONSE_BYTES + 1))
            if not isinstance(payload, dict) or not isinstance(payload.get("results"), list):
                raise SearchError("搜索服务返回的数据格式不正确。")
            results = []
            for item in payload["results"][:5]:
                if not isinstance(item, dict):
                    continue
                title = str(item.get("title") or "网页").strip()[:200]
                url = str(item.get("url") or "").strip()[:1000]
                content = str(item.get("content") or "").strip()[:600]
                if url.startswith(("https://", "http://")):
                    results.append({"title": title, "url": url, "content": content})
            return results
        except SearchError:
            raise
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, json.JSONDecodeError):
            raise SearchError("搜索服务失败或超时；本轮没有完成实时检索。") from None
        except Exception:
            raise SearchError("搜索服务失败；本轮没有完成实时检索。") from None


def create_search(provider="bing_rss", api_key=""):
    """根据配置创建搜索后端；默认免 Key 的公网搜索。"""
    provider = str(provider or "bing_rss").strip().lower()
    if provider in {"tavily", "tavily_api"}:
        return TavilySearch(api_key)
    return BingRssSearch()


# 兼容旧代码/外部调用：默认即免 Key 的联网搜索。
DeepSeekWebSearch = BingRssSearch