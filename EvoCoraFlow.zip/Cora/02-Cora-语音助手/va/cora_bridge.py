# -*- coding: utf-8 -*-
"""把桌面语音助手接到 Cora：一句话 → 相机识别 → 步进电机执行 → 语音回播。

**为什么用子进程跑 cora.py，而不是把它 import 进来：**
  - 语音助手不必加载 torch / ultralytics / 海康 SDK，启动不被拖累
  - Cora 是成熟的实时循环（取帧 + 推理 + 电机），进程隔离后它崩了
    不会带倒语音助手，语音助手重启也不必重连相机
指令走子进程的 stdin（Cora 本来就带 stdin 读取线程），
结果走 `--reply-log` 写出的 JSON 行 —— 这样不用去猜它 print 了什么。
"""

import json
import os
import subprocess
import sys
import threading
import time

# 通用采集默认值；现场 ROI、曝光和输入源通过 extra_args 覆盖。
DEFAULT_ARGS = [
    "--source", "hik",
    "--exposure-time", "15000",
    "--gain", "0",
    "--imgsz", "1280",
]

# 启动失败时，日志里出现这些字样就值得念给用户听
_ERROR_HINTS = ("0x80000203", "没有找到任何串口", "串口", "模型文件不存在",
                "未安装", "Traceback", "RuntimeError", "FileNotFoundError",
                "Error", "失败")

# 出现这些字样说明主循环已经跑起来了
_READY_HINTS = ("可用指令示例", "[Cora] 输入源")


class CoraBridge:
    """管理 cora.py 子进程，收发指令与回复。线程安全。"""

    def __init__(self, cora_dir, python_exe=None, extra_args=None, log=None, hardware_enabled=False):
        self.cora_dir = cora_dir
        self.python_exe = python_exe or sys.executable
        self.extra_args = [a for a in (extra_args or []) if a is not None]
        self.hardware_enabled = bool(hardware_enabled)
        self.log = log or (lambda msg: None)

        self.reply_path = os.path.join(cora_dir, "_voice_reply.jsonl")
        self.proc = None
        self._reader = None
        self._running = False
        self._offset = 0
        self._ready = False
        self._lines = []            # 最近的日志行（排错用）
        self._problems = []         # 启动期捞到的可疑报错
        self._lock = threading.Lock()

    # ------------------------------------------------------------ 状态
    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def ready(self):
        return self._ready and self.alive()

    def log_tail(self, n=8):
        with self._lock:
            return list(self._lines[-n:])

    def problems(self):
        with self._lock:
            return list(self._problems)

    # ------------------------------------------------------------ 相机占用
    @staticmethod
    def _mvs_running():
        try:
            r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq MVS.exe", "/FO", "CSV", "/NH"],
                               capture_output=True, timeout=15)
            return b"MVS.exe" in r.stdout
        except Exception:
            return False

    def free_camera(self):
        """报告相机占用，不终止其他应用。返回是否检测到占用。"""
        return self._mvs_running()

    # ------------------------------------------------------------ 生命周期
    def build_command(self):
        cmd = [self.python_exe, "-u", "cora.py", "--reply-log", self.reply_path]
        cmd += list(DEFAULT_ARGS)
        # 安全默认：语音助手联动只启动视觉识别演练，不向电机发送运动指令。
        # 只有用户在配置中明确开启 hardware.enabled 才允许连接电机。
        if not self.hardware_enabled and "--no-motor" not in self.extra_args:
            cmd.append("--no-motor")
        cmd += self.extra_args
        return cmd

    def start(self):
        """启动 Cora。返回 (是否成功, 提示文本)。"""
        if self.alive():
            return True, "Cora 已经在运行"

        if not os.path.isdir(self.cora_dir):
            return False, f"找不到 Cora 目录：{self.cora_dir}"
        if not os.path.exists(os.path.join(self.cora_dir, "cora.py")):
            return False, f"Cora 目录里没有 cora.py：{self.cora_dir}"

        cmd = self.build_command()
        source = "hik"
        for i, arg in enumerate(cmd[:-1]):
            if arg == "--source":
                source = cmd[i + 1]
        if source == "hik" and self.free_camera():
            return False, "相机客户端可能占用设备，请手动关闭采集后重试"

        # 清掉上一轮的回复，避免读到旧内容
        try:
            open(self.reply_path, "w", encoding="utf-8").close()
        except Exception:
            pass
        self._offset = 0
        self._ready = False
        with self._lock:
            self._lines = []
            self._problems = []

        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"

        try:
            self.proc = subprocess.Popen(
                cmd,
                cwd=self.cora_dir,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as exc:
            self.proc = None
            return False, f"Cora 启动失败：{exc}"

        self._running = True
        self._reader = threading.Thread(target=self._pump, daemon=True)
        self._reader.start()
        return True, ("已启动 Cora（相机 + 模型 + 电机）" if self.hardware_enabled
                      else "已启动 Cora（相机 + 模型，无电机模式）")

    def stop(self, timeout=6.0):
        self._running = False
        proc = self.proc
        if proc is None:
            return
        try:
            if proc.stdin and proc.poll() is None:
                proc.stdin.write("__quit__\n")
                proc.stdin.flush()
        except Exception:
            pass
        deadline = time.time() + timeout
        while time.time() < deadline and proc.poll() is None:
            time.sleep(0.15)
        if proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
            time.sleep(0.5)
            if proc.poll() is None:
                try:
                    proc.kill()
                except Exception:
                    pass
        self.proc = None

    # ------------------------------------------------------------ 日志泵
    def _pump(self):
        proc = self.proc
        if proc is None or proc.stdout is None:
            return
        for raw in proc.stdout:
            line = raw.rstrip("\n")
            if not line:
                continue
            with self._lock:
                self._lines.append(line)
                if len(self._lines) > 400:
                    del self._lines[:200]
            if not self._ready and any(h in line for h in _READY_HINTS):
                self._ready = True
            if not self._ready and any(h in line for h in _ERROR_HINTS):
                with self._lock:
                    if line not in self._problems:
                        self._problems.append(line)
        self._running = False

    # ------------------------------------------------------------ 指令
    def send(self, text):
        """把一条中文指令送进 Cora。返回是否送出。"""
        text = (text or "").strip()
        if not text:
            return False
        proc = self.proc
        if proc is None or proc.poll() is not None or proc.stdin is None:
            return False
        try:
            proc.stdin.write(text + "\n")
            proc.stdin.flush()
            return True
        except Exception:
            return False

    def poll_replies(self):
        """取回自上次调用以来新增的回复，返回 [{action, cmd, reply}, ...]。"""
        out = []
        try:
            if not os.path.exists(self.reply_path):
                return out
            with open(self.reply_path, "r", encoding="utf-8") as fh:
                fh.seek(self._offset)
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        out.append(json.loads(line))
                    except Exception:
                        continue
                self._offset = fh.tell()
        except Exception:
            pass
        return out
