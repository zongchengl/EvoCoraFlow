"""语音识别：本地 OpenAI Whisper（离线、免费、隐私）。

关键点：直接把 numpy 波形喂给 model.transcribe()，
绕开对 ffmpeg 的依赖，本机无需安装任何外部解码器。
"""

import threading

import numpy as np

_MODEL_DOWNLOAD_HINT = (
    "首次使用需要下载语音模型（base 约 150MB），请保持联网，"
    "下载完成后即可完全离线使用。"
)


class ASR:
    def __init__(self, model_name="base", language="zh", device="cpu",
                 initial_prompt="以下是普通话内容。", hotwords=""):
        self.model_name = model_name
        self.language = language
        self.device = device
        self.initial_prompt = initial_prompt or ""
        self.hotwords = hotwords or ""
        self._model = None
        self._lock = threading.Lock()
        self.loaded = False

    # ------------------------------------------------------------ 模型加载
    def preload(self):
        """主动加载模型（可在启动时后台预热）。"""
        return self._ensure_model()

    def _ensure_model(self):
        if self._model is not None:
            return self._model
        with self._lock:
            if self._model is not None:
                return self._model
            import whisper

            self._model = whisper.load_model(self.model_name, device=self.device)
            self.loaded = True
        return self._model

    # ------------------------------------------------------------ 转写
    def _prompt(self) -> str:
        prompt = self.initial_prompt
        if self.hotwords:
            words = [w.strip() for w in self.hotwords.replace("，", ",").split(",") if w.strip()]
            if words:
                prompt = (prompt + " 可能出现的专有名词：" + "、".join(words) + "。").strip()
        return prompt

    def transcribe(self, audio: np.ndarray) -> str:
        """输入一维 float32 波形（16kHz），输出识别文本。"""
        if audio is None or len(audio) == 0:
            return ""
        if audio.dtype != np.float32:
            audio = audio.astype("float32")
        model = self._ensure_model()
        result = model.transcribe(
            audio,
            language=self.language,
            task="transcribe",
            fp16=False,          # CPU 上必须关闭，否则告警甚至报错
            condition_on_previous_text=False,
            initial_prompt=self._prompt(),
            no_speech_threshold=0.6,
        )
        text = (result.get("text") or "").strip()
        return _clean(text)


def _clean(text: str) -> str:
    """清理 Whisper 常见的口水话与格式噪音。"""
    if not text:
        return ""
    noise = {
        "谢谢大家", "谢谢观看", "字幕由", "请不吝点赞", "订阅", "转发",
        "明镜与点点栏目", "MING PAO CANADA", "中文字幕",
    }
    text = text.strip()
    for n in noise:
        if text == n or text.strip("。.!！ ") == n:
            return ""
    # 去掉行首的标点噪音
    while text and text[0] in "，。、,.!！?？…— ":
        text = text[1:]
    return text.strip()


def is_model_cached(model_name="base") -> bool:
    """检查模型是否已下载到本地缓存。"""
    import os

    cache = os.path.join(os.path.expanduser("~"), ".cache", "whisper")
    expected = f"{model_name}.pt"
    return os.path.exists(os.path.join(cache, expected))


# 供界面展示的提示语
MODEL_HINT = _MODEL_DOWNLOAD_HINT
