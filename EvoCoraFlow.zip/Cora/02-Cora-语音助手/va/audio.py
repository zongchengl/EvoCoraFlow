"""麦克风录音：基于 sounddevice 的流式采集，返回 float32 单声道波形。

设计要点：
- 直接产出 numpy 数组，交给 Whisper 时无需落盘、无需 ffmpeg。
- 实时暴露音量 level，用于界面波形/状态反馈。
- 可选的静音自动停止（VAD-lite），由调用方轮询 check_silence() 实现。
"""

import threading

import numpy as np
import sounddevice as sd


class Recorder:
    def __init__(self, sample_rate=16000, channels=1, block_ms=30,
                 silence_threshold=0.012, device=None):
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.block_size = max(1, int(self.sample_rate * block_ms / 1000))
        self.silence_threshold = float(silence_threshold)
        self.device = device          # None = 用系统默认输入设备

        self._frames = []
        self._stream = None
        self._lock = threading.Lock()
        self._level = 0.0
        self._peak = 0.0
        self._recording = False
        self._last_voice_ts = 0.0
        self._started_ts = 0.0
        self._saw_voice = False

    # ------------------------------------------------------------ 生命周期
    def start(self):
        """打开输入流并开始采集。重复调用是安全的。"""
        with self._lock:
            if self._recording:
                return
            self._frames = []
            self._level = 0.0
            self._peak = 0.0
            self._saw_voice = False
            import time

            now = time.time()
            self._started_ts = now
            self._last_voice_ts = now
            self._stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                dtype="float32",
                blocksize=self.block_size,
                device=self.device,
                callback=self._callback,
            )
            self._stream.start()
            self._recording = True

    def stop(self):
        """停止采集并返回整段波形（一维 float32）。"""
        with self._lock:
            self._recording = False
            stream, self._stream = self._stream, None
            frames = self._frames
            self._frames = []
        if stream is not None:
            try:
                stream.stop()
                stream.close()
            except Exception:
                pass
        if not frames:
            return np.zeros(0, dtype="float32")
        audio = np.concatenate(frames, axis=0)
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        return audio.astype("float32")

    # ------------------------------------------------------------ 采集回调
    def _callback(self, indata, frames, time_info, status):
        chunk = indata.copy()
        rms = float(np.sqrt(np.mean(np.square(chunk))))
        with self._lock:
            if not self._recording:
                return
            self._frames.append(chunk)
            self._level = rms
            self._peak = max(self._peak, rms)
            if rms >= self._voice_floor():
                import time

                self._last_voice_ts = time.time()
                self._saw_voice = True

    # ------------------------------------------------------------ 状态查询
    @property
    def recording(self) -> bool:
        return self._recording

    @property
    def level(self) -> float:
        """0~1 之间的平滑音量，用于界面反馈。"""
        return min(1.0, self._level * 12.0)

    def duration(self) -> float:
        with self._lock:
            total = sum(f.shape[0] for f in self._frames)
        return total / self.sample_rate

    def voice_floor(self) -> float:
        return self._voice_floor()

    def _voice_floor(self) -> float:
        # 相对阈值：以当前峰值的一定比例判断"还在说话"
        return max(self.silence_threshold, self._peak * 0.25)

    def check_auto_stop(self, silence_seconds=1.3, max_seconds=30.0, min_seconds=0.35):
        """轮询式静音检测。

        返回 (should_stop, reason)。reason 取值：
          "silence"  静音超时
          "timeout"  达到最大录音时长
        未触发时返回 (False, None)。
        """
        import time

        if not self._recording:
            return False, None
        now = time.time()
        elapsed = now - self._started_ts
        if elapsed >= max_seconds:
            return True, "timeout"
        if elapsed < min_seconds:
            return False, None
        if not self._saw_voice:
            # 一直没检测到说话：给 3 秒宽限
            if elapsed >= 3.0:
                return True, "silence"
            return False, None
        if now - self._last_voice_ts >= silence_seconds:
            return True, "silence"
        return False, None


def list_input_devices():
    """列出可用输入设备，便于排查麦克风问题。"""
    try:
        devices = sd.query_devices()
    except Exception:
        return []
    result = []
    for idx, dev in enumerate(devices):
        if dev.get("max_input_channels", 0) > 0:
            result.append((idx, dev.get("name", "未知设备")))
    return result


def default_input_device():
    try:
        return sd.query_devices(kind="input")
    except Exception:
        return None
