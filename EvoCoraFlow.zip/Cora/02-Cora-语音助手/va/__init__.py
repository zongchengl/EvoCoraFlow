"""桌面智能问答语音助手 —— 核心包。"""

__version__ = "1.0.0"
__all__ = ["config", "audio", "asr", "tts", "llm"]
