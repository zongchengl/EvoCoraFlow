"""Cora artwork rendering with a lightweight, non-blocking star animation."""
import logging
import math
import random
try:
    import tkinter as tk
except ImportError:  # 允许无桌面运行时做静态图像回归测试
    class _TkUnavailable:
        class Canvas:
            def __init__(self, *args, **kwargs):
                raise RuntimeError("图形界面需要 Python Tk 支持")

        class TclError(Exception):
            pass

    tk = _TkUnavailable()

log = logging.getLogger(__name__)


def render_background(source, width, height):
    """Cover the viewport, keeping the portrait's top/right; dim only chat side."""
    from PIL import Image, ImageOps
    if width < 1 or height < 1:
        raise ValueError("Background dimensions must be positive")
    image = ImageOps.fit(source.convert("RGB"), (width, height),
                         method=Image.Resampling.LANCZOS, centering=(1.0, 0.0))
    mask = Image.new("L", (width, 1))
    mask.putdata([round(46 * max(0.0, 1.0 - x / max(1, width * .60)))
                  for x in range(width)])
    return Image.composite(Image.new("RGB", image.size, "#080e23"), image,
                           mask.resize(image.size))


class ArtworkCanvas(tk.Canvas):
    """Viewport-pinned background with subtle stars that never block the UI."""
    def __init__(self, master, image_path, **kwargs):
        super().__init__(master, highlightthickness=0, bd=0, **kwargs)
        self._source = None
        self._photo = None
        self._bg_id = None
        self._size = None
        self._pending = None
        self._scrollbar = None
        self._stars = []
        self._phase = 0.0
        self._animation_job = None
        try:
            from PIL import Image
            with Image.open(image_path) as image:
                self._source = image.convert("RGB")
        except (OSError, ImportError, ValueError) as exc:
            log.warning("Cora background unavailable (%s); using solid color", type(exc).__name__)
        self.configure(yscrollcommand=self._on_scroll)
        self.bind("<Configure>", self._schedule_repaint)
        self._animation_job = self.after(180, self._animate)

    def set_scrollbar(self, callback):
        self._scrollbar = callback

    def _on_scroll(self, first, last):
        self._pin_background()
        if self._scrollbar:
            self._scrollbar(first, last)

    def _pin_background(self):
        x, y = self.canvasx(0), self.canvasy(0)
        if self._bg_id is not None:
            self.coords(self._bg_id, x, y)
        for star in self._stars:
            self.coords(star["id"], x + star["x"], y + star["y"])
        if self._bg_id is not None:
            self.tag_lower(self._bg_id)
        for star in self._stars:
            self.tag_raise(star["id"])

    def _schedule_repaint(self, event=None):
        if self._pending is not None:
            self.after_cancel(self._pending)
        self._pending = self.after(100, self.repaint)

    def _ensure_stars(self, width, height):
        if self._stars and self._size == (width, height):
            return
        for star in self._stars:
            self.delete(star["id"])
        rng = random.Random(width * 1009 + height * 9176)
        self._stars = []
        for _ in range(min(42, max(16, width // 24))):
            x = rng.uniform(width * 0.42, width * 0.98)
            y = rng.uniform(height * 0.04, height * 0.92)
            radius = rng.choice((1.0, 1.0, 1.4, 1.8))
            item_id = self.create_oval(x - radius, y - radius, x + radius, y + radius,
                                       fill="#bde8ff", outline="", tags="cora-star")
            self._stars.append({"id": item_id, "x": x, "y": y,
                               "radius": radius, "phase": rng.uniform(0, math.tau)})

    def repaint(self):
        if self._pending is not None:
            self.after_cancel(self._pending)
            self._pending = None
        width, height = self.winfo_width(), self.winfo_height()
        if width < 2 or height < 2:
            return
        if self._source is not None and self._size != (width, height):
            from PIL import ImageTk
            image = render_background(self._source, width, height)
            self._photo = ImageTk.PhotoImage(image, master=self)
            if self._bg_id is None:
                self._bg_id = self.create_image(0, 0, anchor="nw", image=self._photo, tags="bg")
            else:
                self.itemconfigure(self._bg_id, image=self._photo)
        self._size = (width, height)
        self._ensure_stars(width, height)
        self._pin_background()

    def _animate(self):
        self._animation_job = None
        self._phase += 0.22
        for star in self._stars:
            brightness = 0.48 + 0.42 * ((math.sin(self._phase + star["phase"]) + 1.0) / 2.0)
            if self._stars:
                color = "#%02x%02x%02x" % (int(120 + 110 * brightness),
                                            int(185 + 60 * brightness), 255)
                self.itemconfigure(star["id"], fill=color)
        try:
            self._animation_job = self.after(180, self._animate)
        except tk.TclError:
            self._animation_job = None

    def destroy(self):
        if self._pending is not None:
            self.after_cancel(self._pending)
            self._pending = None
        if self._animation_job is not None:
            try:
                self.after_cancel(self._animation_job)
            except tk.TclError:
                pass
            self._animation_job = None
        super().destroy()
