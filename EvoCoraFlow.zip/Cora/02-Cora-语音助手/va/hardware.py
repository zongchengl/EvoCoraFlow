"""Safety-first camera, motor and vision interfaces for Cora.

The default is deliberately simulated and disconnected. Real devices are only
opened after an explicit connect call; motor motion additionally requires the
unlock phrase and a per-action confirmation from the UI.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
import string
import threading
from typing import Any, Iterable


ALLOWED_MOTIONS = frozenset({"left", "right", "up", "down", "stop"})
UNLOCK_PHRASE = "确认解锁硬件"


class HardwareError(RuntimeError):
    """Base error for device and model operations."""


class SafetyError(HardwareError):
    """Raised when a motion violates the safety gate."""


class HardwareSafetyGate:
    """Independent lock and emergency-stop state for all motion commands."""

    def __init__(self):
        self._unlocked = False
        self._emergency = False
        self._lock = threading.RLock()

    @property
    def unlocked(self) -> bool:
        with self._lock:
            return self._unlocked

    @property
    def emergency_stopped(self) -> bool:
        with self._lock:
            return self._emergency

    def unlock(self, phrase: str) -> bool:
        with self._lock:
            if phrase.strip() != UNLOCK_PHRASE:
                return False
            if self._emergency:
                return False
            self._unlocked = True
            return True

    def lock(self) -> None:
        with self._lock:
            self._unlocked = False

    def emergency_stop(self) -> None:
        with self._lock:
            self._emergency = True
            self._unlocked = False

    def reset_emergency(self) -> None:
        with self._lock:
            self._emergency = False

    def check_motion(self, action: str, confirmed: bool) -> None:
        if action not in ALLOWED_MOTIONS:
            raise SafetyError(f"不允许的电机动作：{action}")
        with self._lock:
            # 停止是安全动作：即使尚未解锁或急停状态已触发，也允许
            # 发送停止命令，避免“锁住了所以停不下来”。
            if action == "stop":
                return
            if self._emergency:
                raise SafetyError("急停已触发，请先复位急停")
            if not self._unlocked:
                raise SafetyError("硬件控制仍处于锁定状态")
            if not confirmed:
                raise SafetyError("真实运动必须由用户明确确认")


class CameraController:
    """Lazy camera wrapper; simulated mode never touches a camera device."""

    def __init__(self, simulated: bool = True):
        self.simulated = bool(simulated)
        self.index: int | str | None = None
        self._capture = None
        self.connected = False

    def connect(self, index: int | str = 0) -> None:
        if self.connected:
            return
        if self.simulated:
            self.index = index
            self.connected = True
            return
        try:
            import cv2
        except ImportError as exc:
            raise HardwareError("真实摄像头需要安装 opencv-python") from exc
        try:
            device = int(index)
        except (TypeError, ValueError) as exc:
            raise HardwareError("摄像头编号必须是整数") from exc
        capture = cv2.VideoCapture(device, cv2.CAP_DSHOW)
        if not capture.isOpened():
            capture.release()
            raise HardwareError(f"无法打开摄像头 {device}")
        self._capture = capture
        self.index = device
        self.connected = True

    def read(self) -> Any:
        if not self.connected:
            raise HardwareError("摄像头尚未连接")
        if self.simulated:
            return {"simulated": True, "device_index": self.index, "width": 640, "height": 480}
        ok, frame = self._capture.read()
        if not ok:
            raise HardwareError("摄像头读取画面失败")
        return frame

    def disconnect(self) -> None:
        if self._capture is not None:
            self._capture.release()
            self._capture = None
        self.connected = False
        self.index = None


class MotorController:
    """Whitelisted stepper motor adapter with an explicit safety gate."""

    def __init__(self, simulated: bool = True, safety_gate: HardwareSafetyGate | None = None):
        self.simulated = bool(simulated)
        self.safety_gate = safety_gate or HardwareSafetyGate()
        self.port: str | None = None
        self._serial = None
        self.connected = False
        self.last_command: dict[str, Any] | None = None

    def connect(self, port: str = "SIM") -> None:
        if self.connected:
            return
        if self.simulated:
            self.port = port or "SIM"
            self.connected = True
            return
        try:
            import serial
        except ImportError as exc:
            raise HardwareError("真实电机需要安装 pyserial") from exc
        if not port:
            raise HardwareError("请先选择电机串口")
        serial_port = serial.Serial(port=port, baudrate=115200, timeout=1)
        self._serial = serial_port
        self.port = port
        self.connected = True

    def jog(self, action: str, steps: int = 10, confirmed: bool = False) -> dict[str, Any]:
        action = str(action).strip().lower()
        self.safety_gate.check_motion(action, confirmed)
        if not self.connected:
            raise HardwareError("电机尚未连接")
        if not isinstance(steps, int) or not 1 <= steps <= 10000:
            raise HardwareError("步数必须是 1 到 10000 的整数")
        command = {"action": action, "steps": steps, "simulated": self.simulated}
        self.last_command = command
        if not self.simulated and action != "stop":
            payload = f"{action.upper()} {steps}\n".encode("ascii")
            self._serial.write(payload)
        elif not self.simulated:
            self._serial.write(b"STOP\n")
        return dict(command)

    def emergency_stop(self) -> None:
        self.safety_gate.emergency_stop()
        if self.connected and not self.simulated and self._serial is not None:
            self._serial.write(b"STOP\n")
        self.last_command = {"action": "stop", "emergency": True, "simulated": self.simulated}

    def disconnect(self) -> None:
        if self._serial is not None:
            self._serial.close()
            self._serial = None
        self.connected = False
        self.port = None
        self.safety_gate.lock()


class VisionModelController:
    """Load-only adapter for .engine/.onnx model paths.

    In this first safe integration the class validates and records the model
    path; inference remains delegated to the user's existing detector process.
    """

    def __init__(self, simulated: bool = True):
        self.simulated = bool(simulated)
        self.path: str | None = None
        self.loaded = False

    def load(self, path: str) -> bool:
        import os
        path = os.path.abspath(os.path.expanduser(str(path)))
        if not os.path.isfile(path):
            raise FileNotFoundError(f"视觉模型文件不存在：{path}")
        self.path = path
        self.loaded = True
        return True

    def unload(self) -> None:
        self.path = None
        self.loaded = False


def _class_key(item: dict[str, Any]) -> str:
    value = item.get("class_name", item.get("class_id", "droplet"))
    return str(value)


def label_droplets(droplets: Iterable[dict[str, Any]], row_tolerance: float = 0.0) -> list[dict[str, Any]]:
    """Sort detections top-to-bottom/left-to-right and assign A1, A2, B1...

    The input is copied. Each item needs numeric ``x`` and ``y``; optional
    ``class_name`` or ``class_id`` groups detections into the same letter.
    ``row_tolerance`` can be used by a detector to treat nearly aligned y
    values as one row, while preserving left-to-right order inside a row.
    """
    items = [dict(item) for item in droplets]
    for item in items:
        if "x" not in item or "y" not in item:
            raise ValueError("每个液滴检测结果都必须包含 x 和 y")
        try:
            item["x"] = float(item["x"])
            item["y"] = float(item["y"])
        except (TypeError, ValueError) as exc:
            raise ValueError("液滴坐标必须是数字") from exc

    # A stable row-aware key avoids detector order affecting labels.
    if row_tolerance > 0:
        rows: list[float] = []
        def row_key(y: float) -> float:
            for row in rows:
                if abs(y - row) <= row_tolerance:
                    return row
            rows.append(y)
            return y
        for item in items:
            item["_row"] = row_key(item["y"])
        items.sort(key=lambda item: (item["_row"], item["x"]))
    else:
        items.sort(key=lambda item: (item["y"], item["x"]))

    letters: dict[str, str] = {}
    counters: defaultdict[str, int] = defaultdict(int)
    for item in items:
        key = _class_key(item)
        if key not in letters:
            letters[key] = string.ascii_uppercase[len(letters) % 26]
        counters[key] += 1
        item["label"] = f"{letters[key]}{counters[key]}"
        item.pop("_row", None)
    return items


@dataclass
class HardwareHub:
    """Small composition root used by the UI; safe and lazy by default."""

    simulated: bool = True

    def __post_init__(self):
        self.safety_gate = HardwareSafetyGate()
        self.camera = CameraController(self.simulated)
        self.motor = MotorController(self.simulated, self.safety_gate)
        self.vision = VisionModelController(self.simulated)

    def status(self) -> dict[str, Any]:
        return {
            "simulated": self.simulated,
            "camera_connected": self.camera.connected,
            "motor_connected": self.motor.connected,
            "motor_unlocked": self.safety_gate.unlocked,
            "emergency_stopped": self.safety_gate.emergency_stopped,
            "vision_loaded": self.vision.loaded,
        }

    def disconnect_all(self) -> None:
        self.camera.disconnect()
        self.motor.disconnect()
        self.vision.unload()
