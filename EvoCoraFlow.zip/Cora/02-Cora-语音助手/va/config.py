"""配置管理：默认值 + config.json 覆盖，支持点号路径读写。"""

import copy
import json
import os

# ---------------------------------------------------------------- 默认配置

DEFAULT_CONFIG = {
    "llm": {
        "base_url": "https://api.deepseek.com",
        "api_key": "",
        "model": "deepseek-chat",
        "temperature": 0.7,
        "max_history": 20,
        "system_prompt": (
            "你是运行在用户电脑上的桌面语音助手，名叫Cora。"
            "你的回答会被语音朗读出来，所以请用口语化、简洁的中文回答，"
            "通常控制在两三句话以内；不要使用列表、Markdown 符号、表情符号、"
            "括号补充或书面语标题。需要分步骤时用自然语言叙述。"
            "你还连着本机的液滴操控程序 Cora：开启联动后，"
            "「把最左边的液滴移到右侧」「把 A1 移到 B2 旁边」「停止」"
            "这类操控指令会直接由它执行 —— 它用工业相机识别液滴、"
            "驱动步进电机移动激光来拖拽液滴，这类指令系统会先交给它，你不用回答。"
            "如果用户只是聊天式地问你能不能看画面、能不能动电机，"
            "应说明必须先连接设备并核对状态；不得在未连接时声称已执行动作。"
            "如果用户的问题需要精确数据而你并不确定，就直说不确定。"
        ),
        "timeout": 60,
    },
    "asr": {
        "model": "base",          # tiny / base / small / medium
        "language": "zh",
        "device": "cpu",
        "initial_prompt": "以下是普通话内容。",
        "hotwords": "",           # 用逗号分隔的专有名词，会拼进提示词
    },
    "web_search": {
        "enabled": False,
        "provider": "bing_rss",
        "api_key": "",
    },
    "tts": {
        "enabled": True,
        "voice": "zh-CN-XiaoxiaoNeural",
        "rate": "+0%",
        "volume": "+0%",
        "pitch": "+0Hz",
    },
    "audio": {
        "sample_rate": 16000,
        "channels": 1,
        "device": None,           # null = 用系统默认麦克风；也可填设备序号
        "max_record_seconds": 30,
        "min_record_seconds": 0.35,
        "auto_stop": True,        # 静音自动结束录音
        "silence_threshold": 0.012,
        "silence_seconds": 1.3,
    },
    "ui": {
        "appearance": "dark",
        "always_on_top": False,
        "window_size": "560x760",
    },
    "hardware": {
        # 安全默认值：不自动打开设备，且先使用模拟适配器。
        "enabled": False,
        "laser_enabled": False,
        "simulated": True,
        "camera_index": 0,
        "motor_port": "",
        "engine_path": "",
        "cora_args": [],          # 主链的 ROI、曝光、输入源等命令行参数
    },
}


class Config:
    """轻量配置对象，读写 config.json（UTF-8）。"""

    def __init__(self, path):
        self.path = path
        self.data = copy.deepcopy(DEFAULT_CONFIG)
        self.load()

    # ------------------------------------------------------------ 基础操作
    def load(self):
        if not os.path.exists(self.path):
            self.save()
        else:
            try:
                with open(self.path, "r", encoding="utf-8-sig") as f:
                    user = json.load(f)
                self._merge(self.data, user)
            except Exception as exc:  # 配置损坏时不阻塞启动
                print(f"[config] 读取失败，使用默认配置：{exc}")

        # API Key 只允许从环境变量注入，环境变量优先于配置文件。
        # 这样即使 config.json 被复制、压缩或提交，也不会把密钥带出去。
        env_key = os.getenv("DEEPSEEK_API_KEY", "").strip()
        self.data.setdefault("llm", {})["api_key"] = env_key
        # Never trust or restore a Tavily key from config.json. The settings UI
        # may hold one for this process only; a persistent key must come from env.
        self.data.setdefault("web_search", {})["api_key"] = os.getenv("TAVILY_API_KEY", "").strip()

    def save(self):
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            persisted = copy.deepcopy(self.data)
            # Tavily credentials are runtime-only, including values entered in
            # the settings dialog. Never write them to config.json.
            persisted.setdefault("web_search", {})["api_key"] = ""
            # Environment-injected chat credentials are runtime-only as well.
            persisted.setdefault("llm", {})["api_key"] = ""
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump(persisted, f, ensure_ascii=False, indent=2)
        except Exception as exc:
            print(f"[config] 保存失败：{exc}")

    @staticmethod
    def _merge(base, override):
        for key, value in override.items():
            if isinstance(value, dict) and isinstance(base.get(key), dict):
                Config._merge(base[key], value)
            else:
                base[key] = value

    # ------------------------------------------------------------ 点号读写
    def get(self, path, default=None):
        cur = self.data
        for part in path.split("."):
            if not isinstance(cur, dict) or part not in cur:
                return default
            cur = cur[part]
        return cur

    def set(self, path, value):
        parts = path.split(".")
        cur = self.data
        for part in parts[:-1]:
            cur = cur.setdefault(part, {})
        cur[parts[-1]] = value

    # ------------------------------------------------------------ 便捷属性
    @property
    def has_api_key(self) -> bool:
        key = (self.get("llm.api_key") or "").strip()
        return len(key) > 8 and not key.startswith("sk-把你的")

