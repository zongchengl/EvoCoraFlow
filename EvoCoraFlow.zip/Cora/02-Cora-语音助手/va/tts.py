"""语音合成：Edge TTS（微软免费接口，中文自然）+ pygame 播放。

- 支持中途打断（stop），便于"说话时按一下就能插话"。
- 网络异常时自动降级到 Windows 自带 SAPI 语音，保证始终有声音。
"""

import asyncio
import os
import subprocess
import tempfile
import threading
import time


class TTS:
    def __init__(self, voice="zh-CN-XiaoxiaoNeural", rate="+0%",
                 volume="+0%", pitch="+0Hz", enabled=True):
        self.voice = voice
        self.rate = rate
        self.volume = volume
        self.pitch = pitch
        self.enabled = enabled
        self._mixer_ready = False
        self._speaking = False
        self._stop_flag = threading.Event()
        self._speak_lock = threading.Lock()   # pygame.mixer.music 是全局单例，必须串行
        self.last_error = None

    # ------------------------------------------------------------ 播放器
    def _ensure_mixer(self):
        if self._mixer_ready:
            return
        import pygame

        self._sweep_stale_temp()
        pygame.mixer.init(frequency=24000, size=-16, channels=2, buffer=1024)
        self._mixer_ready = True

    @staticmethod
    def _sweep_stale_temp():
        """清掉上次异常退出遗留的语音临时文件（只删本程序命名的那批）。"""
        import glob

        try:
            pattern = os.path.join(tempfile.gettempdir(), "va_tts_*.mp3")
            for path in glob.glob(pattern):
                try:
                    if time.time() - os.path.getmtime(path) > 3600:
                        os.remove(path)
                except Exception:
                    pass
        except Exception:
            pass

    # ------------------------------------------------------------ 合成
    def _synth_edge(self, text: str, out_path: str):
        import edge_tts

        async def _run():
            communicate = edge_tts.Communicate(
                text, self.voice, rate=self.rate, volume=self.volume, pitch=self.pitch
            )
            await communicate.save(out_path)

        asyncio.run(_run())

    def _speak_sapi(self, text: str):
        """兜底：Windows 自带语音（离线，音质一般）。"""
        safe = text.replace("'", "''")
        script = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            "$s.Rate = 2; "
            f"$s.Speak('{safe}');"
        )
        try:
            subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                timeout=120,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception as exc:
            self.last_error = f"兜底语音失败：{exc}"

    # ------------------------------------------------------------ 对外接口
    def speak(self, text: str, on_start=None):
        """朗读文本，阻塞直到播完或被 stop() 打断。"""
        if not self.enabled or not text or not text.strip():
            return
        with self._speak_lock:
            self._speak_inner(text, on_start)

    def _speak_inner(self, text: str, on_start=None):
        self._stop_flag.clear()
        self.last_error = None
        # 每次朗读都必须换一个新的临时文件名。
        # pygame.mixer.music 会一直握着音源文件的句柄，若沿用同一个名字，
        # 下一句 edge-tts 再往该路径写就会被系统拒绝（Permission denied），
        # 表现为「第一句正常，之后全降级成系统离线音」。
        self._tmp_seq = getattr(self, "_tmp_seq", 0) + 1
        tmp_path = os.path.join(
            tempfile.gettempdir(),
            f"va_tts_{os.getpid()}_{self._tmp_seq}_{int(time.time() * 1000) % 100000}.mp3",
        )
        try:
            self._ensure_mixer()
            self._synth_edge(text, tmp_path)
            if self._stop_flag.is_set():
                return
            import pygame

            pygame.mixer.music.load(tmp_path)
            pygame.mixer.music.play()
            self._speaking = True
            if on_start:
                try:
                    on_start()
                except Exception:
                    pass
            while pygame.mixer.music.get_busy():
                if self._stop_flag.is_set():
                    pygame.mixer.music.stop()
                    break
                time.sleep(0.05)
        except Exception as exc:
            self.last_error = str(exc)
            print(f"[tts] Edge TTS 不可用（{exc}），改用系统离线语音")
            if not self._stop_flag.is_set():
                self._speak_sapi(text)
        finally:
            self._speaking = False
            # 先松开播放器对文件的占用再删。pygame 不松手时 Windows 删不掉，
            # 临时文件会一直堆在 Temp 目录里。
            try:
                import pygame

                pygame.mixer.music.stop()
                pygame.mixer.music.unload()
            except Exception:
                pass
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass

    def stop(self):
        """打断当前朗读。"""
        self._stop_flag.set()
        if self._mixer_ready:
            try:
                import pygame

                pygame.mixer.music.stop()
            except Exception:
                pass

    @property
    def speaking(self) -> bool:
        return self._speaking

    # ------------------------------------------------------------ 试听
    def preview(self, voice: str, text="你好，我是你的桌面语音助手。"):
        old = self.voice
        self.voice = voice
        self.speak(text)
        self.voice = old


# 可选的中文音色（Edge TTS）
VOICE_CHOICES = [
    ("zh-CN-XiaoxiaoNeural", "晓晓 · 女声 · 亲切自然（推荐）"),
    ("zh-CN-XiaoyiNeural", "晓伊 · 女声 · 俏皮活泼"),
    ("zh-CN-YunxiNeural", "云希 · 男声 · 阳光少年"),
    ("zh-CN-YunjianNeural", "云健 · 男声 · 沉稳解说"),
    ("zh-CN-YunyangNeural", "云扬 · 男声 · 新闻播报"),
    ("zh-CN-liaoning-XiaobeiNeural", "晓北 · 女声 · 东北口音"),
    ("zh-TW-HsiaoChenNeural", "晓臻 · 女声 · 台湾腔"),
]
