# -*- coding: utf-8 -*-
"""桌面智能问答语音助手 —— 主程序。

按住空格或按住麦克风按钮说话，松开即识别 → 提问 → 播报回答。
技术栈：sounddevice 录音 + 本地 Whisper 识别 + DeepSeek 对话 + Edge TTS 播报。
"""

import math
import os
import queue
import sys
import threading
import time
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    TK_AVAILABLE = True
except ImportError:  # 无 Tk 的环境仍可运行安全/解析离线测试
    TK_AVAILABLE = False

    class _TkUnavailable:
        class Tk:
            def __init__(self, *args, **kwargs):
                raise RuntimeError("图形界面需要 Python Tk 支持")

        class Canvas:
            def __init__(self, *args, **kwargs):
                raise RuntimeError("图形界面需要 Python Tk 支持")

        class Entry:
            pass

        class Toplevel:
            pass

        class TclError(Exception):
            pass

        def __getattr__(self, _name):
            raise RuntimeError("图形界面需要 Python Tk 支持")

    class _TkModuleUnavailable:
        def __getattr__(self, _name):
            raise RuntimeError("图形界面需要 Python Tk 支持")

    tk = _TkUnavailable()
    filedialog = messagebox = ttk = _TkModuleUnavailable()

# pythonw 启动时没有标准输出，先兜住，避免 print 崩溃
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w", encoding="utf-8")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w", encoding="utf-8")

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)

from va.asr import ASR, MODEL_HINT, is_model_cached      # noqa: E402
from va.config import Config                              # noqa: E402
from va.llm import LLM, LLMError, PROVIDER_PRESETS        # noqa: E402
from va.tts import TTS, VOICE_CHOICES                     # noqa: E402
from va.web_search import create_search, SearchError       # noqa: E402
from va.cora_bridge import CoraBridge                     # noqa: E402
from va.chat_background import ArtworkCanvas                 # noqa: E402
from va.hardware import HardwareHub, SafetyError, UNLOCK_PHRASE  # noqa: E402

CONFIG_PATH = os.path.join(APP_DIR, "config.json")
CHAT_ONLY_PROMPT = (
    "你是 Cora，一位友好、简洁的中文语音助手。当前运行在仅聊天模式，"
    "没有连接摄像头、步进电机或激光器，也无法执行设备指令。"
    "不能声称已经观察画面、移动液滴或操控硬件。可以讨论实验方案，但要明确未执行。"
    "如果不确定，直接说明。"
)


# Cora 液滴操控程序目录：优先支持源码包的中文目录名，兼容旧版 cora 目录。
def _resolve_cora_dir():
    env_dir = os.getenv("CORA_DROPLET_DIR", "").strip().strip('"')
    candidates = []
    if env_dir:
        candidates.append(os.path.abspath(env_dir))
    candidates.extend([
        os.path.normpath(os.path.join(APP_DIR, "..", "01-Cora-液滴操控系统")),
        os.path.normpath(os.path.join(APP_DIR, "..", "cora")),
    ])
    for path in candidates:
        if os.path.isfile(os.path.join(path, "cora.py")):
            return path
    return candidates[0]


CORA_DIR = _resolve_cora_dir()


def _console_python():
    """Cora 必须用「控制台版」解释器启动 —— 它要读写 stdin/stdout 管道。

    pythonw.exe 是 GUI 子系统程序，带重定向管道时行为不稳；
    换成同目录的 python.exe，再靠 CREATE_NO_WINDOW 避免弹控制台。
    """
    exe = sys.executable or "python"
    if exe.lower().endswith("pythonw.exe"):
        cand = exe[: -len("pythonw.exe")] + "python.exe"
        if os.path.exists(cand):
            return cand
    return exe

# ------------------------------------------------------------------ 配色
# 「夜深紫」主题：整体是靛蓝 → 紫的竖向渐变，配一抹青色作点缀。
BG        = "#12131f"      # 兜底底色
HEADER_BG = "#141524"      # 顶栏
FOOTER_BG = "#181729"      # 底栏
PANEL     = "#1b1c2a"      # 通用面板（设置窗口等）
CARD      = "#242639"      # 按钮 / 输入框
BORDER    = "#303349"      # 描边
TEXT      = "#e9eaf4"
MUTED     = "#8f92a8"
ACCENT    = "#8b5cf6"      # 主强调色：紫
ACCENT_2  = "#22d3ee"      # 次强调色：青（只做点缀）
USER_BG   = "#4b63f0"
AI_BG     = "#232538"
REC_RED   = "#f2555a"
OK_GREEN  = "#3ecf8e"
WARN      = "#f5a524"

# 对话区背景渐变（上 → 下）
GRAD_TOP  = "#101120"
GRAD_BOT  = "#1d1735"

F_UI    = ("Microsoft YaHei UI", 10)
F_SMALL = ("Microsoft YaHei UI", 9)
F_CHAT  = ("Microsoft YaHei UI", 11)
F_TITLE = ("Microsoft YaHei UI", 12, "bold")

STATUS_TEXT = {
    "idle":        ("就绪", MUTED),
    "loading":     ("正在加载语音模型…", WARN),
    "recording":   ("正在聆听，说完自动结束", REC_RED),
    "recognizing": ("正在识别…", ACCENT),
    "thinking":    ("正在思考…", ACCENT),
    "speaking":    ("正在朗读，按空格可打断", OK_GREEN),
    "error":       ("出错了", REC_RED),
}


# ------------------------------------------------------------------ 绘图工具
def _hex2rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _rgb2hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in rgb)


def blend(c1, c2, t):
    """两色插值：t=0 取 c1，t=1 取 c2。t 会自动夹到 [0,1]。"""
    t = 0.0 if t < 0 else (1.0 if t > 1 else t)
    a, b = _hex2rgb(c1), _hex2rgb(c2)
    return _rgb2hex([a[i] + (b[i] - a[i]) * t for i in range(3)])


def round_rect_points(x0, y0, x1, y1, r, steps=8):
    """圆角矩形的顶点序列，配合 create_polygon(smooth=True) 用。"""
    r = max(0.0, min(r, (x1 - x0) / 2.0, (y1 - y0) / 2.0))
    pts = []
    for cx, cy, a0, a1 in ((x1 - r, y0 + r, -90.0, 0.0),
                           (x1 - r, y1 - r, 0.0, 90.0),
                           (x0 + r, y1 - r, 90.0, 180.0),
                           (x0 + r, y0 + r, 180.0, 270.0)):
        for s in range(steps + 1):
            a = math.radians(a0 + (a1 - a0) * s / steps)
            pts.extend((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def _jelly_sprite(px, phase, tint=(120, 215, 255), alpha=165):
    """画一只水母（伞盖 + 触手 + 伞底亮点），返回一张带透明的 RGBA 图。

    phase 控制"呼吸"：伞盖一缩一放，触手随之摆动。
    """
    from PIL import Image, ImageDraw, ImageFilter

    w = max(24, int(px))
    h = int(w * 1.55)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    cx = w * 0.5
    pulse = math.sin(phase)
    rx = w * 0.30 * (1.0 - 0.10 * pulse)
    ry = w * 0.22 * (1.0 + 0.20 * pulse)
    cy = w * 0.40

    # 触手先画，让伞盖压在上面，看起来才是从伞下垂出来的
    for i in range(7):
        x0 = cx + (i / 6.0 - 0.5) * rx * 0.85
        pts = []
        for s in range(16):
            u = s / 15.0
            y = cy + ry * 0.55 + u * (h - cy - ry * 0.55) * 0.92
            x = x0 + math.sin(u * 3.4 + phase * 1.5 + i * 0.85) * w * 0.045 * (0.35 + u)
            pts.append((x, y))
        d.line(pts, fill=tint + (int(alpha * 0.74),),
               width=max(2, int(w * 0.016)), joint="curve")

    d.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=tint + (alpha,))
    # 伞盖内高光，制造"半透明"的观感
    d.ellipse([cx - rx * 0.55, cy - ry * 0.72, cx + rx * 0.46, cy - ry * 0.04],
              fill=(228, 250, 255, int(alpha * 0.55)))
    # 伞底一圈亮点
    for i in range(9):
        bx = cx + (i / 8.0 - 0.5) * rx * 1.85
        by = cy + ry * 0.92
        r = max(1.5, w * 0.012)
        d.ellipse([bx - r, by - r, bx + r, by + r], fill=(205, 245, 255, alpha))

    return img.filter(ImageFilter.GaussianBlur(max(1.0, w * 0.015)))


class GradientCanvas(tk.Canvas):
    """动态背景画布：竖向渐变 + 柔光 + 缓慢漂游的水母。

    blobs 每项为 (fx, fy, fr, 颜色, 强度)，fx/fy/fr 是相对宽高的比例。

    水母采用**逐帧预渲染**：启动和改尺寸时把所有帧一次渲完存成 PhotoImage，
    播放时只 itemconfigure 换图。每帧现算 numpy 在 20fps 下会掉帧。
    """

    FRAMES = 32          # 一个呼吸周期的帧数
    INTERVAL = 80        # 每帧间隔（ms）→ 约 2.6 秒一个循环

    def __init__(self, master, grad=(GRAD_TOP, GRAD_BOT), blobs=(), jelly=True, **kw):
        super().__init__(master, highlightthickness=0, bd=0, **kw)
        self._grad = grad
        self._blobs = tuple(blobs)
        self._jelly = jelly
        self._size = None
        self._photos = []
        self._idx = 0
        self._job = None
        self._pending = None
        self._bg_id = None
        self.bind("<Configure>", self._on_configure)

    # ---------------------------------------------------------- 尺寸变化
    def _on_configure(self, _e=None):
        # 拖窗口会连续触发 Configure，防抖：停手一会儿再重渲
        if self._pending:
            try:
                self.after_cancel(self._pending)
            except Exception:
                pass
        self._pending = self.after(220, self.repaint)

    def repaint(self):
        self._pending = None
        w, h = self.winfo_width(), self.winfo_height()
        if w < 2 or h < 2 or (w, h) == self._size:
            return
        self._size = (w, h)
        self._stop_play()
        try:
            from PIL import ImageTk

            base = self._render_base(w, h)
            images = self._render_frames(base, w, h) if self._jelly else [base]
            # PhotoImage 必须留着引用，否则被回收后背景会变空白
            self._photos = [ImageTk.PhotoImage(im) for im in images]
            self.delete("bg")
            self._bg_id = self.create_image(0, 0, anchor="nw",
                                            image=self._photos[0], tags="bg")
            self.tag_lower("bg")
            self._idx = 1
            if len(self._photos) > 1:
                self._play()
        except Exception:
            # 没有 PIL 就退回纯色，至少不会开天窗
            self.delete("bg")
            self.configure(bg=self._grad[0])

    # ---------------------------------------------------------- 播放
    def _play(self):
        if not self._photos or self._bg_id is None:
            return
        if not self.winfo_exists():
            return
        try:
            self.itemconfigure(self._bg_id, image=self._photos[self._idx])
        except Exception:
            return
        self._idx = (self._idx + 1) % len(self._photos)
        self._job = self.after(self.INTERVAL, self._play)

    def _stop_play(self):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None

    def destroy(self):
        self._stop_play()
        super().destroy()

    # ---------------------------------------------------------- 渲染
    def _render_frames(self, base, w, h):
        """在底图上一层层叠水母，渲出一个呼吸周期的全部帧。"""
        from PIL import ImageFilter

        n = max(8, int(self.FRAMES))
        big = max(120.0, min(w, h) * 0.50)
        rgba = base.convert("RGBA")
        frames = []
        for k in range(n):
            ph = 2 * math.pi * k / n
            img = rgba.copy()

            # 前景大只：缓慢左右漂 + 上下浮
            spr = _jelly_sprite(big, ph)
            pos = (int(w * 0.72 + math.sin(ph) * w * 0.045 - spr.width / 2),
                   int(h * 0.30 + math.cos(ph * 0.5) * h * 0.030 - spr.height * 0.45))
            img.alpha_composite(spr.filter(ImageFilter.GaussianBlur(big * 0.07)), pos)
            img.alpha_composite(spr, pos)

            # 背景小只：错开相位，做出景深
            small = big * 0.54
            spr2 = _jelly_sprite(small, ph + 2.1, tint=(150, 190, 255), alpha=120)
            pos2 = (int(w * 0.23 + math.sin(ph + 1.7) * w * 0.035 - spr2.width / 2),
                    int(h * 0.62 + math.cos(ph * 0.7 + 1.0) * h * 0.035 - spr2.height * 0.45))
            img.alpha_composite(spr2.filter(ImageFilter.GaussianBlur(small * 0.09)), pos2)
            img.alpha_composite(spr2, pos2)

            frames.append(img.convert("RGB"))
        return frames

    def _render_base(self, w, h):
        """整幅渲出「竖向渐变 + 径向柔光」。

        不用同心椭圆逐层叠加来近似光晕 —— 那样每一层的边界在下层渐变上
        会留下肉眼可见的硬弧。直接按像素算，过渡才是真正平滑的。
        """
        import numpy as np
        from PIL import Image

        top = np.array(_hex2rgb(self._grad[0]), dtype=np.float32)
        bot = np.array(_hex2rgb(self._grad[1]), dtype=np.float32)

        ylin = np.linspace(0.0, 1.0, h, dtype=np.float32)
        ys = ylin * ylin * (3 - 2 * ylin) * 0.5 + ylin * 0.5   # smoothstep，避免色带
        base = top[None, :] + (bot - top)[None, :] * ys[:, None]

        # 光晕的圆心按线性位置算；ys 是加过 smoothstep 的，只能用来插值颜色
        span = float(max(w, h))
        xs = (np.linspace(0.0, 1.0, w, dtype=np.float32) * w / span)[None, :]
        yv = (ylin * h / span)[:, None]
        rgb = np.repeat(base[:, None, :], w, axis=1)

        for fx, fy, fr, color, strength in self._blobs:
            gcol = np.array(_hex2rgb(color), dtype=np.float32)
            dx = xs - fx * w / span
            dy = yv - fy * h / span
            d = np.sqrt(dx * dx + dy * dy) / max(1e-6, fr)
            f = np.clip(1.0 - d, 0.0, 1.0)
            f = (f * f * (3 - 2 * f) * strength)[:, :, None]   # 平滑衰减
            rgb = rgb * (1.0 - f) + gcol[None, None, :] * f

        return Image.fromarray(np.clip(rgb, 0, 255).astype("uint8"), "RGB")


def paint_h_gradient(canvas, width, c1, c2, height=2):
    """给一条细横线刷水平渐变（顶栏下面的强调线用）。"""
    canvas.delete("all")
    for x in range(max(0, width)):
        canvas.create_line(x, 0, x, height, fill=blend(c1, c2, x / max(1, width - 1)))


class VoiceAssistant:
    def __init__(self, root: tk.Tk, *, chat_only=True):
        from va.audio import Recorder
        self.root = root
        self.chat_only = bool(chat_only)
        self.cfg = Config(CONFIG_PATH)
        self.q = queue.Queue()

        self.state = "loading"
        self.bubbles = []
        self.cur_ai_id = None
        self.ai_buffer = ""
        self._space_down = False
        self._pipeline_busy = False
        self._mic_ready = False
        # Cora 联动（相机 + 指令识别 + 步进电机）
        self.bridge = None
        self.cora_on = False
        # 设备接口默认只创建对象，不打开摄像头/串口；连接必须由设置页主动触发。
        self.hardware = HardwareHub(simulated=bool(self.cfg.get("hardware.simulated", True)))

        # ---------------- 组件初始化
        self.recorder = Recorder(
            sample_rate=self.cfg.get("audio.sample_rate", 16000),
            channels=self.cfg.get("audio.channels", 1),
            silence_threshold=self.cfg.get("audio.silence_threshold", 0.012),
            device=self.cfg.get("audio.device"),
        )
        self.asr = ASR(
            model_name=self.cfg.get("asr.model", "base"),
            language=self.cfg.get("asr.language", "zh"),
            device=self.cfg.get("asr.device", "cpu"),
            initial_prompt=self.cfg.get("asr.initial_prompt", ""),
            hotwords=self.cfg.get("asr.hotwords", ""),
        )
        self.tts = TTS(
            voice=self.cfg.get("tts.voice"),
            rate=self.cfg.get("tts.rate"),
            volume=self.cfg.get("tts.volume"),
            pitch=self.cfg.get("tts.pitch"),
            enabled=self.cfg.get("tts.enabled", True),
        )
        self.llm = LLM(
            base_url=self.cfg.get("llm.base_url"),
            api_key=self.cfg.get("llm.api_key"),
            model=self.cfg.get("llm.model"),
            system_prompt=CHAT_ONLY_PROMPT if self.chat_only else self.cfg.get("llm.system_prompt"),
            temperature=self.cfg.get("llm.temperature", 0.7),
            max_history=self.cfg.get("llm.max_history", 20),
            timeout=self.cfg.get("llm.timeout", 60),
        )

        self._build_ui()
        self._bind_keys()
        self.root.after(40, self._drain_queue)
        self.root.after(50, self._tick)

        threading.Thread(target=self._boot, daemon=True).start()

    # ============================================================== 界面
    def _build_ui(self):
        r = self.root
        r.title("Cora · 星空聊天" + (" · 仅聊天模式" if self.chat_only else ""))
        r.configure(bg=BG)
        # Wide composition keeps the portrait on the right, outside the chat column.
        screen_w, screen_h = r.winfo_screenwidth(), r.winfo_screenheight()
        width, height = min(1120, screen_w - 80), min(780, screen_h - 100)
        r.geometry(f"{width}x{height}+{max(0, (screen_w-width)//2)}+{max(0, (screen_h-height)//2-20)}")
        r.minsize(min(820, width), min(580, height))
        if self.cfg.get("ui.always_on_top"):
            r.attributes("-topmost", True)

        self._init_ttk_style()

        # ---------------------------------------------------- 顶栏
        top = tk.Frame(r, bg=HEADER_BG, height=56)
        top.pack(fill="x", side="top")
        top.pack_propagate(False)

        tk.Label(top, text="Cora", bg=HEADER_BG, fg=TEXT, font=F_TITLE).pack(side="left", padx=(16, 6))
        tk.Label(top, text="星空语音助手", bg=HEADER_BG, fg=MUTED, font=F_SMALL).pack(side="left")

        self._mk_btn(top, "清空", self.clear_chat, width=5).pack(side="right", padx=(0, 10), pady=13)
        self._mk_btn(top, "设置", self.open_settings, width=5).pack(side="right", padx=(0, 6), pady=13)
        self.cora_btn = tk.Button(top, text="联动 Cora", command=self.toggle_cora, font=F_SMALL,
                                  bg=ACCENT, fg="#ffffff", activebackground=ACCENT_2,
                                  activeforeground="#0b0c14", relief="flat", bd=0, width=9,
                                  cursor="hand2", highlightthickness=0, padx=6, pady=4)
        self.cora_btn.pack(side="right", padx=(0, 10), pady=13)
        if self.chat_only:
            self.cora_btn.configure(text="仅聊天", state="disabled", bg=CARD,
                                    disabledforeground=ACCENT_2, cursor="arrow")

        self.model_chip = tk.Label(top, text="", bg=HEADER_BG, fg=MUTED, font=F_SMALL)
        self.model_chip.pack(side="right", padx=(0, 12))

        # 顶栏下沿的紫→青强调线，界面因此不至于太平
        self.rule = tk.Canvas(r, height=2, bg=HEADER_BG, highlightthickness=0, bd=0)
        self.rule.pack(fill="x")
        self.rule.bind("<Configure>",
                       lambda e: paint_h_gradient(self.rule, e.width, ACCENT, ACCENT_2))

        # ---------------------------------------------------- 对话区
        wrap = tk.Frame(r, bg=GRAD_TOP)
        wrap.pack(fill="both", expand=True)

        self.canvas = ArtworkCanvas(
            wrap, image_path=os.path.join(APP_DIR, "assets", "gpt-image-01.png"), bg="#090f25")
        self.scroll = ttk.Scrollbar(wrap, orient="vertical", command=self.canvas.yview,
                                    style="Dark.Vertical.TScrollbar")
        self.canvas.set_scrollbar(self.scroll.set)
        self.scroll.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        # 宽度变化时重排气泡；add="+" 才不会顶掉渐变画布自己的重绘
        self.canvas.bind("<Configure>", self._on_canvas_configure, add="+")
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._on_wheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

        # ---------------------------------------------------- 底栏
        bottom = tk.Frame(r, bg=FOOTER_BG)
        bottom.pack(fill="x", side="bottom")
        tk.Frame(bottom, bg=BORDER, height=1).pack(fill="x")

        # 状态条
        status_row = tk.Frame(bottom, bg=FOOTER_BG)
        status_row.pack(fill="x", padx=16, pady=(10, 0))

        self.dot = tk.Canvas(status_row, width=10, height=10, bg=FOOTER_BG, highlightthickness=0)
        self.dot.pack(side="left", pady=(3, 0))
        self.dot_id = self.dot.create_oval(1, 1, 9, 9, fill=MUTED, outline="")

        self.status_lbl = tk.Label(status_row, text="就绪", bg=FOOTER_BG, fg=MUTED, font=F_UI)
        self.status_lbl.pack(side="left", padx=(8, 0))

        self.auto_var = tk.BooleanVar(value=bool(self.cfg.get("audio.auto_stop", True)))
        self.web_search_var = tk.BooleanVar(value=bool(self.cfg.get("web_search.enabled", False)))
        tk.Checkbutton(status_row, text="联网搜索", variable=self.web_search_var,
                       bg=FOOTER_BG, fg=MUTED, selectcolor=CARD, activebackground=FOOTER_BG,
                       activeforeground=TEXT, font=F_SMALL, bd=0, highlightthickness=0,
                       command=self._toggle_web_search).pack(side="right", padx=(0, 12))
        tk.Checkbutton(status_row, text="自动停止", variable=self.auto_var,
                       bg=FOOTER_BG, fg=MUTED, selectcolor=CARD, activebackground=FOOTER_BG,
                       activeforeground=TEXT, font=F_SMALL, bd=0, highlightthickness=0,
                       command=self._toggle_auto_stop).pack(side="right")

        # Compact composer leaves more room for the background and messages.
        composer = tk.Frame(bottom, bg=FOOTER_BG)
        composer.pack(fill="x", padx=16, pady=(4, 10))
        self.btn = tk.Canvas(composer, width=110, height=100, bg=FOOTER_BG,
                             highlightthickness=0, cursor="hand2")
        self.btn.pack(side="left", padx=(0, 12))
        self._draw_mic(0.0, False)
        self.btn.bind("<ButtonPress-1>", lambda e: self.start_recording())
        self.btn.bind("<ButtonRelease-1>", lambda e: self.stop_recording())
        input_panel = tk.Frame(composer, bg=FOOTER_BG)
        input_panel.pack(side="left", fill="both", expand=True, pady=(12, 0))
        self.hint = tk.Label(input_panel, text="按住空格或圆钮说话 · 输入文字后按回车发送",
                             bg=FOOTER_BG, fg=MUTED, font=F_SMALL)
        self.hint.pack(anchor="w", pady=(0, 8))
        row = tk.Frame(input_panel, bg=FOOTER_BG)
        row.pack(fill="x")
        self.entry = tk.Entry(row, bg=CARD, fg=TEXT, insertbackground=TEXT, font=F_UI,
                              relief="flat", bd=0, highlightthickness=1,
                              highlightbackground=BORDER, highlightcolor=ACCENT)
        self.entry.pack(side="left", fill="x", expand=True, ipady=9)
        self.entry.bind("<Return>", lambda e: self.send_text())
        self.entry.bind("<FocusIn>", lambda e: self._set_hint_focus(True))
        self.entry.bind("<FocusOut>", lambda e: self._set_hint_focus(False))
        self._mk_btn(row, "发送", self.send_text, width=6).pack(side="left", padx=(8, 0))

        self._update_model_chip()
        self._welcome()

    def _init_ttk_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Dark.Vertical.TScrollbar", background=CARD, troughcolor=GRAD_TOP,
                        bordercolor=GRAD_TOP, arrowcolor=MUTED, relief="flat", width=10)
        style.map("Dark.Vertical.TScrollbar", background=[("active", BORDER)])

    def _mk_btn(self, parent, text, command, width=6):
        return tk.Button(parent, text=text, command=command, font=F_SMALL,
                         bg=CARD, fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                         relief="flat", bd=0, width=width, cursor="hand2",
                         highlightthickness=0, padx=6, pady=4)

    # -------------------------------------------------------------- 麦克风绘制
    def _draw_mic(self, level=0.0, recording=False, speaking=False):
        c = self.btn
        c.delete("all")
        cx, cy = 55, 50
        base_r = 27
        inner = REC_RED if recording else (OK_GREEN if speaking else ACCENT)
        # 背后的柔光：一圈圈由暗到亮的同心圆，让圆钮"浮"在底栏上
        for i in range(10, 0, -1):
            rr = base_r + 22 * i / 10
            c.create_oval(cx - rr, cy - rr, cx + rr, cy + rr, outline="",
                          fill=blend(FOOTER_BG, inner, 0.16 * (1 - i / 10)))
        # 外圈光晕（随音量放大）
        ring_r = base_r + 6 + level * 22
        c.create_oval(cx - ring_r, cy - ring_r, cx + ring_r, cy + ring_r,
                      outline=inner, width=2, fill="")
        # 按钮本体
        c.create_oval(cx - base_r, cy - base_r, cx + base_r, cy + base_r,
                      fill=inner, outline="")
        # 麦克风图标：细长胶囊头 + 拾音托 + 支杆底座
        white = "#ffffff"
        c.create_oval(cx - 6, cy - 24, cx + 6, cy - 2, fill=white, outline="")
        c.create_rectangle(cx - 6, cy - 16, cx + 6, cy - 8, fill=white, outline="")
        c.create_arc(cx - 12, cy - 9, cx + 12, cy + 15, start=200, extent=140,
                     style="arc", outline=white, width=2.5)
        c.create_line(cx, cy + 13, cx, cy + 19, fill=white, width=2.5)
        c.create_line(cx - 7, cy + 19, cx + 7, cy + 19, fill=white, width=2.5)

    # -------------------------------------------------------------- 气泡
    def _bubble(self, text, role):
        """追加一条气泡，返回序号（流式回复时要靠它原地刷新）。"""
        self.bubbles.append({"text": text, "role": role, "y": 0, "h": 0})
        idx = len(self.bubbles) - 1
        self._render_from(idx)
        return idx

    def _update_bubble(self, idx, text):
        if idx is None or not (0 <= idx < len(self.bubbles)):
            return
        self.bubbles[idx]["text"] = text
        self._render_from(idx)

    def _draw_bubble(self, idx, y_top, text, role, area_w):
        """在 y_top 处画第 idx 个气泡（圆角矩形 + 文字），返回气泡高度。"""
        c = self.canvas
        tag = f"b{idx}"
        c.delete(tag)
        wrap = max(160, int(area_w * 0.74))
        is_user = role == "user"
        fill = USER_BG if is_user else AI_BG
        fg = "#ffffff" if is_user else TEXT
        body = text if text.strip() else " "

        # 先放文字量出真实尺寸，再照着画底衬 —— 长短句都不会留出空白边
        tid = c.create_text(0, y_top, text=body, font=F_CHAT, width=wrap,
                            anchor="nw", fill=fg, tags=("bubble", tag))
        bx0, by0, bx1, by1 = c.bbox(tid)
        bw, bh = (bx1 - bx0) + 30, (by1 - by0) + 22
        left = (area_w - 16 - bw) if is_user else 16

        rid = c.create_polygon(round_rect_points(left, y_top, left + bw, y_top + bh, 15),
                               fill=fill, outline="", smooth=True, tags=("bubble", tag))
        c.tag_lower(rid, tid)
        if not is_user:
            # AI 气泡左侧一道紫竖条，一眼分清谁在说话
            c.create_line(left + 2, y_top + 12, left + 2, y_top + bh - 12,
                          fill=ACCENT, width=3, capstyle="round", tags=("bubble", tag))
        c.coords(tid, left + 15, y_top + 11)
        return bh

    def _render_from(self, start):
        """从第 start 个气泡起重排；它前面的位置没变，不用动。"""
        c = self.canvas
        full_width = max(c.winfo_width(), 460)
        # Both speakers stay in the left column, not on top of Cora's face.
        area_w = max(230, int(full_width * 0.54))
        y = 12
        if start > 0:
            prev = self.bubbles[start - 1]
            y = prev["y"] + prev["h"] + 10
        for i in range(start, len(self.bubbles)):
            c.delete(f"b{i}")
        for i in range(start, len(self.bubbles)):
            b = self.bubbles[i]
            h = self._draw_bubble(i, y, b["text"], b["role"], area_w)
            b["y"], b["h"] = y, h
            y += h + 10
        c.configure(scrollregion=(0, 0, full_width, max(y, c.winfo_height())))
        c.yview_moveto(1.0)

    def _apply_wrap(self):
        """窗口变宽 / 变窄后整片重排。

        背景由静态画布按尺寸缓存，这里只重新排版左侧的聊天气泡。
        """
        self._render_from(0)

    def _scroll_bottom(self):
        self.canvas.yview_moveto(1.0)

    def _on_canvas_configure(self, _e=None):
        self._apply_wrap()

    def _on_wheel(self, e):
        self.canvas.yview_scroll(int(-e.delta / 120), "units")

    # -------------------------------------------------------------- 输入处理
    def _bind_keys(self):
        self.root.bind("<KeyPress-space>", self._on_space_press)
        self.root.bind("<KeyRelease-space>", self._on_space_release)
        self.root.bind("<Escape>", lambda e: self.tts.stop())
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _entry_focused(self):
        try:
            return isinstance(self.root.focus_get(), tk.Entry)
        except Exception:
            return False

    def _on_space_press(self, _e):
        if self._entry_focused() or self._space_down:
            return
        self._space_down = True
        self.start_recording()

    def _on_space_release(self, _e):
        self._space_down = False
        self.stop_recording()

    def _set_hint_focus(self, focused):
        self.hint.configure(text="回车发送文字" if focused else "按住空格 或 按住圆钮说话")

    # ============================================================== 状态机
    def set_state(self, state, extra=None):
        self.state = state
        text, color = STATUS_TEXT.get(state, ("就绪", MUTED))
        if extra:
            text = extra
        self.status_lbl.configure(text=text, fg=color)
        self.dot.itemconfigure(self.dot_id, fill=color)

    # -------------------------------------------------------------- 录音
    def start_recording(self):
        if self.state in ("recognizing", "thinking", "loading", "error"):
            return
        # 正在朗读 → 打断，接着说话
        if self.tts.speaking:
            self.tts.stop()

        if not self._mic_ready:
            self._mic_ready = self._probe_mic()
            if not self._mic_ready:
                return

        try:
            self.recorder.start()
        except Exception as exc:
            self.set_state("error", f"麦克风打不开：{exc}")
            return

        self.set_state("recording")
        self.hint.configure(text="说完松开即可")

    def stop_recording(self):
        if self.state != "recording":
            return
        audio = self.recorder.stop()
        dur = len(audio) / float(self.recorder.sample_rate)
        self.hint.configure(text="按住空格 或 按住圆钮说话")

        min_sec = self.cfg.get("audio.min_record_seconds", 0.35)
        if dur < min_sec:
            self.set_state("idle", "太短了，按住多说一会儿")
            self.root.after(1400, lambda: self.set_state("idle") if self.state == "idle" else None)
            return

        self.set_state("recognizing")
        web_enabled = bool(self.web_search_var.get())
        threading.Thread(target=self._pipeline, args=(audio, web_enabled), daemon=True).start()

    def _probe_mic(self):
        try:
            import sounddevice as sd

            sd.query_devices(kind="input")
            return True
        except Exception as exc:
            self.set_state("error", f"没有找到可用的麦克风（{exc}）")
            self.root.after(3000, self._recover_idle)
            return False

    def _recover_idle(self):
        if self.state == "error":
            self.set_state("idle")

    # -------------------------------------------------------------- 主流程
    def _pipeline(self, audio, web_enabled=False):
        """后台线程：识别 → 提问 → 播报。"""
        self._pipeline_busy = True
        try:
            t0 = time.time()
            text = self.asr.transcribe(audio)
            if not text:
                self.q.put(("status", "没听清，再说一次？"))
                self.q.put(("idle", None))
                return
            print(f"[asr] {time.time() - t0:.2f}s -> {text}")
            self.q.put(("user", text))
            self._route(text, web_enabled=web_enabled)
        except Exception as exc:
            self.q.put(("error", f"识别失败：{exc}"))
            self.q.put(("idle", None))
        finally:
            self._pipeline_busy = False

    def _answer(self, text, web_enabled=False):
        if not self.llm.ready:
            msg = "我还没有接入对话模型，点右上角「设置」填一个 API Key 就能聊天了。"
            self.q.put(("ai_start", None))
            self.q.put(("ai_delta", msg))
            self.q.put(("ai_end", None))
            self.q.put(("speak", msg))
            return

        web_context = None
        sources = []
        search_warning = None
        if web_enabled:
            self.q.put(("status", "正在联网搜索…"))
            try:
                search = create_search(
                    self.cfg.get("web_search.provider", "bing_rss"),
                    self.cfg.get("web_search.api_key", ""),
                )
                sources = search.search(text)
                if not sources:
                    raise SearchError("搜索没有返回可用结果；本轮没有完成实时检索。")
                web_context = "\n\n".join(
                    f"标题：{item['title']}\n网址：{item['url']}\n摘要：{item['content']}"
                    for item in sources
                )
            except SearchError as exc:
                # 搜索不可用时仍然调用 DeepSeek，但明确标注回答不是实时检索结果。
                search_warning = f"本次联网搜索未成功：{exc} 已改用 DeepSeek 普通回答，不代表实时网页信息。"
                self.q.put(("status", "联网搜索不可用，改用 DeepSeek 普通回答…"))

        self.q.put(("status", "正在思考…"))
        self.q.put(("ai_start", None))
        buf = []
        try:
            for piece in self.llm.ask_stream(text, web_context=web_context):
                buf.append(piece)
                self.q.put(("ai_delta", piece))
        except LLMError as exc:
            self.q.put(("ai_end", None))
            err = str(exc)
            self.q.put(("bubble_ai", f"⚠ {err}"))
            self.q.put(("idle", None))
            return
        except Exception as exc:
            self.q.put(("ai_end", None))
            self.q.put(("bubble_ai", f"⚠ 出错了：{exc}"))
            self.q.put(("idle", None))
            return

        full = "".join(buf).strip()
        self.q.put(("ai_end", None))
        if sources:
            self.q.put(("sources", sources))
        if search_warning:
            self.q.put(("bubble_ai", "提示：" + search_warning))
        if full and self.tts.enabled:
            self.q.put(("speak", full))
        else:
            self.q.put(("idle", None))

    # -------------------------------------------------------------- Cora 联动
    def _route(self, text, web_enabled=False):
        """先让 Cora 判一次：是操控指令就执行，不是才交给大模型。

        这样"把 A1 移到右侧"会真的动电机，而"今天天气怎么样"照常聊天，
        用户不用在两个模式之间来回切。
        """
        if not self.chat_only and self.cora_on:
            try:
                if self._ask_cora(text):
                    return
            except Exception as exc:
                print(f"[cora] 转发失败：{exc}")
        self._answer(text, web_enabled=web_enabled)

    def _ask_cora(self, text, timeout=30.0):
        """把指令交给 Cora。返回 True 表示已由 Cora 处理掉。"""
        if self.chat_only:
            return False
        bridge = self.bridge
        if bridge is None or not bridge.ready():
            return False
        bridge.poll_replies()          # 先清掉积压，免得把上一条的结果当成本条
        if not bridge.send(text):
            return False
        self.q.put(("status", "Cora 正在执行…"))
        deadline = time.time() + timeout
        while time.time() < deadline:
            for item in bridge.poll_replies():
                if (item.get("cmd") or "").strip() != text.strip():
                    continue
                action = item.get("action", "")
                reply = (item.get("reply") or "").strip()
                if action == "unknown":
                    return False       # 不是操控指令，转交大模型
                body = reply or "已执行"
                self.q.put(("ai_start", None))
                self.q.put(("ai_delta", f"〔Cora〕{body}"))
                self.q.put(("ai_end", None))
                if reply and self.tts.enabled:
                    self.q.put(("speak", reply))
                else:
                    self.q.put(("idle", None))
                return True
            time.sleep(0.12)
        self.q.put(("bubble_ai", "Cora 没在预期时间内回应 —— 看一眼它的窗口里是不是有报错。"))
        self.q.put(("idle", None))
        return True

    def toggle_cora(self):
        if self.chat_only:
            return
        if self.cora_on:
            self.cora_on = False
            self.cora_btn.configure(text="联动 Cora", bg=ACCENT, fg="#ffffff")
            if self.bridge is not None:
                threading.Thread(target=self.bridge.stop, daemon=True).start()
            self._bubble("已断开 Cora，恢复正常问答。", "ai")
            return
        if self.bridge is not None and self.bridge.alive():
            return
        self.cora_btn.configure(text="启动中…", bg=CARD, fg=MUTED)
        self.set_state("loading", "正在启动 Cora（相机 + 模型，默认安全演练）…")
        threading.Thread(target=self._start_cora, daemon=True).start()

    def _start_cora(self):
        """后台线程：拉起 cora.py 并等它的主循环真正跑起来。"""
        if self.chat_only:
            return
        try:
            if self.bridge is None:
                self.bridge = CoraBridge(
                    CORA_DIR,
                    python_exe=_console_python(),
                    log=print,
                    hardware_enabled=bool(self.cfg.get("hardware.enabled", False)),
                    extra_args=self.cfg.get("hardware.cora_args", []),
                )
            ok, msg = self.bridge.start()
            if not ok:
                self.root.after(0, lambda: self._cora_failed(msg))
                return
            # 相机建流 + 模型加载 + 电机使能都要时间，等就绪信号
            deadline = time.time() + 75
            while time.time() < deadline:
                if self.bridge.ready() or not self.bridge.alive():
                    break
                time.sleep(0.3)
            if self.bridge.ready():
                self.cora_on = True
                self.root.after(0, lambda: self._cora_up(msg))
            else:
                detail = "；".join(self.bridge.problems()[-2:]) or \
                         "；".join(self.bridge.log_tail(3))
                self.root.after(0, lambda: self._cora_failed(f"{msg}\n{detail}"))
        except Exception as exc:
            self.root.after(0, lambda: self._cora_failed(f"启动 Cora 出错：{exc}"))

    def _cora_up(self, msg):
        self.cora_btn.configure(text="Cora 已联动", bg=OK_GREEN, fg="#0b0c14")
        self.set_state("idle")
        self._bubble(f"〔Cora〕{msg}\n\n"
                     "现在说的话会先当作操控指令：比如「把最左边的液滴移到右侧」。\n"
                     "不是操控指令的，我会照常当聊天回答。再说「停止」可以让电机立刻停下。",
                     "ai")

    def _cora_failed(self, msg):
        self.cora_on = False
        self.cora_btn.configure(text="联动 Cora", bg=ACCENT, fg="#ffffff")
        self.set_state("error", "Cora 没起来")
        self._bubble(f"〔Cora〕没能启动：\n{msg}", "ai")

    def send_text(self):
        if self.state in ("thinking", "recognizing", "loading"):
            return
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        if self.tts.speaking:
            self.tts.stop()
        self._bubble(text, "user")
        self.set_state("thinking")
        web_enabled = bool(self.web_search_var.get())
        threading.Thread(target=self._route, args=(text, web_enabled), daemon=True).start()

    # -------------------------------------------------------------- 队列泵
    def _drain_queue(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                self._handle_event(kind, payload)
        except queue.Empty:
            pass
        self.root.after(40, self._drain_queue)

    def _handle_event(self, kind, payload):
        if kind == "status":
            self.set_state(self.state if self.state != "idle" else "thinking", payload)
        elif kind == "user":
            self._bubble(payload, "user")
        elif kind == "ai_start":
            self.cur_ai_id = self._bubble("", "ai")
            self.ai_buffer = ""
        elif kind == "ai_delta":
            self.ai_buffer += payload
            self._update_bubble(self.cur_ai_id, self.ai_buffer)
        elif kind == "ai_end":
            if self.cur_ai_id is not None and not self.ai_buffer.strip():
                self._update_bubble(self.cur_ai_id, "（没有返回内容）")
            self.cur_ai_id = None
        elif kind == "sources":
            lines = ["来源（联网检索）："]
            for item in payload:
                lines.append(f"• {item['title']}\n  {item['url']}")
            self._bubble("\n".join(lines), "ai")
        elif kind == "bubble_ai":
            self._bubble(payload, "ai")
            self.set_state("error", payload[:40])
        elif kind == "speak":
            self.set_state("speaking")
            self.tts.speak(payload)
        elif kind == "idle":
            if not self.tts.speaking:
                self.set_state("idle")
        elif kind == "error":
            self.set_state("error", payload)
            self._bubble(f"⚠ {payload}", "ai")

    # -------------------------------------------------------------- 心跳
    def _tick(self):
        if self.state == "recording":
            lvl = self.recorder.level
            self._draw_mic(lvl, recording=True)
            if self.auto_var.get():
                should, _reason = self.recorder.check_auto_stop(
                    silence_seconds=self.cfg.get("audio.silence_seconds", 1.3),
                    max_seconds=self.cfg.get("audio.max_record_seconds", 30),
                    min_seconds=self.cfg.get("audio.min_record_seconds", 0.35),
                )
                if should:
                    self.stop_recording()
        elif self.state == "speaking":
            self._draw_mic(0.0, recording=False, speaking=True)
        else:
            self._draw_mic(0.0, recording=False)

        if self.tts.speaking and self.state != "speaking":
            self.set_state("speaking")
        if (not self.tts.speaking) and self.state == "speaking":
            self.set_state("idle")
        self.root.after(50, self._tick)

    def _toggle_web_search(self):
        self.cfg.set("web_search.enabled", bool(self.web_search_var.get()))
        self.cfg.save()

    def _toggle_auto_stop(self):
        self.cfg.set("audio.auto_stop", bool(self.auto_var.get()))
        self.cfg.save()

    # -------------------------------------------------------------- 启动引导
    def _boot(self):
        if not is_model_cached(self.cfg.get("asr.model", "base")):
            self.q.put(("status", "首次运行，正在下载语音模型…"))
        try:
            self.asr.preload()
            self.q.put(("boot_done", None))
        except Exception as exc:
            self.q.put(("error", f"语音模型加载失败：{exc}"))

    def _welcome(self):
        theme = "你好，我是 Cora。\n\n星空已就位，想聊些什么？"
        if self.chat_only:
            theme += "\n\n当前仅聊天，摄像头和电机未连接。"
        if not self.llm.ready:
            theme += "\n\n请先在右上角「设置」填写对话服务的 API Key，再开始问答。"
        self._bubble(theme, "ai")

    def _update_model_chip(self):
        name = self.cfg.get("llm.model", "")
        state = "已配置" if self.llm.ready else "未配置 Key"
        self.model_chip.configure(text=f"{name} · {state}")

    # ============================================================== 其他命令
    def clear_chat(self):
        self.canvas.delete("bubble")
        self.bubbles = []
        self.canvas.configure(scrollregion=(0, 0, 10, 10))
        self.llm.reset()
        self._welcome()
        self.set_state("idle")

    def open_settings(self):
        SettingsWindow(self)

    def _on_close(self):
        try:
            if self.bridge is not None:
                self.bridge.stop()
        except Exception:
            pass
        try:
            self.tts.stop()
        except Exception:
            pass
        try:
            if self.recorder.recording:
                self.recorder.stop()
        except Exception:
            pass
        try:
            self.hardware.disconnect_all()
        except Exception:
            pass
        try:
            self.cfg.save()
        except Exception:
            pass
        self.root.destroy()

    def apply_config(self):
        """设置窗口保存后回灌运行时组件。"""
        self.tts.voice = self.cfg.get("tts.voice")
        self.tts.rate = self.cfg.get("tts.rate")
        self.tts.enabled = bool(self.cfg.get("tts.enabled", True))
        self.llm.reconfigure(
            base_url=self.cfg.get("llm.base_url"),
            api_key=self.cfg.get("llm.api_key"),
            model=self.cfg.get("llm.model"),
            temperature=self.cfg.get("llm.temperature"),
            max_history=self.cfg.get("llm.max_history"),
        )
        self.auto_var.set(bool(self.cfg.get("audio.auto_stop", True)))
        self.web_search_var.set(bool(self.cfg.get("web_search.enabled", False)))
        wanted_simulated = bool(self.cfg.get("hardware.simulated", True))
        if wanted_simulated != self.hardware.simulated:
            self.hardware.disconnect_all()
            self.hardware = HardwareHub(simulated=wanted_simulated)
        self._update_model_chip()
        self.set_state("idle")


# ================================================================== 设置窗口
class SettingsWindow:
    def __init__(self, app: VoiceAssistant):
        self.app = app
        self.cfg = app.cfg
        self.win = tk.Toplevel(app.root)
        self.win.title("设置")
        self.win.configure(bg=BG)
        self.win.geometry("680x820")
        self.win.transient(app.root)
        self.win.grab_set()

        nb = ttk.Notebook(self.win)
        self._style_notebook()
        nb.pack(fill="both", expand=True, padx=12, pady=12)

        self.tab_llm = tk.Frame(nb, bg=BG)
        self.tab_voice = tk.Frame(nb, bg=BG)
        nb.add(self.tab_llm, text="  对话模型  ")
        self.tab_web = tk.Frame(nb, bg=BG)
        self.tab_device = tk.Frame(nb, bg=BG)
        nb.add(self.tab_voice, text="  语音  ")
        nb.add(self.tab_web, text="  联网搜索  ")
        nb.add(self.tab_device, text="  设备中心  ")

        self._build_llm_tab()
        self._build_voice_tab()
        self._build_web_tab()
        self._build_device_tab()

        bar = tk.Frame(self.win, bg=BG)
        bar.pack(fill="x", padx=12, pady=(0, 12))
        tk.Button(bar, text="保存", command=self.save, font=F_UI, bg=ACCENT, fg="#ffffff",
                  activebackground="#6a4ce8", activeforeground="#ffffff", relief="flat",
                  bd=0, padx=18, pady=6, cursor="hand2").pack(side="right")
        tk.Button(bar, text="取消", command=self.win.destroy, font=F_UI, bg=CARD, fg=TEXT,
                  activebackground=BORDER, relief="flat", bd=0, padx=14, pady=6,
                  cursor="hand2").pack(side="right", padx=(0, 8))
        self.status = tk.Label(bar, text="", bg=BG, fg=MUTED, font=F_SMALL)
        self.status.pack(side="left")

    def _style_notebook(self):
        style = ttk.Style()
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=MUTED,
                        padding=(14, 7), font=F_UI, borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", CARD)],
                  foreground=[("selected", TEXT)])

    # ------------------------------------------------------------ 通用控件
    def _label(self, parent, text, note=None):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill="x", padx=16, pady=(14, 4))
        tk.Label(f, text=text, bg=BG, fg=TEXT, font=F_UI).pack(side="left")
        if note:
            tk.Label(f, text=note, bg=BG, fg=MUTED, font=F_SMALL).pack(side="left", padx=(8, 0))
        return f

    def _entry(self, parent, value, show=None):
        e = tk.Entry(parent, bg=CARD, fg=TEXT, insertbackground=TEXT, font=F_UI,
                     relief="flat", bd=0, highlightthickness=1,
                     highlightbackground=BORDER, highlightcolor=ACCENT, show=show)
        e.pack(fill="x", padx=16, ipady=7)
        if value:
            e.insert(0, str(value))
        return e

    # ------------------------------------------------------------ 对话模型页
    def _build_llm_tab(self):
        p = self.tab_llm
        tk.Label(p, text="填上任意 OpenAI 兼容服务的 Key 即可使用，推荐 DeepSeek（注册送额度）。",
                 bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left").pack(
            anchor="w", padx=16, pady=(16, 0))

        self._label(p, "服务商", "选一个自动填好地址和模型名")
        self.provider = ttk.Combobox(p, values=list(PROVIDER_PRESETS.keys()),
                                     state="readonly", font=F_UI)
        self.provider.pack(fill="x", padx=16, ipady=4)
        self.provider.set(self._guess_provider())
        self.provider.bind("<<ComboboxSelected>>", self._on_provider)

        self._label(p, "API Key", "必填")
        self.key_entry = self._entry(p, self.cfg.get("llm.api_key"), show="•")

        self._label(p, "接口地址 base_url")
        self.url_entry = self._entry(p, self.cfg.get("llm.base_url"))

        self._label(p, "模型名 model")
        self.model_entry = self._entry(p, self.cfg.get("llm.model"))

        self._label(p, "温度 temperature", "0~2，越大越活泼")
        self.temp_entry = self._entry(p, self.cfg.get("llm.temperature"))

        link = tk.Label(p, text="点这里打开申请页面 →", bg=BG, fg=ACCENT, font=F_SMALL,
                        cursor="hand2")
        link.pack(anchor="w", padx=16, pady=(10, 0))
        link.bind("<Button-1>", self._open_provider_help)

        tk.Label(p, text="Key 只保存在本机的 config.json 里，不会上传到任何地方。",
                 bg=BG, fg=MUTED, font=F_SMALL).pack(anchor="w", padx=16, pady=(12, 0))

    def _guess_provider(self):
        url = (self.cfg.get("llm.base_url") or "").lower()
        for name, pres in PROVIDER_PRESETS.items():
            if pres["base_url"].lower().rstrip("/") == url.rstrip("/"):
                return name
        return list(PROVIDER_PRESETS.keys())[0]

    def _on_provider(self, _e=None):
        pres = PROVIDER_PRESETS.get(self.provider.get())
        if not pres:
            return
        self._replace(self.url_entry, pres["base_url"])
        self._replace(self.model_entry, pres["model"])

    def _open_provider_help(self, _e=None):
        pres = PROVIDER_PRESETS.get(self.provider.get()) or {}
        url = pres.get("help")
        if url:
            import webbrowser

            webbrowser.open(url)

    @staticmethod
    def _replace(entry, text):
        entry.delete(0, "end")
        entry.insert(0, text or "")

    # ------------------------------------------------------------ 联网搜索页
    def _build_web_tab(self):
        p = self.tab_web
        tk.Label(p, text="联网搜索默认关闭。开启后，Cora 先取得网页摘要，再交给 DeepSeek 生成回答并显示来源。",
                 bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left").pack(
            anchor="w", padx=16, pady=(16, 8))
        self._label(p, "搜索方式", "推荐免 Key 模式")
        self.search_provider_values = ["DeepSeek 联网模式（免搜索 Key）", "Tavily（需要 Tavily Key）"]
        self.search_provider_codes = {self.search_provider_values[0]: "bing_rss", self.search_provider_values[1]: "tavily"}
        self.search_provider = ttk.Combobox(p, values=self.search_provider_values,
                                            state="readonly", font=F_UI)
        self.search_provider.pack(fill="x", padx=16, ipady=4)
        current_provider = self.cfg.get("web_search.provider", "bing_rss")
        current_label = self.search_provider_values[1] if current_provider == "tavily" else self.search_provider_values[0]
        self.search_provider.set(current_label)

        self._label(p, "Tavily API Key（可选）", "仅选择 Tavily 时需要")
        self.tavily_key_entry = self._entry(p, self.cfg.get("web_search.api_key", ""), show="•")
        tk.Label(p, text=("推荐使用默认的 DeepSeek 联网模式：它用免 Key 的公网搜索取得网页摘要，"
                          "再由你配置的 DeepSeek API 生成回答；不需要再申请 Tavily Key。"
                          "搜索只发送当前问题，不上传本地文件或完整聊天记录。"),
                 bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left").pack(
            anchor="w", padx=16, pady=(12, 0))
        tk.Label(p, text="如果公网搜索被网络、代理或防火墙拦截，Cora 会改用 DeepSeek 普通回答，并明确提示不会假装是实时信息。",
                 bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left").pack(
            anchor="w", padx=16, pady=(12, 0))

    # ------------------------------------------------------------ 设备中心页
    def _device_status(self, text, color=MUTED):
        self.device_status.configure(text=text, fg=color)

    def _refresh_device_status(self):
        status = self.app.hardware.status()
        mode = "模拟模式" if status["simulated"] else "真实设备模式"
        parts = [mode,
                 "相机已连接" if status["camera_connected"] else "相机未连接",
                 "电机已连接" if status["motor_connected"] else "电机未连接",
                 "控制已解锁" if status["motor_unlocked"] else "控制已锁定"]
        if status["emergency_stopped"]:
            parts.append("急停中")
        if status["vision_loaded"]:
            parts.append("视觉模型已加载")
        self._device_status(" · ".join(parts), WARN if status["emergency_stopped"] else MUTED)

    def _toggle_simulated(self):
        simulated = bool(self.simulated_var.get())
        self.cfg.set("hardware.simulated", simulated)
        self.app.hardware.disconnect_all()
        self.app.hardware = HardwareHub(simulated=simulated)
        self._refresh_device_status()

    def _connect_camera(self):
        try:
            index = int(self.camera_index_entry.get().strip() or "0")
            self.app.hardware.camera.connect(index)
            self._device_status(f"摄像头 {index} 已连接", OK_GREEN)
        except Exception as exc:
            self._device_status(f"摄像头连接失败：{exc}", REC_RED)

    def _disconnect_camera(self):
        self.app.hardware.camera.disconnect()
        self._refresh_device_status()

    def _read_camera(self):
        try:
            frame = self.app.hardware.camera.read()
            if isinstance(frame, dict) and frame.get("simulated"):
                self._device_status("模拟画面读取成功（640×480）", OK_GREEN)
            else:
                shape = getattr(frame, "shape", None)
                self._device_status(f"画面读取成功：{shape or '已获取帧'}", OK_GREEN)
        except Exception as exc:
            self._device_status(f"读取画面失败：{exc}", REC_RED)

    def _connect_motor(self):
        try:
            port = self.motor_port_entry.get().strip() or "SIM"
            self.app.hardware.motor.connect(port)
            self._device_status(f"电机 {port} 已连接，但控制仍锁定", OK_GREEN)
        except Exception as exc:
            self._device_status(f"电机连接失败：{exc}", REC_RED)

    def _disconnect_motor(self):
        self.app.hardware.motor.disconnect()
        self._refresh_device_status()

    def _unlock_hardware(self):
        if self.app.hardware.safety_gate.unlock(self.unlock_entry.get()):
            self._device_status("已解锁；每次真实运动仍需确认", WARN)
        else:
            self._device_status(f"解锁失败：请输入“{UNLOCK_PHRASE}”", REC_RED)

    def _hardware_jog(self, action):
        if action != "stop" and not self.app.hardware.simulated:
            if not messagebox.askyesno("确认电机动作", f"确认让电机执行“{action}”吗？", parent=self.win):
                return
        try:
            steps = int(self.steps_entry.get().strip() or "10")
            result = self.app.hardware.motor.jog(action, steps=steps, confirmed=True)
            self._device_status(f"已执行 {result['action']} {result['steps']} 步" +
                                ("（模拟）" if result["simulated"] else ""), OK_GREEN)
        except Exception as exc:
            self._device_status(f"动作未执行：{exc}", REC_RED)

    def _emergency_stop(self):
        self.app.hardware.motor.emergency_stop()
        self._device_status("急停已触发；复位后必须重新解锁", WARN)

    def _reset_emergency(self):
        self.app.hardware.safety_gate.reset_emergency()
        self._refresh_device_status()

    def _browse_engine(self):
        path = filedialog.askopenfilename(parent=self.win, title="选择视觉模型",
                                          filetypes=[("Engine/ONNX", "*.engine *.onnx"), ("所有文件", "*.*")])
        if path:
            self.engine_entry.delete(0, "end")
            self.engine_entry.insert(0, path)

    def _load_engine(self):
        try:
            self.app.hardware.vision.load(self.engine_entry.get().strip())
            self.cfg.set("hardware.engine_path", self.engine_entry.get().strip())
            self._device_status("视觉模型路径已验证并加载；具体推理由现有 Cora 进程负责", OK_GREEN)
        except Exception as exc:
            self._device_status(f"模型加载失败：{exc}", REC_RED)

    def _build_device_tab(self):
        p = self.tab_device
        tk.Label(p, text="设备默认断开、模拟模式、硬件锁定。这里的连接和点动都不会自动发生。",
                 bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left").pack(
            anchor="w", padx=16, pady=(14, 6))
        self.simulated_var = tk.BooleanVar(value=bool(self.cfg.get("hardware.simulated", True)))
        tk.Checkbutton(p, text="模拟模式（推荐，不接触真实摄像头/电机）", variable=self.simulated_var,
                       command=self._toggle_simulated, bg=BG, fg=TEXT, selectcolor=CARD,
                       activebackground=BG, activeforeground=TEXT, font=F_UI, bd=0,
                       highlightthickness=0).pack(anchor="w", padx=16, pady=(2, 4))
        self.device_status = tk.Label(p, text="", bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left")
        self.device_status.pack(anchor="w", padx=16, pady=(0, 8))

        self._label(p, "摄像头编号", "真实模式常用 0/1/2")
        row = tk.Frame(p, bg=BG); row.pack(fill="x", padx=16)
        self.camera_index_entry = self._entry(row, self.cfg.get("hardware.camera_index", 0))
        self.camera_index_entry.pack_forget(); self.camera_index_entry.pack(side="left", fill="x", expand=True, ipady=7)
        tk.Button(row, text="连接", command=self._connect_camera, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(6, 0))
        tk.Button(row, text="读取帧", command=self._read_camera, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(4, 0))
        tk.Button(row, text="断开", command=self._disconnect_camera, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(4, 0))

        self._label(p, "电机串口", "模拟模式可填 SIM")
        row = tk.Frame(p, bg=BG); row.pack(fill="x", padx=16)
        self.motor_port_entry = self._entry(row, self.cfg.get("hardware.motor_port", "SIM"))
        self.motor_port_entry.pack_forget(); self.motor_port_entry.pack(side="left", fill="x", expand=True, ipady=7)
        tk.Button(row, text="连接", command=self._connect_motor, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(6, 0))
        tk.Button(row, text="断开", command=self._disconnect_motor, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(4, 0))

        self._label(p, "硬件解锁", "输入完整短语后才允许点动")
        row = tk.Frame(p, bg=BG); row.pack(fill="x", padx=16)
        self.unlock_entry = self._entry(row, "", show="•")
        self.unlock_entry.pack_forget(); self.unlock_entry.pack(side="left", fill="x", expand=True, ipady=7)
        tk.Button(row, text="解锁", command=self._unlock_hardware, bg=ACCENT, fg="#fff", relief="flat", bd=0, padx=10, pady=5).pack(side="left", padx=(6, 0))
        tk.Button(row, text="急停", command=self._emergency_stop, bg=REC_RED, fg="#fff", relief="flat", bd=0, padx=10, pady=5).pack(side="left", padx=(4, 0))
        tk.Button(row, text="复位急停", command=self._reset_emergency, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(4, 0))

        self._label(p, "步进电机点动", "仅支持白名单方向")
        row = tk.Frame(p, bg=BG); row.pack(fill="x", padx=16)
        self.steps_entry = self._entry(row, "10")
        self.steps_entry.pack_forget(); self.steps_entry.pack(side="left", fill="x", expand=True, ipady=7)
        for action, label in (("left", "左移"), ("right", "右移"), ("up", "上移"), ("down", "下移"), ("stop", "停止")):
            tk.Button(row, text=label, command=lambda a=action: self._hardware_jog(a), bg=CARD, fg=TEXT,
                      relief="flat", bd=0, padx=6, pady=5).pack(side="left", padx=(4, 0))

        self._label(p, "视觉模型 .engine", "只验证路径；推理仍由现有 Cora 程序负责")
        row = tk.Frame(p, bg=BG); row.pack(fill="x", padx=16)
        self.engine_entry = self._entry(row, self.cfg.get("hardware.engine_path", ""))
        self.engine_entry.pack_forget(); self.engine_entry.pack(side="left", fill="x", expand=True, ipady=7)
        tk.Button(row, text="选择", command=self._browse_engine, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(6, 0))
        tk.Button(row, text="加载", command=self._load_engine, bg=CARD, fg=TEXT, relief="flat", bd=0, padx=8, pady=5).pack(side="left", padx=(4, 0))
        self._refresh_device_status()

    # ------------------------------------------------------------ 语音页
    def _build_voice_tab(self):
        p = self.tab_voice
        self._label(p, "回答音色")
        self.voice_names = [v[0] for v in VOICE_CHOICES] + ["自定义"]
        self.voice_box = ttk.Combobox(p, values=[v[1] for v in VOICE_CHOICES] + ["自定义"],
                                      state="readonly", font=F_UI)
        self.voice_box.pack(fill="x", padx=16, ipady=4)
        cur = self.cfg.get("tts.voice")
        idx = next((i for i, v in enumerate(VOICE_CHOICES) if v[0] == cur), 0)
        self.voice_box.current(idx)

        ttk.Button(p, text="试听这句话", command=self._preview).pack(anchor="w", padx=16, pady=(8, 0))

        self._label(p, "语速 rate", "如 +20% / -10%")
        self.rate_entry = self._entry(p, self.cfg.get("tts.rate"))

        self.speak_var = tk.BooleanVar(value=bool(self.cfg.get("tts.enabled", True)))
        tk.Checkbutton(p, text="朗读回答（关闭则只显示文字）", variable=self.speak_var,
                       bg=BG, fg=TEXT, selectcolor=CARD, activebackground=BG,
                       activeforeground=TEXT, font=F_UI, bd=0, highlightthickness=0).pack(
            anchor="w", padx=16, pady=(14, 0))

        tk.Frame(p, bg=BORDER, height=1).pack(fill="x", padx=16, pady=14)

        self._label(p, "识别模型", "越大越准也越慢，改完需重启")
        self.asr_box = ttk.Combobox(p, values=["tiny", "base", "small", "medium"],
                                    state="readonly", font=F_UI)
        self.asr_box.pack(fill="x", padx=16, ipady=4)
        self.asr_box.set(self.cfg.get("asr.model", "base"))

        self._label(p, "识别热词", "专有名词用逗号分隔，能提高识别率")
        self.hot_entry = self._entry(p, self.cfg.get("asr.hotwords"))

        tk.Label(p, text="第一次使用某个模型会自动下载（tiny 75MB / base 150MB / small 480MB）。",
                 bg=BG, fg=MUTED, font=F_SMALL, wraplength=450, justify="left").pack(
            anchor="w", padx=16, pady=(10, 0))

    def _preview(self):
        idx = self.voice_box.current()
        voice = VOICE_CHOICES[idx][0] if idx < len(VOICE_CHOICES) else self.cfg.get("tts.voice")
        self.status.configure(text="正在合成试听…", fg=MUTED)

        def _run():
            self.app.tts.preview(voice, "你好，我是 Cora，很高兴为你服务。")
            self.win.after(0, lambda: self.status.configure(text=""))

        threading.Thread(target=_run, daemon=True).start()

    # ------------------------------------------------------------ 保存
    def save(self):
        key = self.key_entry.get().strip()
        url = self.url_entry.get().strip()
        model = self.model_entry.get().strip()
        if not url or not model:
            self.status.configure(text="接口地址和模型名不能为空", fg=REC_RED)
            return
        try:
            temp = float(self.temp_entry.get().strip())
        except ValueError:
            temp = 0.7

        idx = self.voice_box.current()
        voice = VOICE_CHOICES[idx][0] if 0 <= idx < len(VOICE_CHOICES) else self.cfg.get("tts.voice")

        self.cfg.set("llm.api_key", key)
        self.cfg.set("llm.base_url", url)
        self.cfg.set("llm.model", model)
        self.cfg.set("llm.temperature", temp)
        self.cfg.set("tts.voice", voice)
        self.cfg.set("tts.rate", self.rate_entry.get().strip() or "+0%")
        self.cfg.set("tts.enabled", bool(self.speak_var.get()))
        self.cfg.set("asr.model", self.asr_box.get())
        self.cfg.set("asr.hotwords", self.hot_entry.get().strip())
        # 搜索 Key 仅用于本次运行；Config.save 会将其擦除。
        selected_label = self.search_provider.get()
        provider = self.search_provider_codes.get(selected_label, "bing_rss")
        self.cfg.set("web_search.provider", provider)
        self.cfg.set("web_search.api_key", self.tavily_key_entry.get().strip())
        self.cfg.set("web_search.enabled", bool(self.app.web_search_var.get()))
        self.cfg.set("hardware.simulated", bool(self.simulated_var.get()))
        self.cfg.set("hardware.camera_index", self.camera_index_entry.get().strip() or "0")
        self.cfg.set("hardware.motor_port", self.motor_port_entry.get().strip())
        self.cfg.set("hardware.engine_path", self.engine_entry.get().strip())
        self.cfg.save()

        self.app.apply_config()
        self.status.configure(text="已保存", fg=OK_GREEN)
        self.win.after(600, self.win.destroy)


def parse_startup_args(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description="Cora 语音交互")
    parser.add_argument("--enable-control", action="store_true",
                        help="显示主链联动入口；电机仍由 hardware.enabled 单独控制")
    return parser.parse_args(argv)


def main(argv=None):
    options = parse_startup_args(argv)
    if not TK_AVAILABLE:
        print("启动失败：当前 Python 没有 Tk 支持，无法打开桌面界面。")
        return 1
    root = tk.Tk()
    app = VoiceAssistant(root, chat_only=not options.enable_control)

    # 启动后台：模型加载完成后打开麦克风自检
    def _after_boot():
        def _check():
            if app.asr.loaded:
                app._mic_ready = app._probe_mic()
                if app.state == "loading":
                    app.set_state("idle")
            else:
                app.root.after(400, _check)

        app.root.after(400, _check)

    _after_boot()
    root.mainloop()


if __name__ == "__main__":
    main()

