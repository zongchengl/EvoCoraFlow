# -*- coding: utf-8 -*-
"""安全的海康相机曝光扫描：只读取图像，不连接电机、不发送运动指令。"""
import argparse
import os
import sys
import time
import cv2

HERE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "01-Cora-液滴操控系统")
sys.path.insert(0, HERE)
import droplet_core as core
from image_io import write_image


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", default=os.path.join(HERE, "diagnostics", "exposure"))
    p.add_argument("--width", type=int, default=2024)
    p.add_argument("--height", type=int, default=2036)
    p.add_argument("--offset-x", type=int, default=0)
    p.add_argument("--offset-y", type=int, default=0)
    p.add_argument("--gain", type=float, default=0.0)
    p.add_argument("--exposures", default="1500,3000,5000,8000,12000,15000,20000,30000")
    args = p.parse_args()
    os.makedirs(args.output, exist_ok=True)
    exposures = [float(x.strip()) for x in args.exposures.split(",") if x.strip()]
    cam = core.HikCamera(width=args.width, height=args.height,
                          offset_x=args.offset_x, offset_y=args.offset_y,
                          exposure_time=exposures[0], gain=args.gain)
    print(f"相机：{args.width}x{args.height}，gain={args.gain}")
    try:
        for exposure in exposures:
            cam.cam.MV_CC_SetEnumValue("ExposureAuto", 0)
            cam.cam.MV_CC_SetFloatValue("ExposureTime", exposure)
            cam.cam.MV_CC_SetEnumValue("GainAuto", 0)
            cam.cam.MV_CC_SetFloatValue("Gain", args.gain)
            time.sleep(0.25)
            frame = None
            for _ in range(3):
                frame = cam.get_frame(timeout=2000)
            if frame is None:
                print(f"曝光 {exposure:>7.0f} us：取帧失败")
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            mean = float(gray.mean())
            over = float((gray >= 250).mean() * 100)
            under = float((gray <= 5).mean() * 100)
            name = os.path.join(args.output, f"exposure_{int(exposure)}us.png")
            preview = cv2.resize(frame, (0, 0), fx=0.35, fy=0.35, interpolation=cv2.INTER_AREA)
            write_image(name, preview)
            print(f"曝光 {exposure:>7.0f} us：均值 {mean:6.1f}，过曝 {over:6.2f}% ，欠曝 {under:6.2f}% ，{name}")
    finally:
        cam.close()


if __name__ == "__main__":
    main()
